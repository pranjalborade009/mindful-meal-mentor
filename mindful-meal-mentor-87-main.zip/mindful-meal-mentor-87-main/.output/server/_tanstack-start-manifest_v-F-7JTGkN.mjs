//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-F-7JTGkN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_workspace",
			"/forgot-password",
			"/login",
			"/register"
		],
		preloads: [
			"/assets/index-CGRaIl-6.js",
			"/assets/jsx-runtime-D3jfb0Ew.js",
			"/assets/react-dom-CwdmouWZ.js",
			"/assets/matchContext-CaFHjCGQ.js",
			"/assets/_workspace.foods._foodId-C4QOkl3j.js",
			"/assets/link-Cqw0SZOf.js",
			"/assets/dist-CWtSPrbB.js",
			"/assets/food-data-service-CYB1yRp6.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CGRaIl-6.js"
		} }]
	},
	"/": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-L4Q2rmpV.js",
			"/assets/hero-meal-DZsDpMu-.js",
			"/assets/createLucideIcon-GbkIog0d.js",
			"/assets/arrow-right-Do1YRq-l.js",
			"/assets/FoodCard-b8FA2s_I.js",
			"/assets/network-DY9DdEcy.js",
			"/assets/user-round-BSAvy415.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/sparkles-BNBj2awz.js",
			"/assets/x-C1YxrEI2.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/Logo-unpZ6WyN.js"
		]
	},
	"/_workspace": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.tsx",
		children: [
			"/_workspace/assessment",
			"/_workspace/dashboard",
			"/_workspace/diary",
			"/_workspace/explorer",
			"/_workspace/history",
			"/_workspace/insights",
			"/_workspace/profile",
			"/_workspace/recommendations",
			"/_workspace/saved",
			"/_workspace/foods/$foodId"
		],
		preloads: [
			"/assets/_workspace-Bb5VD-gT.js",
			"/assets/useNavigate-B-zoS3m-.js",
			"/assets/createLucideIcon-GbkIog0d.js",
			"/assets/book-open-BXfbFqSQ.js",
			"/assets/bookmark-BpAGh4iJ.js",
			"/assets/user-round-BSAvy415.js",
			"/assets/history-B4amKG8I.js",
			"/assets/search-B2A_Zr5w.js",
			"/assets/sparkles-BNBj2awz.js",
			"/assets/x-C1YxrEI2.js",
			"/assets/dist-B3pUOe40.js",
			"/assets/dist-4ghk4zK4.js",
			"/assets/dist-BCwNX6AT.js",
			"/assets/Logo-unpZ6WyN.js"
		]
	},
	"/forgot-password": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-Cgz_ETZn.js",
			"/assets/createLucideIcon-GbkIog0d.js",
			"/assets/arrow-left-hNlAnx9b.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/input-FiBMTdHF.js",
			"/assets/AuthLayout-BRiVxAN0.js"
		]
	},
	"/login": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-Bpr1A9Tz.js",
			"/assets/useNavigate-B-zoS3m-.js",
			"/assets/checkbox-BCfF7nGq.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/input-FiBMTdHF.js",
			"/assets/AuthLayout-BRiVxAN0.js"
		]
	},
	"/register": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-Bq5V1suL.js",
			"/assets/useNavigate-B-zoS3m-.js",
			"/assets/checkbox-BCfF7nGq.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/input-FiBMTdHF.js",
			"/assets/AuthLayout-BRiVxAN0.js"
		]
	},
	"/_workspace/assessment": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.assessment.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.assessment-DYq-CK1c.js",
			"/assets/arrow-left-hNlAnx9b.js",
			"/assets/arrow-right-Do1YRq-l.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/input-FiBMTdHF.js",
			"/assets/dist-CyBCRTPs.js",
			"/assets/textarea-Caytr_j7.js"
		]
	},
	"/_workspace/dashboard": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.dashboard-DABF8zbN.js",
			"/assets/arrow-right-Do1YRq-l.js",
			"/assets/FoodCard-b8FA2s_I.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/target-DwiEufwh.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/generateCategoricalChart-BEY-RGSc.js",
			"/assets/demoHistory-DbDB2drD.js"
		]
	},
	"/_workspace/diary": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.diary.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.diary-B9e6V3j5.js",
			"/assets/FoodCard-b8FA2s_I.js",
			"/assets/check-D5PIylc8.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/search-x-CDQAVHFK.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/input-FiBMTdHF.js"
		]
	},
	"/_workspace/explorer": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.explorer.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.explorer-BTNr4tTy.js",
			"/assets/FoodCard-b8FA2s_I.js",
			"/assets/select-BkGywjZJ.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/search-x-CDQAVHFK.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/input-FiBMTdHF.js",
			"/assets/dist-CyBCRTPs.js",
			"/assets/dist-C27j6xoU.js",
			"/assets/dist-CvH34gRE.js",
			"/assets/dist-BDDJhNHz.js",
			"/assets/FoodFilters-CEUmz1LZ.js"
		]
	},
	"/_workspace/history": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.history.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.history-B1LsLmKU.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/target-DwiEufwh.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/demoHistory-DbDB2drD.js"
		]
	},
	"/_workspace/insights": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.insights.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.insights-kAsJdobA.js",
			"/assets/arrow-right-Do1YRq-l.js",
			"/assets/network-DY9DdEcy.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/dist-CyBCRTPs.js",
			"/assets/dist-C27j6xoU.js",
			"/assets/dist-CvH34gRE.js",
			"/assets/dist-MEaLFxYW.js"
		]
	},
	"/_workspace/profile": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.profile.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.profile-ClKEAoTC.js",
			"/assets/select-BkGywjZJ.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/input-FiBMTdHF.js",
			"/assets/textarea-Caytr_j7.js",
			"/assets/demoHistory-DbDB2drD.js"
		]
	},
	"/_workspace/recommendations": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.recommendations.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.recommendations-C05rZxF0.js",
			"/assets/FoodCard-b8FA2s_I.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/search-x-CDQAVHFK.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/demoHistory-DbDB2drD.js",
			"/assets/FoodFilters-CEUmz1LZ.js"
		]
	},
	"/_workspace/saved": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.saved.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.saved-Dryz6XuP.js",
			"/assets/FoodCard-b8FA2s_I.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/button-BwMEgZn2.js"
		]
	},
	"/_workspace/foods/$foodId": {
		filePath: "D:/ML Project/mindful-meal-mentor-87-main/src/routes/_workspace.foods.$foodId.tsx",
		children: void 0,
		preloads: [
			"/assets/_workspace.foods._foodId-1brvIzi0.js",
			"/assets/arrow-left-hNlAnx9b.js",
			"/assets/FoodCard-b8FA2s_I.js",
			"/assets/common-BEy9eFGc.js",
			"/assets/leaf-rhN69OLV.js",
			"/assets/button-BwMEgZn2.js",
			"/assets/input-FiBMTdHF.js",
			"/assets/generateCategoricalChart-BEY-RGSc.js",
			"/assets/_workspace.foods._foodId-BNYebz2g.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
