import { i as __toESM } from "./_runtime.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { l as SearchX, o as Sparkles, w as Info } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as foodDataService } from "./_ssr/food-data-service-ig-qFVcp.mjs";
import { i as PageHeader, n as DemoBadge, r as EmptyState } from "./_ssr/common-DdTCn9RE.mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
import { r as recommendationService, t as FoodCard } from "./_ssr/FoodCard-DBah2pwS.mjs";
import { n as demoProfile } from "./_ssr/demoHistory-B7iCp8mX.mjs";
import { n as SortSelect, r as useFoodFilter, t as FilterSelect } from "./_ssr/FoodFilters-D5cF2aTN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.recommendations-25n_1w1W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
function RecommendationsPage() {
	const recommendationFoods = recommendationService.getRecommendations().map(({ foodId }) => foodDataService.getById(foodId)).filter((food) => food !== void 0);
	const { f, setF, results, reset } = useFoodFilter(recommendationFoods);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const generate = () => {
		setLoading(true);
		setTimeout(() => {
			setLoading(false);
			toast("Sample set refreshed", { description: "Prototype only — the ML engine is not connected yet." });
		}, 1200);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Meal planning",
				title: "Meal Planner",
				description: "Foods that fit your goals and dietary preferences, tailored to your daily routine.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "forest",
					onClick: generate,
					disabled: loading,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}),
						" ",
						loading ? "Planning…" : "Build Meal Plan"
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 rounded-xl bg-forest p-5 text-forest-foreground md:grid-cols-4",
				children: [
					["Goal", demoProfile.goal],
					["Diet", demoProfile.diet],
					["Calories", `${demoProfile.targets.caloriesKcal} kcal`],
					["Protein", `${demoProfile.targets.proteinG} g`]
				].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.68rem] uppercase tracking-widest opacity-60",
					children: k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-xl",
					children: v
				})] }, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
							value: f.meal,
							onChange: (v) => setF({
								...f,
								meal: v
							}),
							placeholder: "Meals",
							options: [
								"Breakfast",
								"Lunch",
								"Dinner",
								"Snack"
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-44",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
							value: f.cuisine,
							onChange: (v) => setF({
								...f,
								cuisine: v
							}),
							placeholder: "Cuisines",
							options: foodDataService.getCuisines()
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-44",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
							value: f.diet,
							onChange: (v) => setF({
								...f,
								diet: v
							}),
							placeholder: "Diets",
							options: [
								"Vegetarian",
								"Non-vegetarian",
								"Vegan"
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ml-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortSelect, {
							value: f.sort,
							onChange: (v) => setF({
								...f,
								sort: v
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" }), " Meal-fit scores are sample suggestions only and should be treated as placeholders."]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoBadge, {})]
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
				children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-[5/4] rounded-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-24" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-40" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" })
						]
					})]
				}, i))
			}) : results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: SearchX,
				title: "No foods match these filters",
				description: "Try widening your filters.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: reset,
					children: "Reset filters"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
				children: results.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodCard, {
					food: x,
					showReason: true
				}, x.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-xs text-muted-foreground",
				children: ["Want to review your nutrition context? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/insights",
					className: "text-primary hover:underline",
					children: "Open Nutrition Insights"
				})]
			})
		]
	});
}
//#endregion
export { RecommendationsPage as component };
