import { t as cn } from "./utils-C_uf36nf.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { K as ArrowUpRight, U as Bookmark, W as BookmarkCheck, x as Leaf } from "../_libs/lucide-react.mjs";
import { i as formatNutrient } from "./food-data-service-ig-qFVcp.mjs";
import { n as useSavedFoods } from "./use-saved-foods-CT0vTAMy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FoodCard-DBah2pwS.js
var import_jsx_runtime = require_jsx_runtime();
/** Illustrative prototype scores only; these are not outputs from a trained model. */
var demoRecommendations = [
	{
		foodId: "salmon-quinoa-bowl",
		score: 91,
		scoreUnit: "percent",
		reason: "High protein density with balanced fats.",
		source: "demo"
	},
	{
		foodId: "paneer-tikka",
		score: 86,
		scoreUnit: "percent",
		reason: "Vegetarian protein source, low carbohydrate.",
		source: "demo"
	},
	{
		foodId: "greek-yogurt-bowl",
		score: 83,
		scoreUnit: "percent",
		reason: "Moderate calories, good morning protein.",
		source: "demo"
	},
	{
		foodId: "lentil-salad",
		score: 88,
		scoreUnit: "percent",
		reason: "Very high fiber, supports satiety.",
		source: "demo"
	},
	{
		foodId: "millet-khichdi",
		score: 79,
		scoreUnit: "percent",
		reason: "Whole-grain carbohydrates, familiar cuisine.",
		source: "demo"
	},
	{
		foodId: "tofu-stir-fry",
		score: 84,
		scoreUnit: "percent",
		reason: "Plant protein with complex carbohydrates.",
		source: "demo"
	},
	{
		foodId: "grilled-chicken-plate",
		score: 90,
		scoreUnit: "percent",
		reason: "Highest protein per calorie in sample set.",
		source: "demo"
	},
	{
		foodId: "moong-chilla",
		score: 81,
		scoreUnit: "percent",
		reason: "Low-fat, protein-rich vegan breakfast.",
		source: "demo"
	}
];
/** Demo-only source until a real recommendation API is available. */
var recommendationService = {
	getRecommendations() {
		return demoRecommendations;
	},
	getForFood(foodId) {
		return demoRecommendations.find((recommendation) => recommendation.foodId === foodId);
	}
};
function Macro({ label, value, unit = "g" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold text-forest sm:text-sm",
			children: value === null ? "Not available" : formatNutrient(value, unit)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[0.65rem] uppercase tracking-wider text-muted-foreground",
			children: label
		})]
	});
}
function FoodImage({ food, className }) {
	if (food.image) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: food.image,
		alt: food.name,
		loading: "lazy",
		width: 912,
		height: 736,
		className: cn("size-full object-cover", className)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "img",
		"aria-label": `Photo unavailable for ${food.name}`,
		className: cn("grid size-full place-items-center bg-sage/75 text-forest", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-11 place-items-center rounded-full border border-forest/15 bg-card/75",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
				className: "size-5",
				"aria-hidden": "true"
			})
		})
	});
}
function FoodCard({ food, showReason, onRemove }) {
	const { isSaved, toggle } = useSavedFoods();
	const saved = isSaved(food.id);
	const recommendation = recommendationService.getForFood(food.id);
	const metadata = [
		food.regionalOrigin ?? (food.cuisine !== "Unspecified" ? food.cuisine : void 0),
		food.preparationState && food.preparationState !== "not-specified" ? food.preparationState : void 0,
		food.meal ?? void 0
	].filter((value) => value !== void 0);
	const qualityLabel = food.source === "usda-fooddata-central" ? "USDA · estimated" : food.source === "demo" ? "Demo · estimated" : `${food.nutritionDataQuality} nutrition`;
	const servingLabel = food.nutrition.basis === "per-100g" ? "Per 100 g" : `Per ${food.nutrition.servingSize.description ?? `${food.nutrition.servingSize.quantity} ${food.nutrition.servingSize.unit}`}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "surface lift group flex flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[5/4] overflow-hidden bg-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodImage, {
					food,
					className: "transition-transform duration-700 group-hover:scale-105"
				}),
				recommendation?.source === "demo" && recommendation.score != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "absolute left-3 top-3 rounded-full bg-card/90 px-2.5 py-1 text-[0.68rem] font-medium text-forest backdrop-blur",
					title: "Illustrative prototype score — not a model prediction",
					children: ["Sample match ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-semibold",
						children: [recommendation.score, "%"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onRemove ?? (() => toggle(food.id)),
					"aria-label": onRemove ? `Remove ${food.name}` : saved ? `Unsave ${food.name}` : `Save ${food.name}`,
					className: cn("absolute right-3 top-3 grid size-9 place-items-center rounded-full backdrop-blur transition-colors", saved ? "bg-lime text-lime-foreground" : "bg-card/90 text-forest hover:bg-lime"),
					children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col p-4",
			children: [
				metadata.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.7rem] uppercase tracking-wider text-muted-foreground",
					children: metadata.join(" · ")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-xl leading-tight",
					children: food.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: [
						qualityLabel,
						" · ",
						servingLabel
					]
				}),
				showReason && recommendation?.source === "demo" && recommendation.reason && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-xs leading-relaxed text-muted-foreground",
					children: recommendation.reason
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-5 gap-1 rounded-lg bg-muted/70 py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Macro, {
							label: "kcal",
							value: food.nutrition.caloriesKcal,
							unit: " kcal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Macro, {
							label: "Protein",
							value: food.nutrition.proteinG
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Macro, {
							label: "Carbs",
							value: food.nutrition.carbohydrateG
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Macro, {
							label: "Fat",
							value: food.nutrition.fatG
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Macro, {
							label: "Fibre",
							value: food.nutrition.fiberG
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/foods/$foodId",
					params: { foodId: food.id },
					className: "mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary hover:text-forest",
					children: ["View details ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" })]
				})
			]
		})]
	});
}
//#endregion
export { FoodImage as n, recommendationService as r, FoodCard as t };
