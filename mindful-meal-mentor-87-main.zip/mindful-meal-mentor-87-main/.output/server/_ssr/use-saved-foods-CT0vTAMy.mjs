import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as foodDataService } from "./food-data-service-ig-qFVcp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-saved-foods-CT0vTAMy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Ctx = (0, import_react.createContext)(null);
function SavedFoodsProvider({ children }) {
	const [saved, setSaved] = (0, import_react.useState)([
		"lentil-salad",
		"paneer-tikka",
		"moong-chilla"
	]);
	const toggle = (0, import_react.useCallback)((id) => {
		setSaved((s) => {
			const has = s.includes(id);
			const name = foodDataService.getById(id)?.name ?? "Food";
			toast(has ? `${name} removed` : `${name} saved`, { description: "Demo only — not stored yet." });
			return has ? s.filter((x) => x !== id) : [...s, id];
		});
	}, []);
	const remove = (0, import_react.useCallback)((id) => setSaved((s) => s.filter((x) => x !== id)), []);
	const value = (0, import_react.useMemo)(() => ({
		saved,
		isSaved: (id) => saved.includes(id),
		toggle,
		remove
	}), [
		saved,
		toggle,
		remove
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value,
		children
	});
}
function useSavedFoods() {
	const c = (0, import_react.useContext)(Ctx);
	if (!c) throw new Error("useSavedFoods must be used within SavedFoodsProvider");
	return c;
}
//#endregion
export { useSavedFoods as n, SavedFoodsProvider as t };
