import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as getFoodNutritionPer100g, n as filterFoods } from "./food-data-service-ig-qFVcp.mjs";
import { r as recommendationService } from "./FoodCard-DBah2pwS.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FoodFilters-D5cF2aTN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var defaultFilters = {
	q: "",
	cuisine: "all",
	category: "all",
	diet: "all",
	meal: "all",
	allergens: "",
	maxCal: 700,
	minProtein: 0,
	sort: "match"
};
function sortFoodResults(foods, sort) {
	const sorted = [...foods];
	if (sort === "match") sorted.sort((a, b) => (recommendationService.getForFood(b.id)?.score ?? -1) - (recommendationService.getForFood(a.id)?.score ?? -1));
	if (sort === "name-asc") sorted.sort((a, b) => a.name.localeCompare(b.name));
	if (sort === "calories-asc") sorted.sort((a, b) => (getFoodNutritionPer100g(a).caloriesKcal ?? Infinity) - (getFoodNutritionPer100g(b).caloriesKcal ?? Infinity));
	if (sort === "protein-desc") sorted.sort((a, b) => (getFoodNutritionPer100g(b).proteinG ?? -Infinity) - (getFoodNutritionPer100g(a).proteinG ?? -Infinity));
	if (sort === "price-asc") sorted.sort((a, b) => (a.priceInr ?? Infinity) - (b.priceInr ?? Infinity));
	return sorted;
}
/** Local filtering over SAMPLE data — the real dataset will be filtered server-side. */
function useFoodFilter(foods) {
	const [f, setF] = (0, import_react.useState)(defaultFilters);
	return {
		f,
		setF,
		results: (0, import_react.useMemo)(() => {
			return sortFoodResults(filterFoods(foods, {
				query: f.q,
				cuisine: f.cuisine,
				category: f.category === "all" ? "all" : f.category,
				diet: f.diet,
				meal: f.meal,
				...f.maxCal < 700 ? { maxCalories: f.maxCal } : {},
				...f.minProtein > 0 ? { minProtein: f.minProtein } : {},
				allergensToAvoid: f.allergens.split(",")
			}), f.sort);
		}, [foods, f]),
		reset: () => setF({ ...defaultFilters })
	};
}
function FilterSelect({ value, onChange, placeholder, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
		value,
		onValueChange: onChange,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
			className: "h-10 rounded-full bg-card",
			"aria-label": placeholder,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
			value: "all",
			children: ["All ", placeholder.toLowerCase()]
		}), options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: o,
			children: o
		}, o))] })]
	});
}
function SortSelect({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
		value,
		onValueChange: (v) => onChange(v),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
			className: "h-10 w-[190px] rounded-full bg-card",
			"aria-label": "Sort",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: "match",
				children: "Sample match score (demo)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: "name-asc",
				children: "Name: A to Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: "calories-asc",
				children: "Calories per 100 g: low to high"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: "protein-desc",
				children: "Protein per 100 g: high to low"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: "price-asc",
				children: "Price: low to high"
			})
		] })]
	});
}
//#endregion
export { SortSelect as n, useFoodFilter as r, FilterSelect as t };
