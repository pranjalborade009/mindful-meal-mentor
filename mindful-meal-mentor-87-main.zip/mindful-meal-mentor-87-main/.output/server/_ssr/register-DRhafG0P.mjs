import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { A as EyeOff, k as Eye } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-BuPsPhsM.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as Field, t as AuthLayout } from "./AuthLayout-4bq3yTtf.mjs";
import { t as Checkbox } from "./checkbox-kt6FvQcE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-DRhafG0P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RegisterPage() {
	const [show, setShow] = (0, import_react.useState)(false);
	const [pw, setPw] = (0, import_react.useState)("");
	const [pw2, setPw2] = (0, import_react.useState)("");
	const [terms, setTerms] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)({});
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthLayout, {
		title: "Create your account",
		subtitle: "Start building your nutrition profile.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (e) => {
				e.preventDefault();
				const next = {};
				if (pw.length < 8) next["pw"] = "Use at least 8 characters.";
				if (pw !== pw2) next["pw2"] = "Passwords do not match.";
				if (!terms) next["terms"] = "Please accept the terms to continue.";
				setErrors(next);
				if (Object.keys(next).length) return;
				toast("Demo account created", { description: "Nothing was stored — registration comes in a later phase." });
				navigate({ to: "/profile" });
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "name",
					label: "Full name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "name",
						placeholder: "Your name",
						className: "h-11 bg-card"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "email",
					label: "Email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "email",
						type: "email",
						placeholder: "you@example.com",
						className: "h-11 bg-card"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "pw",
					label: "Password",
					error: errors["pw"],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "pw",
							type: show ? "text" : "password",
							value: pw,
							onChange: (e) => setPw(e.target.value),
							className: "h-11 bg-card pr-10"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setShow(!show),
							"aria-label": show ? "Hide password" : "Show password",
							className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-forest",
							children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "pw2",
					label: "Confirm password",
					error: errors["pw2"],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "pw2",
						type: show ? "text" : "password",
						value: pw2,
						onChange: (e) => setPw2(e.target.value),
						className: "h-11 bg-card"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-start gap-2 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: terms,
						onCheckedChange: (v) => setTerms(!!v),
						className: "mt-0.5"
					}), "I agree to the terms and understand recommendations are informational only."]
				}), errors["terms"] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-destructive",
					children: errors["terms"]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "forest",
					size: "lg",
					className: "w-full",
					children: "Create Account"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-center text-sm text-muted-foreground",
					children: ["Already have an account? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "font-medium text-primary hover:underline",
						children: "Log in"
					})]
				})
			]
		})
	});
}
//#endregion
export { RegisterPage as component };
