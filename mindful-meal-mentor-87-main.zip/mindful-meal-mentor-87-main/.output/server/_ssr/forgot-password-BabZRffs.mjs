import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { J as ArrowLeft, v as MailCheck } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-BuPsPhsM.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as Field, t as AuthLayout } from "./AuthLayout-4bq3yTtf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forgot-password-BabZRffs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ForgotPage() {
	const [sent, setSent] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthLayout, {
		title: "Forgot password?",
		subtitle: "Enter the email linked to your account and we'll send a reset link.",
		children: [sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border bg-card p-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailCheck, { className: "mx-auto size-8 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-medium text-forest",
					children: "Demo: reset link not actually sent"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Email delivery will be added in a later phase."
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-5",
			onSubmit: (e) => {
				e.preventDefault();
				setSent(true);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "email",
				label: "Email address",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "email",
					type: "email",
					required: true,
					placeholder: "you@example.com",
					className: "h-11 bg-card"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "forest",
				size: "lg",
				className: "w-full",
				children: "Send Reset Link"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/login",
			className: "mt-6 inline-flex items-center gap-1.5 text-sm text-primary hover:underline",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Return to login"]
		})]
	});
}
//#endregion
export { ForgotPage as component };
