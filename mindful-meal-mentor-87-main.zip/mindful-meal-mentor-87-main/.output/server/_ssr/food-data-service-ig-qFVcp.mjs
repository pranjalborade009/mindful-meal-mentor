import { t as hero_meal_default } from "./hero-meal-BzPMHyun.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/food-data-service-ig-qFVcp.js
var food_paneer_default = "/assets/food-paneer-gl9jMjJM.jpg";
var food_yogurt_default = "/assets/food-yogurt-CLeXujBT.jpg";
var food_lentil_default = "/assets/food-lentil-CJbMgiC6.jpg";
var food_khichdi_default = "/assets/food-khichdi-D50LqOAS.jpg";
var food_tofu_default = "/assets/food-tofu-Di_n_vUD.jpg";
var food_chicken_default = "/assets/food-chicken-DJUJwxVR.jpg";
var food_chilla_default = "/assets/food-chilla-n6Z9GcwE.jpg";
var demoNutritionProvenance = {
	sourceName: "Prototype demo values (unverified)",
	sourceType: "demo",
	note: "Illustrative sample values only; not checked against a validated nutrition dataset."
};
/**
* SAMPLE UI DATA — illustrative values for the prototype only.
* Replace with records from the validated nutritional dataset / backend API.
*/
var demoFoods = [
	{
		id: "salmon-quinoa-bowl",
		name: "Salmon Quinoa Bowl",
		cuisine: "Mediterranean",
		meal: "Lunch",
		category: "dish",
		diet: "Non-vegetarian",
		dietaryLabels: ["Non-vegetarian"],
		allergens: null,
		allergenDataStatus: "unknown",
		image: hero_meal_default,
		source: "demo",
		nutrition: {
			servingSize: {
				quantity: 380,
				unit: "g",
				description: "1 bowl"
			},
			basis: "per-serving",
			caloriesKcal: 520,
			proteinG: 34,
			carbohydrateG: 42,
			fatG: 22,
			fiberG: 9
		},
		nutritionDataQuality: "estimated",
		nutritionProvenance: demoNutritionProvenance,
		priceInr: 420,
		ingredients: [
			"Salmon",
			"Quinoa",
			"Kale",
			"Avocado",
			"Chickpeas",
			"Lime"
		]
	},
	{
		id: "paneer-tikka",
		name: "Paneer Tikka",
		cuisine: "Indian",
		meal: "Dinner",
		category: "dish",
		diet: "Vegetarian",
		dietaryLabels: ["Vegetarian"],
		allergens: null,
		allergenDataStatus: "unknown",
		image: food_paneer_default,
		source: "demo",
		nutrition: {
			servingSize: {
				quantity: 200,
				unit: "g",
				description: "6 pieces"
			},
			basis: "per-serving",
			caloriesKcal: 340,
			proteinG: 22,
			carbohydrateG: 12,
			fatG: 22,
			fiberG: 3
		},
		nutritionDataQuality: "estimated",
		nutritionProvenance: demoNutritionProvenance,
		priceInr: 260,
		ingredients: [
			"Paneer",
			"Bell pepper",
			"Onion",
			"Yogurt marinade",
			"Mint chutney"
		]
	},
	{
		id: "greek-yogurt-bowl",
		name: "Greek Yogurt & Berries",
		cuisine: "Continental",
		meal: "Breakfast",
		category: "dish",
		diet: "Vegetarian",
		dietaryLabels: ["Vegetarian"],
		allergens: null,
		allergenDataStatus: "unknown",
		image: food_yogurt_default,
		source: "demo",
		nutrition: {
			servingSize: {
				quantity: 250,
				unit: "g",
				description: "1 bowl"
			},
			basis: "per-serving",
			caloriesKcal: 290,
			proteinG: 18,
			carbohydrateG: 38,
			fatG: 7,
			fiberG: 6
		},
		nutritionDataQuality: "estimated",
		nutritionProvenance: demoNutritionProvenance,
		priceInr: 180,
		ingredients: [
			"Greek yogurt",
			"Oats",
			"Berries",
			"Honey"
		]
	},
	{
		id: "lentil-salad",
		name: "Mediterranean Lentil Salad",
		cuisine: "Mediterranean",
		meal: "Lunch",
		category: "dish",
		diet: "Vegetarian",
		dietaryLabels: ["Vegetarian"],
		allergens: null,
		allergenDataStatus: "unknown",
		image: food_lentil_default,
		source: "demo",
		nutrition: {
			servingSize: {
				quantity: 300,
				unit: "g",
				description: "1 bowl"
			},
			basis: "per-serving",
			caloriesKcal: 360,
			proteinG: 19,
			carbohydrateG: 44,
			fatG: 12,
			fiberG: 13
		},
		nutritionDataQuality: "estimated",
		nutritionProvenance: demoNutritionProvenance,
		priceInr: 220,
		ingredients: [
			"Green lentils",
			"Cucumber",
			"Tomato",
			"Feta",
			"Parsley"
		]
	},
	{
		id: "millet-khichdi",
		name: "Vegetable Millet Khichdi",
		cuisine: "Indian",
		meal: "Dinner",
		category: "dish",
		diet: "Vegetarian",
		dietaryLabels: ["Vegetarian"],
		allergens: null,
		allergenDataStatus: "unknown",
		image: food_khichdi_default,
		source: "demo",
		nutrition: {
			servingSize: {
				quantity: 320,
				unit: "g",
				description: "1 bowl"
			},
			basis: "per-serving",
			caloriesKcal: 380,
			proteinG: 13,
			carbohydrateG: 58,
			fatG: 10,
			fiberG: 8
		},
		nutritionDataQuality: "estimated",
		nutritionProvenance: demoNutritionProvenance,
		priceInr: 150,
		ingredients: [
			"Foxtail millet",
			"Moong dal",
			"Peas",
			"Carrot",
			"Ghee"
		]
	},
	{
		id: "tofu-stir-fry",
		name: "Tofu Broccoli Stir-fry",
		cuisine: "East Asian",
		meal: "Dinner",
		category: "dish",
		diet: "Vegan",
		dietaryLabels: ["Vegan"],
		allergens: null,
		allergenDataStatus: "unknown",
		image: food_tofu_default,
		source: "demo",
		nutrition: {
			servingSize: {
				quantity: 340,
				unit: "g",
				description: "1 bowl"
			},
			basis: "per-serving",
			caloriesKcal: 410,
			proteinG: 24,
			carbohydrateG: 46,
			fatG: 14,
			fiberG: 7
		},
		nutritionDataQuality: "estimated",
		nutritionProvenance: demoNutritionProvenance,
		priceInr: 240,
		ingredients: [
			"Tofu",
			"Broccoli",
			"Brown rice",
			"Sesame",
			"Soy glaze"
		]
	},
	{
		id: "grilled-chicken-plate",
		name: "Grilled Chicken & Sweet Potato",
		cuisine: "Continental",
		meal: "Lunch",
		category: "dish",
		diet: "Non-vegetarian",
		dietaryLabels: ["Non-vegetarian"],
		allergens: null,
		allergenDataStatus: "unknown",
		image: food_chicken_default,
		source: "demo",
		nutrition: {
			servingSize: {
				quantity: 360,
				unit: "g",
				description: "1 plate"
			},
			basis: "per-serving",
			caloriesKcal: 470,
			proteinG: 42,
			carbohydrateG: 40,
			fatG: 12,
			fiberG: 7
		},
		nutritionDataQuality: "estimated",
		nutritionProvenance: demoNutritionProvenance,
		priceInr: 320,
		ingredients: [
			"Chicken breast",
			"Sweet potato",
			"Green beans",
			"Herbs"
		]
	},
	{
		id: "moong-chilla",
		name: "Moong Dal Chilla",
		cuisine: "Indian",
		meal: "Breakfast",
		category: "dish",
		diet: "Vegan",
		dietaryLabels: ["Vegan"],
		allergens: null,
		allergenDataStatus: "unknown",
		image: food_chilla_default,
		source: "demo",
		nutrition: {
			servingSize: {
				quantity: 180,
				unit: "g",
				description: "2 pieces"
			},
			basis: "per-serving",
			caloriesKcal: 260,
			proteinG: 15,
			carbohydrateG: 34,
			fatG: 6,
			fiberG: 6
		},
		nutritionDataQuality: "estimated",
		nutritionProvenance: demoNutritionProvenance,
		priceInr: 120,
		ingredients: [
			"Moong dal",
			"Ginger",
			"Coriander",
			"Tomato chutney"
		]
	}
];
var usdaFoundationFoods = [
	{
		"id": "usda-fdc-2262074",
		"name": "Almond butter, creamy",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 603,
			"proteinG": 20.8,
			"carbohydrateG": 21.2,
			"fatG": 53,
			"fiberG": 9.72,
			"micronutrients": {
				"calcium": {
					"value": 264,
					"unit": "mg"
				},
				"iron": {
					"value": 4.11,
					"unit": "mg"
				},
				"magnesium": {
					"value": 268,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 507,
					"unit": "mg"
				},
				"potassium": {
					"value": 745,
					"unit": "mg"
				},
				"sodium": {
					"value": .996,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.18,
					"unit": "mg"
				},
				"copper": {
					"value": .975,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.14,
					"unit": "mg"
				},
				"selenium": {
					"value": .794,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 16.7,
					"unit": "mg"
				},
				"thiamin": {
					"value": .095,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.91,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .084,
					"unit": "mg"
				},
				"folate": {
					"value": 42.5,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2262074/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2262074,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2257045",
		"name": "Almond milk, unsweetened, plain, refrigerated",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 19.3,
			"proteinG": .656,
			"carbohydrateG": .671,
			"fatG": 1.56,
			"fiberG": 0,
			"micronutrients": {
				"calcium": {
					"value": 158,
					"unit": "mg"
				},
				"iron": {
					"value": .125,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.25,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 19.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 49.3,
					"unit": "mg"
				},
				"sodium": {
					"value": 59.2,
					"unit": "mg"
				},
				"zinc": {
					"value": .077,
					"unit": "mg"
				},
				"copper": {
					"value": .027,
					"unit": "mg"
				},
				"manganese": {
					"value": .056,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 1.59,
					"unit": "µg"
				},
				"thiamin": {
					"value": .005,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .083,
					"unit": "mg"
				},
				"niacin": {
					"value": .089,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": 0,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .449,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2257045/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2257045,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-1999631",
		"name": "Almond milk, unsweetened, plain, shelf stable",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 14.6,
			"proteinG": .555,
			"carbohydrateG": .337,
			"fatG": 1.22,
			"fiberG": 0,
			"micronutrients": {
				"calcium": {
					"value": 173,
					"unit": "mg"
				},
				"iron": {
					"value": .29,
					"unit": "mg"
				},
				"magnesium": {
					"value": 6.78,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 29.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 30.8,
					"unit": "mg"
				},
				"sodium": {
					"value": 59.6,
					"unit": "mg"
				},
				"zinc": {
					"value": .172,
					"unit": "mg"
				},
				"copper": {
					"value": .021,
					"unit": "mg"
				},
				"manganese": {
					"value": .045,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 41.4,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 3.32,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .927,
					"unit": "µg"
				},
				"thiamin": {
					"value": 0,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .033,
					"unit": "mg"
				},
				"niacin": {
					"value": .074,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": 0,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .338,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999631/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999631,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2747652",
		"name": "Anchovies, canned in olive oil, with salt, drained",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 206,
			"proteinG": 26.9,
			"carbohydrateG": 2.41,
			"fatG": 9.85,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 240,
					"unit": "mg"
				},
				"iron": {
					"value": 2.69,
					"unit": "mg"
				},
				"magnesium": {
					"value": 228,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 226,
					"unit": "mg"
				},
				"potassium": {
					"value": 298,
					"unit": "mg"
				},
				"sodium": {
					"value": 5400,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.54,
					"unit": "mg"
				},
				"copper": {
					"value": .235,
					"unit": "mg"
				},
				"manganese": {
					"value": .138,
					"unit": "mg"
				},
				"selenium": {
					"value": 48.2,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 12.6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747652/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747652,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2003590",
		"name": "Apple juice, with added vitamin C, from concentrate, shelf stable",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 47.2,
			"proteinG": .086,
			"carbohydrateG": 11.4,
			"fatG": .286,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 7.1,
					"unit": "mg"
				},
				"iron": {
					"value": .04,
					"unit": "mg"
				},
				"magnesium": {
					"value": 4.86,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 5.99,
					"unit": "mg"
				},
				"potassium": {
					"value": 95.9,
					"unit": "mg"
				},
				"sodium": {
					"value": 4.87,
					"unit": "mg"
				},
				"zinc": {
					"value": .002,
					"unit": "mg"
				},
				"copper": {
					"value": .003,
					"unit": "mg"
				},
				"manganese": {
					"value": .027,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 51.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": .01,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .014,
					"unit": "mg"
				},
				"folate": {
					"value": 3.09,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003590/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003590,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-1750340",
		"name": "Apples, fuji, with skin, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 58.2,
			"proteinG": .148,
			"carbohydrateG": 15.7,
			"fatG": .162,
			"fiberG": 2.08,
			"micronutrients": {
				"calcium": {
					"value": 5.98,
					"unit": "mg"
				},
				"iron": {
					"value": .015,
					"unit": "mg"
				},
				"magnesium": {
					"value": 4.67,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 9.78,
					"unit": "mg"
				},
				"potassium": {
					"value": 104,
					"unit": "mg"
				},
				"sodium": {
					"value": 1.01,
					"unit": "mg"
				},
				"zinc": {
					"value": .017,
					"unit": "mg"
				},
				"copper": {
					"value": .033,
					"unit": "mg"
				},
				"manganese": {
					"value": .033,
					"unit": "mg"
				},
				"thiamin": {
					"value": .006,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .068,
					"unit": "mg"
				},
				"niacin": {
					"value": .091,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .035,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750340/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750340,
			"release": "10/30/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-1750341",
		"name": "Apples, gala, with skin, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 54.9,
			"proteinG": .133,
			"carbohydrateG": 14.8,
			"fatG": .15,
			"fiberG": 2.11,
			"micronutrients": {
				"calcium": {
					"value": 6.64,
					"unit": "mg"
				},
				"iron": {
					"value": .06,
					"unit": "mg"
				},
				"magnesium": {
					"value": 4.95,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 8.44,
					"unit": "mg"
				},
				"potassium": {
					"value": 106,
					"unit": "mg"
				},
				"sodium": {
					"value": .279,
					"unit": "mg"
				},
				"zinc": {
					"value": .024,
					"unit": "mg"
				},
				"copper": {
					"value": .034,
					"unit": "mg"
				},
				"manganese": {
					"value": .04,
					"unit": "mg"
				},
				"thiamin": {
					"value": .011,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .069,
					"unit": "mg"
				},
				"niacin": {
					"value": .089,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .032,
					"unit": "mg"
				},
				"folate": {
					"value": .812,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750341/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750341,
			"release": "10/30/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-1750342",
		"name": "Apples, granny smith, with skin, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 53,
			"proteinG": .266,
			"carbohydrateG": 14.1,
			"fatG": .138,
			"fiberG": 2.51,
			"micronutrients": {
				"calcium": {
					"value": 5.48,
					"unit": "mg"
				},
				"iron": {
					"value": .07,
					"unit": "mg"
				},
				"magnesium": {
					"value": 5.06,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 9.86,
					"unit": "mg"
				},
				"potassium": {
					"value": 116,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .023,
					"unit": "mg"
				},
				"copper": {
					"value": .035,
					"unit": "mg"
				},
				"manganese": {
					"value": .039,
					"unit": "mg"
				},
				"thiamin": {
					"value": .017,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .075,
					"unit": "mg"
				},
				"niacin": {
					"value": .11,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .028,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750342/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750342,
			"release": "10/30/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-1750343",
		"name": "Apples, honeycrisp, with skin, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 54,
			"proteinG": .102,
			"carbohydrateG": 14.7,
			"fatG": .1,
			"fiberG": 1.72,
			"micronutrients": {
				"calcium": {
					"value": 3.87,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 4.15,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 7.85,
					"unit": "mg"
				},
				"potassium": {
					"value": 98,
					"unit": "mg"
				},
				"sodium": {
					"value": .138,
					"unit": "mg"
				},
				"zinc": {
					"value": .018,
					"unit": "mg"
				},
				"copper": {
					"value": .023,
					"unit": "mg"
				},
				"manganese": {
					"value": .04,
					"unit": "mg"
				},
				"thiamin": {
					"value": .009,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .074,
					"unit": "mg"
				},
				"niacin": {
					"value": .074,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .033,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750343/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750343,
			"release": "10/30/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-1750339",
		"name": "Apples, red delicious, with skin, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 55.6,
			"proteinG": .188,
			"carbohydrateG": 14.8,
			"fatG": .212,
			"fiberG": 2.04,
			"micronutrients": {
				"calcium": {
					"value": 4.66,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 4.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 9.18,
					"unit": "mg"
				},
				"potassium": {
					"value": 95.3,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .02,
					"unit": "mg"
				},
				"copper": {
					"value": .024,
					"unit": "mg"
				},
				"manganese": {
					"value": .029,
					"unit": "mg"
				},
				"thiamin": {
					"value": .009,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .066,
					"unit": "mg"
				},
				"niacin": {
					"value": .09,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .021,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750339/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750339,
			"release": "10/30/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2346414",
		"name": "Applesauce, unsweetened, with added vitamin C",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 46.4,
			"proteinG": .273,
			"carbohydrateG": 12.3,
			"fatG": .162,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 3.82,
					"unit": "mg"
				},
				"iron": {
					"value": .045,
					"unit": "mg"
				},
				"magnesium": {
					"value": 3.94,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 9.12,
					"unit": "mg"
				},
				"potassium": {
					"value": 108,
					"unit": "mg"
				},
				"sodium": {
					"value": .504,
					"unit": "mg"
				},
				"zinc": {
					"value": .003,
					"unit": "mg"
				},
				"copper": {
					"value": .039,
					"unit": "mg"
				},
				"manganese": {
					"value": .037,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 43.7,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346414/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346414,
			"release": "10/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710815",
		"name": "Apricot, with skin, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 43.5,
			"proteinG": .961,
			"carbohydrateG": 10.2,
			"fatG": .405,
			"fiberG": 1.51,
			"micronutrients": {
				"calcium": {
					"value": 11.6,
					"unit": "mg"
				},
				"iron": {
					"value": .163,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.88,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 22.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 231,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .148,
					"unit": "mg"
				},
				"copper": {
					"value": .056,
					"unit": "mg"
				},
				"manganese": {
					"value": .054,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 3.07,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710815/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710815,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710822",
		"name": "Arugula, baby, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 25.9,
			"proteinG": 1.65,
			"carbohydrateG": 5.37,
			"fatG": .325,
			"fiberG": 2.28,
			"micronutrients": {
				"calcium": {
					"value": 204,
					"unit": "mg"
				},
				"iron": {
					"value": 1.39,
					"unit": "mg"
				},
				"magnesium": {
					"value": 42.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 51.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 407,
					"unit": "mg"
				},
				"sodium": {
					"value": 86.9,
					"unit": "mg"
				},
				"zinc": {
					"value": .348,
					"unit": "mg"
				},
				"copper": {
					"value": .083,
					"unit": "mg"
				},
				"manganese": {
					"value": .514,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 101,
					"unit": "mg"
				},
				"folate": {
					"value": 149,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710822/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710822,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2710823",
		"name": "Asparagus, green, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 23.5,
			"proteinG": 1.44,
			"carbohydrateG": 5.1,
			"fatG": .216,
			"fiberG": 1.88,
			"micronutrients": {
				"calcium": {
					"value": 20.6,
					"unit": "mg"
				},
				"iron": {
					"value": .444,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 53.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 278,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.46,
					"unit": "mg"
				},
				"zinc": {
					"value": .596,
					"unit": "mg"
				},
				"copper": {
					"value": .132,
					"unit": "mg"
				},
				"manganese": {
					"value": .146,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 9.15,
					"unit": "mg"
				},
				"thiamin": {
					"value": .069,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.08,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .112,
					"unit": "mg"
				},
				"folate": {
					"value": 182,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710823/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710823,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2710824",
		"name": "Avocado, Hass, peeled, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 206,
			"proteinG": 1.81,
			"carbohydrateG": 8.32,
			"fatG": 20.3,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 14.5,
					"unit": "mg"
				},
				"iron": {
					"value": .613,
					"unit": "mg"
				},
				"magnesium": {
					"value": 32.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 42.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 576,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .46,
					"unit": "mg"
				},
				"copper": {
					"value": .285,
					"unit": "mg"
				},
				"manganese": {
					"value": .197,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .167,
					"unit": "mg"
				},
				"folate": {
					"value": 129,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710824/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710824,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-1105073",
		"name": "Bananas, overripe, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 85,
			"proteinG": .73,
			"carbohydrateG": 20.1,
			"fatG": .22,
			"fiberG": 1.7,
			"micronutrients": {
				"vitaminA": {
					"value": 1,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 9.7,
					"unit": "mg"
				},
				"thiamin": {
					"value": .04,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": .57,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .234,
					"unit": "mg"
				},
				"folate": {
					"value": 25,
					"unit": "µg"
				},
				"vitaminK": {
					"value": .2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1105073/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1105073,
			"release": "4/1/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 Peeled Banana",
			"weightGrams": 110
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-1105314",
		"name": "Bananas, ripe and slightly ripe, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 97,
			"proteinG": .74,
			"carbohydrateG": 23,
			"fatG": .29,
			"fiberG": 1.7,
			"micronutrients": {
				"calcium": {
					"value": 5,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 28,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 22,
					"unit": "mg"
				},
				"potassium": {
					"value": 326,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .16,
					"unit": "mg"
				},
				"copper": {
					"value": .101,
					"unit": "mg"
				},
				"manganese": {
					"value": .258,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 1,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 12.3,
					"unit": "mg"
				},
				"thiamin": {
					"value": .056,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": .662,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .209,
					"unit": "mg"
				},
				"folate": {
					"value": 14,
					"unit": "µg"
				},
				"vitaminK": {
					"value": .1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1105314/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1105314,
			"release": "4/1/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 Peeled Banana",
			"weightGrams": 115
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2644285",
		"name": "Beans, black, canned, sodium added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 115,
			"proteinG": 6.91,
			"carbohydrateG": 19.8,
			"fatG": 1.27,
			"fiberG": 6.69,
			"micronutrients": {
				"calcium": {
					"value": 43.3,
					"unit": "mg"
				},
				"iron": {
					"value": 1.69,
					"unit": "mg"
				},
				"magnesium": {
					"value": 32.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 91,
					"unit": "mg"
				},
				"potassium": {
					"value": 253,
					"unit": "mg"
				},
				"sodium": {
					"value": 218,
					"unit": "mg"
				},
				"zinc": {
					"value": .74,
					"unit": "mg"
				},
				"copper": {
					"value": .336,
					"unit": "mg"
				},
				"manganese": {
					"value": .332,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644285/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644285,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2644287",
		"name": "Beans, cannellini, canned, sodium added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 112,
			"proteinG": 7.41,
			"carbohydrateG": 18.8,
			"fatG": 1.17,
			"fiberG": 6.76,
			"micronutrients": {
				"calcium": {
					"value": 69.2,
					"unit": "mg"
				},
				"iron": {
					"value": 1.4,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 94.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 203,
					"unit": "mg"
				},
				"sodium": {
					"value": 164,
					"unit": "mg"
				},
				"zinc": {
					"value": .516,
					"unit": "mg"
				},
				"copper": {
					"value": .219,
					"unit": "mg"
				},
				"manganese": {
					"value": .369,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644287/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644287,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2644281",
		"name": "Beans, cannellini, dry",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 337,
			"proteinG": 21.6,
			"carbohydrateG": 59.8,
			"fatG": 2.2,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 143,
					"unit": "mg"
				},
				"iron": {
					"value": 6.67,
					"unit": "mg"
				},
				"magnesium": {
					"value": 154,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 412,
					"unit": "mg"
				},
				"potassium": {
					"value": 1420,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.72,
					"unit": "mg"
				},
				"copper": {
					"value": .742,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.78,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644281/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644281,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 35
		}]
	},
	{
		"id": "usda-fdc-747444",
		"name": "Beans, Dry, Black (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 24.4,
			"carbohydrateG": null,
			"fatG": 1.45,
			"fiberG": 4.2,
			"micronutrients": {
				"calcium": {
					"value": 191,
					"unit": "mg"
				},
				"iron": {
					"value": 5.34,
					"unit": "mg"
				},
				"magnesium": {
					"value": 180,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 522,
					"unit": "mg"
				},
				"potassium": {
					"value": 1540,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.37,
					"unit": "mg"
				},
				"copper": {
					"value": 1.12,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.08,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747444/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747444,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747433",
		"name": "Beans, Dry, Brown (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 25.6,
			"carbohydrateG": null,
			"fatG": 1.12,
			"fiberG": 4.1,
			"micronutrients": {
				"calcium": {
					"value": 158,
					"unit": "mg"
				},
				"iron": {
					"value": 4.7,
					"unit": "mg"
				},
				"magnesium": {
					"value": 158,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 543,
					"unit": "mg"
				},
				"potassium": {
					"value": 1580,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.71,
					"unit": "mg"
				},
				"copper": {
					"value": 1.03,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.87,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747433/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747433,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747436",
		"name": "Beans, Dry, Carioca (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 25.2,
			"carbohydrateG": null,
			"fatG": 1.44,
			"fiberG": 4.5,
			"micronutrients": {
				"calcium": {
					"value": 194,
					"unit": "mg"
				},
				"iron": {
					"value": 5.87,
					"unit": "mg"
				},
				"magnesium": {
					"value": 179,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 535,
					"unit": "mg"
				},
				"potassium": {
					"value": 1390,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.36,
					"unit": "mg"
				},
				"copper": {
					"value": 1.04,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.93,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747436/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747436,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747437",
		"name": "Beans, Dry, Cranberry (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 24.4,
			"carbohydrateG": null,
			"fatG": 1.23,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 152,
					"unit": "mg"
				},
				"iron": {
					"value": 5.26,
					"unit": "mg"
				},
				"magnesium": {
					"value": 166,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 487,
					"unit": "mg"
				},
				"potassium": {
					"value": 1340,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.03,
					"unit": "mg"
				},
				"copper": {
					"value": .757,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.78,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747437/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747437,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747440",
		"name": "Beans, Dry, Dark Red Kidney (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 25.9,
			"carbohydrateG": null,
			"fatG": 1.31,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 98,
					"unit": "mg"
				},
				"iron": {
					"value": 6.58,
					"unit": "mg"
				},
				"magnesium": {
					"value": 164,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 612,
					"unit": "mg"
				},
				"potassium": {
					"value": 1490,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.29,
					"unit": "mg"
				},
				"copper": {
					"value": .865,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.67,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747440/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747440,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747432",
		"name": "Beans, Dry, Flor de Mayo (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 23.3,
			"carbohydrateG": null,
			"fatG": .86,
			"fiberG": 4,
			"micronutrients": {
				"calcium": {
					"value": 180,
					"unit": "mg"
				},
				"iron": {
					"value": 4.47,
					"unit": "mg"
				},
				"magnesium": {
					"value": 182,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 439,
					"unit": "mg"
				},
				"potassium": {
					"value": 1490,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.42,
					"unit": "mg"
				},
				"copper": {
					"value": .864,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.7,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747432/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747432,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747446",
		"name": "Beans, Dry, Great Northern (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 24.7,
			"carbohydrateG": null,
			"fatG": 1.24,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 192,
					"unit": "mg"
				},
				"iron": {
					"value": 5.48,
					"unit": "mg"
				},
				"magnesium": {
					"value": 176,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 519,
					"unit": "mg"
				},
				"potassium": {
					"value": 1520,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.45,
					"unit": "mg"
				},
				"copper": {
					"value": 1.08,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.9,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747446/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747446,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747438",
		"name": "Beans, Dry, Light Red Kidney (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 25,
			"carbohydrateG": null,
			"fatG": 1.03,
			"fiberG": 4.5,
			"micronutrients": {
				"calcium": {
					"value": 103,
					"unit": "mg"
				},
				"iron": {
					"value": 6.95,
					"unit": "mg"
				},
				"magnesium": {
					"value": 158,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 549,
					"unit": "mg"
				},
				"potassium": {
					"value": 1540,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.5,
					"unit": "mg"
				},
				"copper": {
					"value": .786,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.52,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747438/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747438,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747435",
		"name": "Beans, Dry, Light Tan (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 24.6,
			"carbohydrateG": null,
			"fatG": 1.28,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 98,
					"unit": "mg"
				},
				"iron": {
					"value": 7.29,
					"unit": "mg"
				},
				"magnesium": {
					"value": 178,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 571,
					"unit": "mg"
				},
				"potassium": {
					"value": 1230,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.23,
					"unit": "mg"
				},
				"copper": {
					"value": .932,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.69,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747435/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747435,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747430",
		"name": "Beans, Dry, Medium Red (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 25.5,
			"carbohydrateG": null,
			"fatG": 1.04,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 193,
					"unit": "mg"
				},
				"iron": {
					"value": 6.27,
					"unit": "mg"
				},
				"magnesium": {
					"value": 178,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 548,
					"unit": "mg"
				},
				"potassium": {
					"value": 1490,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.82,
					"unit": "mg"
				},
				"copper": {
					"value": 1.04,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.05,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747430/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747430,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747441",
		"name": "Beans, Dry, Navy (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 24.1,
			"carbohydrateG": null,
			"fatG": 1.51,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 229,
					"unit": "mg"
				},
				"iron": {
					"value": 5.29,
					"unit": "mg"
				},
				"magnesium": {
					"value": 180,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 523,
					"unit": "mg"
				},
				"potassium": {
					"value": 1470,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.31,
					"unit": "mg"
				},
				"copper": {
					"value": 1.14,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.22,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747441/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747441,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747439",
		"name": "Beans, Dry, Pink (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 23.4,
			"carbohydrateG": null,
			"fatG": 1.2,
			"fiberG": 4.1,
			"micronutrients": {
				"calcium": {
					"value": 137,
					"unit": "mg"
				},
				"iron": {
					"value": 5.46,
					"unit": "mg"
				},
				"magnesium": {
					"value": 164,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 491,
					"unit": "mg"
				},
				"potassium": {
					"value": 1490,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.26,
					"unit": "mg"
				},
				"copper": {
					"value": .947,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.7,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747439/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747439,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747445",
		"name": "Beans, Dry, Pinto (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 23.7,
			"carbohydrateG": null,
			"fatG": 1.24,
			"fiberG": 4.1,
			"micronutrients": {
				"calcium": {
					"value": 161,
					"unit": "mg"
				},
				"iron": {
					"value": 5.4,
					"unit": "mg"
				},
				"magnesium": {
					"value": 170,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 507,
					"unit": "mg"
				},
				"potassium": {
					"value": 1510,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.43,
					"unit": "mg"
				},
				"copper": {
					"value": .978,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.78,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747445/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747445,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747431",
		"name": "Beans, Dry, Red (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 21.3,
			"carbohydrateG": null,
			"fatG": 1.16,
			"fiberG": 4,
			"micronutrients": {
				"calcium": {
					"value": 148,
					"unit": "mg"
				},
				"iron": {
					"value": 5.05,
					"unit": "mg"
				},
				"magnesium": {
					"value": 152,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 380,
					"unit": "mg"
				},
				"potassium": {
					"value": 1540,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.84,
					"unit": "mg"
				},
				"copper": {
					"value": .959,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.93,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747431/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747431,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747443",
		"name": "Beans, Dry, Small Red (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 23.5,
			"carbohydrateG": null,
			"fatG": 1.28,
			"fiberG": 4.1,
			"micronutrients": {
				"calcium": {
					"value": 149,
					"unit": "mg"
				},
				"iron": {
					"value": 4.95,
					"unit": "mg"
				},
				"magnesium": {
					"value": 167,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 493,
					"unit": "mg"
				},
				"potassium": {
					"value": 1520,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.23,
					"unit": "mg"
				},
				"copper": {
					"value": .968,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.76,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747443/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747443,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747442",
		"name": "Beans, Dry, Small White (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 24.5,
			"carbohydrateG": null,
			"fatG": 1.32,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 236,
					"unit": "mg"
				},
				"iron": {
					"value": 4.93,
					"unit": "mg"
				},
				"magnesium": {
					"value": 182,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 533,
					"unit": "mg"
				},
				"potassium": {
					"value": 1540,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.54,
					"unit": "mg"
				},
				"copper": {
					"value": 1.05,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.07,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747442/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747442,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-747434",
		"name": "Beans, Dry, Tan (0% moisture)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 26.8,
			"carbohydrateG": null,
			"fatG": 1.14,
			"fiberG": 4.4,
			"micronutrients": {
				"calcium": {
					"value": 178,
					"unit": "mg"
				},
				"iron": {
					"value": 5.85,
					"unit": "mg"
				},
				"magnesium": {
					"value": 198,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 555,
					"unit": "mg"
				},
				"potassium": {
					"value": 1620,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.5,
					"unit": "mg"
				},
				"copper": {
					"value": 1.1,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.16,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747434/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747434,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2644294",
		"name": "Beans, great northern, canned, sodium added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 114,
			"proteinG": 7.03,
			"carbohydrateG": 19.3,
			"fatG": 1.27,
			"fiberG": 6.91,
			"micronutrients": {
				"calcium": {
					"value": 67.2,
					"unit": "mg"
				},
				"iron": {
					"value": 1.38,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 88.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 213,
					"unit": "mg"
				},
				"sodium": {
					"value": 223,
					"unit": "mg"
				},
				"zinc": {
					"value": .635,
					"unit": "mg"
				},
				"copper": {
					"value": .256,
					"unit": "mg"
				},
				"manganese": {
					"value": .463,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644294/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644294,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2644289",
		"name": "Beans, kidney, dark red, canned, sodium added, sugar added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 123,
			"proteinG": 7.8,
			"carbohydrateG": 21,
			"fatG": 1.26,
			"fiberG": 7.01,
			"micronutrients": {
				"calcium": {
					"value": 56.9,
					"unit": "mg"
				},
				"iron": {
					"value": 1.44,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 104,
					"unit": "mg"
				},
				"potassium": {
					"value": 227,
					"unit": "mg"
				},
				"sodium": {
					"value": 172,
					"unit": "mg"
				},
				"zinc": {
					"value": .56,
					"unit": "mg"
				},
				"copper": {
					"value": .273,
					"unit": "mg"
				},
				"manganese": {
					"value": .328,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644289/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644289,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2644290",
		"name": "Beans, kidney, light red, canned, sodium added, sugar added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 124,
			"proteinG": 7.31,
			"carbohydrateG": 21.4,
			"fatG": 1.3,
			"fiberG": 7.4,
			"micronutrients": {
				"calcium": {
					"value": 60.2,
					"unit": "mg"
				},
				"iron": {
					"value": 1.3,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 93.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 209,
					"unit": "mg"
				},
				"sodium": {
					"value": 158,
					"unit": "mg"
				},
				"zinc": {
					"value": .526,
					"unit": "mg"
				},
				"copper": {
					"value": .271,
					"unit": "mg"
				},
				"manganese": {
					"value": .345,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644290/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644290,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2644286",
		"name": "Beans, navy, canned, sodium added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 116,
			"proteinG": 6.57,
			"carbohydrateG": 20,
			"fatG": 1.4,
			"fiberG": 6.85,
			"micronutrients": {
				"calcium": {
					"value": 63.9,
					"unit": "mg"
				},
				"iron": {
					"value": 1.6,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 86.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 184,
					"unit": "mg"
				},
				"sodium": {
					"value": 190,
					"unit": "mg"
				},
				"zinc": {
					"value": .631,
					"unit": "mg"
				},
				"copper": {
					"value": .29,
					"unit": "mg"
				},
				"manganese": {
					"value": .377,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644286/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644286,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2644292",
		"name": "Beans, pinto, canned, sodium added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 114,
			"proteinG": 6.69,
			"carbohydrateG": 19.6,
			"fatG": 1.27,
			"fiberG": 7.09,
			"micronutrients": {
				"calcium": {
					"value": 55.2,
					"unit": "mg"
				},
				"iron": {
					"value": 1.28,
					"unit": "mg"
				},
				"magnesium": {
					"value": 27.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 83.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 210,
					"unit": "mg"
				},
				"sodium": {
					"value": 202,
					"unit": "mg"
				},
				"zinc": {
					"value": .625,
					"unit": "mg"
				},
				"copper": {
					"value": .255,
					"unit": "mg"
				},
				"manganese": {
					"value": .317,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644292/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644292,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-321611",
		"name": "Beans, snap, green, canned, regular pack, drained solids",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 21,
			"proteinG": 1.04,
			"carbohydrateG": 4.11,
			"fatG": .39,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 36,
					"unit": "mg"
				},
				"iron": {
					"value": .78,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 23,
					"unit": "mg"
				},
				"potassium": {
					"value": 97,
					"unit": "mg"
				},
				"sodium": {
					"value": 282,
					"unit": "mg"
				},
				"zinc": {
					"value": .19,
					"unit": "mg"
				},
				"copper": {
					"value": .041,
					"unit": "mg"
				},
				"manganese": {
					"value": .176,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/321611/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 321611,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 drained cup",
			"weightGrams": 129
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2346400",
		"name": "Beans, snap, green, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 33.6,
			"proteinG": 1.97,
			"carbohydrateG": 7.41,
			"fatG": .275,
			"fiberG": 3.01,
			"micronutrients": {
				"calcium": {
					"value": 40,
					"unit": "mg"
				},
				"iron": {
					"value": .652,
					"unit": "mg"
				},
				"magnesium": {
					"value": 28.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 41.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 290,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .35,
					"unit": "mg"
				},
				"copper": {
					"value": .098,
					"unit": "mg"
				},
				"manganese": {
					"value": .332,
					"unit": "mg"
				},
				"thiamin": {
					"value": .06,
					"unit": "mg"
				},
				"niacin": {
					"value": .731,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .121,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 43.9,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346400/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346400,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2646174",
		"name": "Beef, chuck, roast, boneless, choice, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 237,
			"proteinG": 18.4,
			"carbohydrateG": 0,
			"fatG": 17.8,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.58,
					"unit": "mg"
				},
				"iron": {
					"value": 2.06,
					"unit": "mg"
				},
				"magnesium": {
					"value": 17,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 151,
					"unit": "mg"
				},
				"potassium": {
					"value": 281,
					"unit": "mg"
				},
				"sodium": {
					"value": 48.4,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.39,
					"unit": "mg"
				},
				"copper": {
					"value": .054,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2646174/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2646174,
			"release": "10/26/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2646175",
		"name": "Beef, flank, steak, boneless, choice, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 170,
			"proteinG": 20.1,
			"carbohydrateG": 0,
			"fatG": 9.4,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 3.84,
					"unit": "mg"
				},
				"iron": {
					"value": 1.83,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 167,
					"unit": "mg"
				},
				"potassium": {
					"value": 332,
					"unit": "mg"
				},
				"sodium": {
					"value": 51.3,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.56,
					"unit": "mg"
				},
				"copper": {
					"value": .045,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2646175/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2646175,
			"release": "10/26/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2514744",
		"name": "Beef, ground, 80% lean meat / 20% fat, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 248,
			"proteinG": 17.5,
			"carbohydrateG": 0,
			"fatG": 19.4,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6.89,
					"unit": "mg"
				},
				"iron": {
					"value": 1.96,
					"unit": "mg"
				},
				"magnesium": {
					"value": 16.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 144,
					"unit": "mg"
				},
				"potassium": {
					"value": 273,
					"unit": "mg"
				},
				"sodium": {
					"value": 54.9,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.85,
					"unit": "mg"
				},
				"copper": {
					"value": .055,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2514744/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2514744,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2514743",
		"name": "Beef, ground, 90% lean meat / 10% fat, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 190,
			"proteinG": 18.2,
			"carbohydrateG": 0,
			"fatG": 12.8,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 7.14,
					"unit": "mg"
				},
				"iron": {
					"value": 2.13,
					"unit": "mg"
				},
				"magnesium": {
					"value": 16.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 148,
					"unit": "mg"
				},
				"potassium": {
					"value": 281,
					"unit": "mg"
				},
				"sodium": {
					"value": 61.6,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.19,
					"unit": "mg"
				},
				"copper": {
					"value": .056,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2514743/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2514743,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-746758",
		"name": "Beef, loin, tenderloin roast, separable lean only, boneless, trimmed to 0\" fat, select, cooked, roasted",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 176,
			"proteinG": 27.7,
			"carbohydrateG": 0,
			"fatG": 6.36,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 13,
					"unit": "mg"
				},
				"iron": {
					"value": 3.04,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 259,
					"unit": "mg"
				},
				"potassium": {
					"value": 352,
					"unit": "mg"
				},
				"sodium": {
					"value": 54,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.7,
					"unit": "mg"
				},
				"copper": {
					"value": .097,
					"unit": "mg"
				},
				"manganese": {
					"value": .008,
					"unit": "mg"
				},
				"selenium": {
					"value": 25.4,
					"unit": "µg"
				},
				"riboflavin": {
					"value": .4,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.76,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .67,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 4.21,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746758/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746758,
			"release": "12/16/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cooked roast",
			"weightGrams": 462
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-746759",
		"name": "Beef, loin, top loin steak, boneless, lip-on, separable lean only, trimmed to 1/8\" fat, choice, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 155,
			"proteinG": 22.8,
			"carbohydrateG": 0,
			"fatG": 6.39,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 15,
					"unit": "mg"
				},
				"iron": {
					"value": 1.9,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 206,
					"unit": "mg"
				},
				"potassium": {
					"value": 282,
					"unit": "mg"
				},
				"sodium": {
					"value": 45,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.76,
					"unit": "mg"
				},
				"copper": {
					"value": .043,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				},
				"selenium": {
					"value": 21.3,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .25,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .053,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .202,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.88,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .575,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.72,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746759/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746759,
			"release": "12/16/2019"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2646172",
		"name": "Beef, ribeye, steak, boneless, choice, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 260,
			"proteinG": 18.7,
			"carbohydrateG": 0,
			"fatG": 20,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.17,
					"unit": "mg"
				},
				"iron": {
					"value": 1.64,
					"unit": "mg"
				},
				"magnesium": {
					"value": 16.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 150,
					"unit": "mg"
				},
				"potassium": {
					"value": 288,
					"unit": "mg"
				},
				"sodium": {
					"value": 42.5,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.06,
					"unit": "mg"
				},
				"copper": {
					"value": .043,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2646172/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2646172,
			"release": "10/26/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-746760",
		"name": "Beef, round, eye of round roast, boneless, separable lean only, trimmed to 0\" fat, select, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 122,
			"proteinG": 23.4,
			"carbohydrateG": 0,
			"fatG": 2.48,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 13,
					"unit": "mg"
				},
				"iron": {
					"value": 1.37,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 222,
					"unit": "mg"
				},
				"potassium": {
					"value": 312,
					"unit": "mg"
				},
				"sodium": {
					"value": 50,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.38,
					"unit": "mg"
				},
				"copper": {
					"value": .035,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				},
				"selenium": {
					"value": 22.2,
					"unit": "µg"
				},
				"riboflavin": {
					"value": .185,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.58,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .638,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 2.06,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746760/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746760,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 raw roast",
			"weightGrams": 690
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-746761",
		"name": "Beef, round, top round roast, boneless, separable lean only, trimmed to 0\" fat, select, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 123,
			"proteinG": 23.7,
			"carbohydrateG": 0,
			"fatG": 2.41,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 13,
					"unit": "mg"
				},
				"iron": {
					"value": 2.34,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 220,
					"unit": "mg"
				},
				"potassium": {
					"value": 316,
					"unit": "mg"
				},
				"sodium": {
					"value": 55,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.54,
					"unit": "mg"
				},
				"copper": {
					"value": .047,
					"unit": "mg"
				},
				"manganese": {
					"value": .003,
					"unit": "mg"
				},
				"selenium": {
					"value": 22.7,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .21,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .064,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .25,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.16,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .626,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.62,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746761/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746761,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 raw roast",
			"weightGrams": 788
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2646173",
		"name": "Beef, round, top round, boneless, choice, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 146,
			"proteinG": 21.5,
			"carbohydrateG": .852,
			"fatG": 5.7,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.07,
					"unit": "mg"
				},
				"iron": {
					"value": 1.9,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 192,
					"unit": "mg"
				},
				"potassium": {
					"value": 352,
					"unit": "mg"
				},
				"sodium": {
					"value": 45.5,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.78,
					"unit": "mg"
				},
				"copper": {
					"value": .055,
					"unit": "mg"
				},
				"manganese": {
					"value": .003,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2646173/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2646173,
			"release": "10/26/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2727572",
		"name": "Beef, short loin (NY strip steak), raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 196,
			"proteinG": 21.3,
			"carbohydrateG": .221,
			"fatG": 11.5,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 5.04,
					"unit": "mg"
				},
				"iron": {
					"value": 1.61,
					"unit": "mg"
				},
				"magnesium": {
					"value": 19.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 171,
					"unit": "mg"
				},
				"potassium": {
					"value": 323,
					"unit": "mg"
				},
				"sodium": {
					"value": 43.1,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.28,
					"unit": "mg"
				},
				"copper": {
					"value": .043,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727572/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727572,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-746762",
		"name": "Beef, short loin, porterhouse steak, separable lean only, trimmed to 1/8\" fat, select, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 145,
			"proteinG": 22.7,
			"carbohydrateG": 0,
			"fatG": 5.32,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 19,
					"unit": "mg"
				},
				"iron": {
					"value": 2.26,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 200,
					"unit": "mg"
				},
				"potassium": {
					"value": 266,
					"unit": "mg"
				},
				"sodium": {
					"value": 43,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.52,
					"unit": "mg"
				},
				"copper": {
					"value": .075,
					"unit": "mg"
				},
				"manganese": {
					"value": .003,
					"unit": "mg"
				},
				"selenium": {
					"value": 21.4,
					"unit": "µg"
				},
				"riboflavin": {
					"value": .23,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.32,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .751,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.98,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746762/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746762,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 raw steak",
			"weightGrams": 525
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-746763",
		"name": "Beef, short loin, t-bone steak, bone-in, separable lean only, trimmed to 1/8\" fat, choice, cooked, grilled",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 219,
			"proteinG": 27.3,
			"carbohydrateG": 0,
			"fatG": 11.4,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 19,
					"unit": "mg"
				},
				"iron": {
					"value": 3.53,
					"unit": "mg"
				},
				"magnesium": {
					"value": 20,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 211,
					"unit": "mg"
				},
				"potassium": {
					"value": 283,
					"unit": "mg"
				},
				"sodium": {
					"value": 67,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.69,
					"unit": "mg"
				},
				"copper": {
					"value": .078,
					"unit": "mg"
				},
				"manganese": {
					"value": .003,
					"unit": "mg"
				},
				"selenium": {
					"value": 29.7,
					"unit": "µg"
				},
				"riboflavin": {
					"value": .27,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.37,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .753,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.88,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746763/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746763,
			"release": "12/16/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cooked steak",
			"weightGrams": 360
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2727573",
		"name": "Beef,\xA0tenderloin steak, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 149,
			"proteinG": 21.1,
			"carbohydrateG": .18,
			"fatG": 6.46,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.09,
					"unit": "mg"
				},
				"iron": {
					"value": 2.53,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 190,
					"unit": "mg"
				},
				"potassium": {
					"value": 345,
					"unit": "mg"
				},
				"sodium": {
					"value": 44.8,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.22,
					"unit": "mg"
				},
				"copper": {
					"value": .105,
					"unit": "mg"
				},
				"manganese": {
					"value": .005,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727573/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727573,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2727574",
		"name": "Beef, top sirloin steak, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 146,
			"proteinG": 22,
			"carbohydrateG": .218,
			"fatG": 5.71,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 3.7,
					"unit": "mg"
				},
				"iron": {
					"value": 2.22,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 193,
					"unit": "mg"
				},
				"potassium": {
					"value": 349,
					"unit": "mg"
				},
				"sodium": {
					"value": 42.8,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.45,
					"unit": "mg"
				},
				"copper": {
					"value": .07,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727574/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727574,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2747653",
		"name": "Beet greens, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 26.4,
			"proteinG": 1.61,
			"carbohydrateG": 4.66,
			"fatG": .144,
			"fiberG": 2.58,
			"micronutrients": {
				"calcium": {
					"value": 72.8,
					"unit": "mg"
				},
				"iron": {
					"value": 3.16,
					"unit": "mg"
				},
				"magnesium": {
					"value": 74.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 26.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 369,
					"unit": "mg"
				},
				"sodium": {
					"value": 280,
					"unit": "mg"
				},
				"zinc": {
					"value": .315,
					"unit": "mg"
				},
				"copper": {
					"value": .076,
					"unit": "mg"
				},
				"manganese": {
					"value": .817,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 8.58,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .142,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .115,
					"unit": "mg"
				},
				"folate": {
					"value": 152,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747653/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747653,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2685576",
		"name": "Beets, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 41,
			"proteinG": 1.69,
			"carbohydrateG": 8.79,
			"fatG": .302,
			"fiberG": 3.12,
			"micronutrients": {
				"calcium": {
					"value": 13.8,
					"unit": "mg"
				},
				"iron": {
					"value": .428,
					"unit": "mg"
				},
				"magnesium": {
					"value": 21,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 33.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 342,
					"unit": "mg"
				},
				"sodium": {
					"value": 112,
					"unit": "mg"
				},
				"zinc": {
					"value": .31,
					"unit": "mg"
				},
				"copper": {
					"value": .161,
					"unit": "mg"
				},
				"manganese": {
					"value": .257,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 4.6,
					"unit": "mg"
				},
				"folate": {
					"value": 103,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685576/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685576,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2727571",
		"name": "Bison, ground, raw",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 164,
			"proteinG": 19.9,
			"carbohydrateG": -.15,
			"fatG": 8.88,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6.83,
					"unit": "mg"
				},
				"iron": {
					"value": 2.17,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 166,
					"unit": "mg"
				},
				"potassium": {
					"value": 301,
					"unit": "mg"
				},
				"sodium": {
					"value": 55.7,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.76,
					"unit": "mg"
				},
				"copper": {
					"value": .078,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727571/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727571,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2727581",
		"name": "Blackberries, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 1.53,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 5.3,
			"micronutrients": {
				"calcium": {
					"value": 15.4,
					"unit": "mg"
				},
				"iron": {
					"value": .208,
					"unit": "mg"
				},
				"magnesium": {
					"value": 20.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 20.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 167,
					"unit": "mg"
				},
				"sodium": {
					"value": 1.55,
					"unit": "mg"
				},
				"zinc": {
					"value": .189,
					"unit": "mg"
				},
				"copper": {
					"value": .145,
					"unit": "mg"
				},
				"manganese": {
					"value": .885,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 15.4,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727581/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727581,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2644293",
		"name": "Blackeye pea, canned, sodium added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 113,
			"proteinG": 6.92,
			"carbohydrateG": 19.2,
			"fatG": 1.3,
			"fiberG": 4.34,
			"micronutrients": {
				"calcium": {
					"value": 27.8,
					"unit": "mg"
				},
				"iron": {
					"value": 1.08,
					"unit": "mg"
				},
				"magnesium": {
					"value": 27.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 83,
					"unit": "mg"
				},
				"potassium": {
					"value": 138,
					"unit": "mg"
				},
				"sodium": {
					"value": 227,
					"unit": "mg"
				},
				"zinc": {
					"value": .655,
					"unit": "mg"
				},
				"copper": {
					"value": .285,
					"unit": "mg"
				},
				"manganese": {
					"value": .222,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644293/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644293,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2644284",
		"name": "Blackeye pea, dry",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 346,
			"proteinG": 21.2,
			"carbohydrateG": 61.8,
			"fatG": 2.42,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 71.4,
					"unit": "mg"
				},
				"iron": {
					"value": 5.93,
					"unit": "mg"
				},
				"magnesium": {
					"value": 184,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 428,
					"unit": "mg"
				},
				"potassium": {
					"value": 1240,
					"unit": "mg"
				},
				"sodium": {
					"value": 3.46,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.65,
					"unit": "mg"
				},
				"copper": {
					"value": .936,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.29,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644284/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644284,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 35
		}]
	},
	{
		"id": "usda-fdc-2346411",
		"name": "Blueberries, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 57.4,
			"proteinG": .703,
			"carbohydrateG": 14.6,
			"fatG": .306,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 11.7,
					"unit": "mg"
				},
				"iron": {
					"value": .34,
					"unit": "mg"
				},
				"magnesium": {
					"value": 6.18,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 13,
					"unit": "mg"
				},
				"potassium": {
					"value": 85.6,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .085,
					"unit": "mg"
				},
				"copper": {
					"value": .046,
					"unit": "mg"
				},
				"manganese": {
					"value": .423,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 8.06,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346411/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346411,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-747447",
		"name": "Broccoli, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 31,
			"proteinG": 2.57,
			"carbohydrateG": 6.27,
			"fatG": .34,
			"fiberG": 2.4,
			"micronutrients": {
				"calcium": {
					"value": 46,
					"unit": "mg"
				},
				"iron": {
					"value": .69,
					"unit": "mg"
				},
				"magnesium": {
					"value": 21,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 67,
					"unit": "mg"
				},
				"potassium": {
					"value": 303,
					"unit": "mg"
				},
				"sodium": {
					"value": 36,
					"unit": "mg"
				},
				"zinc": {
					"value": .42,
					"unit": "mg"
				},
				"copper": {
					"value": .059,
					"unit": "mg"
				},
				"manganese": {
					"value": .197,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.6,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 8,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .15,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 91.3,
					"unit": "mg"
				},
				"thiamin": {
					"value": .077,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .114,
					"unit": "mg"
				},
				"niacin": {
					"value": .639,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .191,
					"unit": "mg"
				},
				"folate": {
					"value": 65,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 102,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747447/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747447,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 chopped cup",
			"weightGrams": 76
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2685575",
		"name": "Brussels sprouts, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 48.8,
			"proteinG": 3.98,
			"carbohydrateG": 9.62,
			"fatG": .565,
			"fiberG": 4.78,
			"micronutrients": {
				"calcium": {
					"value": 38.6,
					"unit": "mg"
				},
				"iron": {
					"value": .73,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 78.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 477,
					"unit": "mg"
				},
				"sodium": {
					"value": 25.7,
					"unit": "mg"
				},
				"zinc": {
					"value": .366,
					"unit": "mg"
				},
				"copper": {
					"value": .038,
					"unit": "mg"
				},
				"manganese": {
					"value": .24,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 143,
					"unit": "mg"
				},
				"folate": {
					"value": 86,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685575/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685575,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2512378",
		"name": "Buckwheat, whole grain",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 332,
			"proteinG": 11.1,
			"carbohydrateG": 71.1,
			"fatG": 3.04,
			"fiberG": 4.05,
			"micronutrients": {
				"calcium": {
					"value": 13.6,
					"unit": "mg"
				},
				"iron": {
					"value": 2.44,
					"unit": "mg"
				},
				"magnesium": {
					"value": 203,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 374,
					"unit": "mg"
				},
				"potassium": {
					"value": 414,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.24,
					"unit": "mg"
				},
				"copper": {
					"value": .476,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.23,
					"unit": "mg"
				},
				"selenium": {
					"value": 13.6,
					"unit": "µg"
				},
				"thiamin": {
					"value": .539,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .178,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.37,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .278,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512378/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512378,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2710820",
		"name": "Bulgur, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 349,
			"proteinG": 11.8,
			"carbohydrateG": 75.9,
			"fatG": 2.42,
			"fiberG": 11.7,
			"micronutrients": {
				"calcium": {
					"value": 34.1,
					"unit": "mg"
				},
				"iron": {
					"value": 2.62,
					"unit": "mg"
				},
				"magnesium": {
					"value": 119,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 312,
					"unit": "mg"
				},
				"potassium": {
					"value": 358,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.18,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.15,
					"unit": "mg"
				},
				"copper": {
					"value": .377,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.64,
					"unit": "mg"
				},
				"thiamin": {
					"value": .226,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.18,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .223,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710820/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710820,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-790508",
		"name": "Butter, stick, salted",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": 82.2,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 21,
					"unit": "mg"
				},
				"iron": {
					"value": .06,
					"unit": "mg"
				},
				"magnesium": {
					"value": 1.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 22,
					"unit": "mg"
				},
				"potassium": {
					"value": 23,
					"unit": "mg"
				},
				"sodium": {
					"value": 524,
					"unit": "mg"
				},
				"zinc": {
					"value": .07,
					"unit": "mg"
				},
				"copper": {
					"value": .006,
					"unit": "mg"
				},
				"manganese": {
					"value": .005,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 758,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .4,
					"unit": "µg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": 0,
					"unit": "mg"
				},
				"folate": {
					"value": 5,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/790508/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 790508,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-789828",
		"name": "Butter, stick, unsalted",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": 81.5,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 14,
					"unit": "mg"
				},
				"iron": {
					"value": .03,
					"unit": "mg"
				},
				"magnesium": {
					"value": 1.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 19,
					"unit": "mg"
				},
				"potassium": {
					"value": 19,
					"unit": "mg"
				},
				"sodium": {
					"value": 10,
					"unit": "mg"
				},
				"zinc": {
					"value": .07,
					"unit": "mg"
				},
				"copper": {
					"value": .001,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/789828/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 789828,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2259792",
		"name": "Buttermilk, low fat",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 42.9,
			"proteinG": 3.46,
			"carbohydrateG": 4.81,
			"fatG": 1.08,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 120,
					"unit": "mg"
				},
				"iron": {
					"value": .013,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 92.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 158,
					"unit": "mg"
				},
				"sodium": {
					"value": 92.5,
					"unit": "mg"
				},
				"zinc": {
					"value": .426,
					"unit": "mg"
				},
				"copper": {
					"value": .001,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .543,
					"unit": "µg"
				},
				"thiamin": {
					"value": .049,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .196,
					"unit": "mg"
				},
				"niacin": {
					"value": .128,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .039,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2259792/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2259792,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2685572",
		"name": "Cabbage, bok choy, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 17,
			"proteinG": 1.02,
			"carbohydrateG": 3.51,
			"fatG": .234,
			"fiberG": 1.26,
			"micronutrients": {
				"calcium": {
					"value": 61.9,
					"unit": "mg"
				},
				"iron": {
					"value": .439,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 30.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 228,
					"unit": "mg"
				},
				"sodium": {
					"value": 14.3,
					"unit": "mg"
				},
				"zinc": {
					"value": .274,
					"unit": "mg"
				},
				"copper": {
					"value": .028,
					"unit": "mg"
				},
				"manganese": {
					"value": .196,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 30.3,
					"unit": "mg"
				},
				"folate": {
					"value": 68,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685572/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685572,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2346407",
		"name": "Cabbage, green, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 27.9,
			"proteinG": .961,
			"carbohydrateG": 6.38,
			"fatG": .228,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 41.8,
					"unit": "mg"
				},
				"iron": {
					"value": .066,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 26.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 207,
					"unit": "mg"
				},
				"sodium": {
					"value": 16.1,
					"unit": "mg"
				},
				"zinc": {
					"value": .211,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .248,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 40.3,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .138,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 59.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346407/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346407,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2727583",
		"name": "Cabbage, napa, leaf, destemmed, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 1.06,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 1.2,
			"micronutrients": {
				"calcium": {
					"value": 35,
					"unit": "mg"
				},
				"iron": {
					"value": .255,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 34.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 235,
					"unit": "mg"
				},
				"sodium": {
					"value": 12.6,
					"unit": "mg"
				},
				"zinc": {
					"value": .253,
					"unit": "mg"
				},
				"copper": {
					"value": .024,
					"unit": "mg"
				},
				"manganese": {
					"value": .201,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .086,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727583/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727583,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2346408",
		"name": "Cabbage, red, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 29.9,
			"proteinG": 1.24,
			"carbohydrateG": 6.79,
			"fatG": .214,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 31,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 35.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 269,
					"unit": "mg"
				},
				"sodium": {
					"value": 11.7,
					"unit": "mg"
				},
				"zinc": {
					"value": .245,
					"unit": "mg"
				},
				"copper": {
					"value": .004,
					"unit": "mg"
				},
				"manganese": {
					"value": .309,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 53.9,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .179,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 32.3,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346408/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346408,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2258587",
		"name": "Carrots, baby, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 38.3,
			"proteinG": .805,
			"carbohydrateG": 9.08,
			"fatG": .138,
			"fiberG": 2.69,
			"micronutrients": {
				"calcium": {
					"value": 42.2,
					"unit": "mg"
				},
				"iron": {
					"value": .088,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 29.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 237,
					"unit": "mg"
				},
				"sodium": {
					"value": 62.7,
					"unit": "mg"
				},
				"zinc": {
					"value": .16,
					"unit": "mg"
				},
				"copper": {
					"value": .041,
					"unit": "mg"
				},
				"manganese": {
					"value": .093,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .044,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .116,
					"unit": "mg"
				},
				"niacin": {
					"value": .741,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .115,
					"unit": "mg"
				},
				"folate": {
					"value": 43.6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2258587/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2258587,
			"release": "4/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-746764",
		"name": "Carrots, frozen, unprepared",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 37,
			"proteinG": .81,
			"carbohydrateG": 7.92,
			"fatG": .47,
			"fiberG": 3.2,
			"micronutrients": {
				"calcium": {
					"value": 33,
					"unit": "mg"
				},
				"iron": {
					"value": .43,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 31,
					"unit": "mg"
				},
				"potassium": {
					"value": 210,
					"unit": "mg"
				},
				"sodium": {
					"value": 66,
					"unit": "mg"
				},
				"zinc": {
					"value": .28,
					"unit": "mg"
				},
				"copper": {
					"value": .08,
					"unit": "mg"
				},
				"manganese": {
					"value": .143,
					"unit": "mg"
				},
				"vitaminE": {
					"value": .69,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 2.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": .039,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .047,
					"unit": "mg"
				},
				"niacin": {
					"value": .465,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .088,
					"unit": "mg"
				},
				"folate": {
					"value": 7,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 15,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746764/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746764,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2258586",
		"name": "Carrots, mature, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 45,
			"proteinG": .941,
			"carbohydrateG": 10.3,
			"fatG": .351,
			"fiberG": 3.1,
			"micronutrients": {
				"calcium": {
					"value": 30.5,
					"unit": "mg"
				},
				"iron": {
					"value": .15,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 39.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 280,
					"unit": "mg"
				},
				"sodium": {
					"value": 86.6,
					"unit": "mg"
				},
				"zinc": {
					"value": .236,
					"unit": "mg"
				},
				"copper": {
					"value": .061,
					"unit": "mg"
				},
				"manganese": {
					"value": .13,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .065,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .095,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.41,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .146,
					"unit": "mg"
				},
				"folate": {
					"value": 37.1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2258586/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2258586,
			"release": "4/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2685573",
		"name": "Cauliflower, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 22.9,
			"proteinG": 1.64,
			"carbohydrateG": 4.72,
			"fatG": .238,
			"fiberG": 1.95,
			"micronutrients": {
				"calcium": {
					"value": 20.4,
					"unit": "mg"
				},
				"iron": {
					"value": .334,
					"unit": "mg"
				},
				"magnesium": {
					"value": 14.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 39.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 274,
					"unit": "mg"
				},
				"sodium": {
					"value": 20,
					"unit": "mg"
				},
				"zinc": {
					"value": .234,
					"unit": "mg"
				},
				"copper": {
					"value": .024,
					"unit": "mg"
				},
				"manganese": {
					"value": .141,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 67.1,
					"unit": "mg"
				},
				"folate": {
					"value": 97,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685573/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685573,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2346405",
		"name": "Celery, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 14.8,
			"proteinG": .492,
			"carbohydrateG": 3.32,
			"fatG": .162,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 46.3,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 21.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 265,
					"unit": "mg"
				},
				"sodium": {
					"value": 97.2,
					"unit": "mg"
				},
				"zinc": {
					"value": .093,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .076,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminB6": {
					"value": .052,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346405/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346405,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-747429",
		"name": "Cheese, American, restaurant",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 375,
			"proteinG": 17.5,
			"carbohydrateG": 6.35,
			"fatG": 31.1,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 508,
					"unit": "mg"
				},
				"iron": {
					"value": .24,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 380,
					"unit": "mg"
				},
				"potassium": {
					"value": 173,
					"unit": "mg"
				},
				"sodium": {
					"value": 1600,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.45,
					"unit": "mg"
				},
				"copper": {
					"value": .042,
					"unit": "mg"
				},
				"manganese": {
					"value": .018,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747429/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747429,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-328637",
		"name": "Cheese, cheddar",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 408,
			"proteinG": 23.3,
			"carbohydrateG": 2.44,
			"fatG": 34,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 707,
					"unit": "mg"
				},
				"iron": {
					"value": .16,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 458,
					"unit": "mg"
				},
				"potassium": {
					"value": 77,
					"unit": "mg"
				},
				"sodium": {
					"value": 654,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.67,
					"unit": "mg"
				},
				"copper": {
					"value": .033,
					"unit": "mg"
				},
				"manganese": {
					"value": .026,
					"unit": "mg"
				},
				"selenium": {
					"value": 28.3,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 316,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .75,
					"unit": "mg"
				},
				"thiamin": {
					"value": .029,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .441,
					"unit": "mg"
				},
				"niacin": {
					"value": .052,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .069,
					"unit": "mg"
				},
				"folate": {
					"value": 21,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.06,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 2.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/328637/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 328637,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 slice",
				"weightGrams": 17
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 cup",
				"weightGrams": 105
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 30
			}
		]
	},
	{
		"id": "usda-fdc-2647443",
		"name": "Cheese, cotija, solid",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 352,
			"proteinG": 23.8,
			"carbohydrateG": 2.72,
			"fatG": 27.2,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 700,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 486,
					"unit": "mg"
				},
				"potassium": {
					"value": 117,
					"unit": "mg"
				},
				"sodium": {
					"value": 1620,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.6,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .017,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2647443/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2647443,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-328841",
		"name": "Cheese, cottage, lowfat, 2% milkfat",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 84,
			"proteinG": 11,
			"carbohydrateG": 4.31,
			"fatG": 2.3,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 103,
					"unit": "mg"
				},
				"iron": {
					"value": .13,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 148,
					"unit": "mg"
				},
				"potassium": {
					"value": 120,
					"unit": "mg"
				},
				"sodium": {
					"value": 321,
					"unit": "mg"
				},
				"zinc": {
					"value": .61,
					"unit": "mg"
				},
				"copper": {
					"value": .03,
					"unit": "mg"
				},
				"manganese": {
					"value": .015,
					"unit": "mg"
				},
				"selenium": {
					"value": 14.6,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 69,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .08,
					"unit": "mg"
				},
				"thiamin": {
					"value": .02,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .234,
					"unit": "mg"
				},
				"niacin": {
					"value": .09,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .057,
					"unit": "mg"
				},
				"folate": {
					"value": 10,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .42,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/328841/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 328841,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 220
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 55
		}]
	},
	{
		"id": "usda-fdc-746765",
		"name": "Cheese, dry white, queso seco",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 326,
			"proteinG": 24.5,
			"carbohydrateG": 2.07,
			"fatG": 24.3,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 661,
					"unit": "mg"
				},
				"iron": {
					"value": .18,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 475,
					"unit": "mg"
				},
				"potassium": {
					"value": 116,
					"unit": "mg"
				},
				"sodium": {
					"value": 1810,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.28,
					"unit": "mg"
				},
				"copper": {
					"value": .027,
					"unit": "mg"
				},
				"manganese": {
					"value": .018,
					"unit": "mg"
				},
				"selenium": {
					"value": 22.4,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 226,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .49,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 1.83,
					"unit": "µg"
				},
				"thiamin": {
					"value": .038,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .23,
					"unit": "mg"
				},
				"niacin": {
					"value": .083,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .091,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.7,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 1.6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746765/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746765,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 grated cup",
			"weightGrams": 97.3
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2259796",
		"name": "Cheese, feta, whole milk, crumbled",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 273,
			"proteinG": 19.7,
			"carbohydrateG": 5.58,
			"fatG": 19.1,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 371,
					"unit": "mg"
				},
				"iron": {
					"value": .068,
					"unit": "mg"
				},
				"magnesium": {
					"value": 17.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 328,
					"unit": "mg"
				},
				"potassium": {
					"value": 105,
					"unit": "mg"
				},
				"sodium": {
					"value": 1030,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.35,
					"unit": "mg"
				},
				"copper": {
					"value": .032,
					"unit": "mg"
				},
				"manganese": {
					"value": .02,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .056,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .444,
					"unit": "mg"
				},
				"niacin": {
					"value": .264,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .038,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 1.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2259796/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2259796,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2647438",
		"name": "Cheese, monterey jack, solid",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 391,
			"proteinG": 22.6,
			"carbohydrateG": 1.9,
			"fatG": 32.6,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 715,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 471,
					"unit": "mg"
				},
				"potassium": {
					"value": 82.9,
					"unit": "mg"
				},
				"sodium": {
					"value": 662,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.78,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .011,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2647438/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2647438,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-329370",
		"name": "Cheese, mozzarella, low moisture, part-skim",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 298,
			"proteinG": 23.7,
			"carbohydrateG": 4.44,
			"fatG": 20.4,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 693,
					"unit": "mg"
				},
				"iron": {
					"value": .2,
					"unit": "mg"
				},
				"magnesium": {
					"value": 27.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 533,
					"unit": "mg"
				},
				"potassium": {
					"value": 116,
					"unit": "mg"
				},
				"sodium": {
					"value": 699,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.62,
					"unit": "mg"
				},
				"copper": {
					"value": .035,
					"unit": "mg"
				},
				"manganese": {
					"value": .035,
					"unit": "mg"
				},
				"selenium": {
					"value": 26.7,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 203,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .51,
					"unit": "mg"
				},
				"thiamin": {
					"value": .023,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .36,
					"unit": "mg"
				},
				"niacin": {
					"value": .101,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .09,
					"unit": "mg"
				},
				"folate": {
					"value": 26,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.65,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 1.3,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/329370/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 329370,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2647441",
		"name": "Cheese, oaxaca, solid",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 298,
			"proteinG": 22.1,
			"carbohydrateG": 2.4,
			"fatG": 22.1,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 532,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 21.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 380,
					"unit": "mg"
				},
				"potassium": {
					"value": 80.7,
					"unit": "mg"
				},
				"sodium": {
					"value": 734,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.51,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .021,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2647441/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2647441,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-325036",
		"name": "Cheese, parmesan, grated",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 421,
			"proteinG": 29.6,
			"carbohydrateG": 12.4,
			"fatG": 28,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 884,
					"unit": "mg"
				},
				"iron": {
					"value": .45,
					"unit": "mg"
				},
				"magnesium": {
					"value": 34.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 634,
					"unit": "mg"
				},
				"potassium": {
					"value": 184,
					"unit": "mg"
				},
				"sodium": {
					"value": 1750,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.33,
					"unit": "mg"
				},
				"copper": {
					"value": .04,
					"unit": "mg"
				},
				"manganese": {
					"value": .066,
					"unit": "mg"
				},
				"selenium": {
					"value": 35,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 228,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .51,
					"unit": "mg"
				},
				"thiamin": {
					"value": .027,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .345,
					"unit": "mg"
				},
				"niacin": {
					"value": .078,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .081,
					"unit": "mg"
				},
				"folate": {
					"value": 6,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.35,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 1.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/325036/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 325036,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 tbsp",
			"weightGrams": 7.6
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 5
		}]
	},
	{
		"id": "usda-fdc-2259795",
		"name": "Cheese, parmesan, grated, refrigerated",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 405,
			"proteinG": 30.1,
			"carbohydrateG": 4.33,
			"fatG": 29.5,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 950,
					"unit": "mg"
				},
				"iron": {
					"value": .14,
					"unit": "mg"
				},
				"magnesium": {
					"value": 35.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 625,
					"unit": "mg"
				},
				"potassium": {
					"value": 74,
					"unit": "mg"
				},
				"sodium": {
					"value": 1050,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.62,
					"unit": "mg"
				},
				"copper": {
					"value": .042,
					"unit": "mg"
				},
				"manganese": {
					"value": .037,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .035,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .409,
					"unit": "mg"
				},
				"niacin": {
					"value": .141,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .023,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 1.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2259795/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2259795,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 5
		}]
	},
	{
		"id": "usda-fdc-2647439",
		"name": "Cheese, pasteurized process cheese food or product, American, singles",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 308,
			"proteinG": 15.6,
			"carbohydrateG": 8.19,
			"fatG": 23.9,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 1500,
					"unit": "mg"
				},
				"iron": {
					"value": 1.3,
					"unit": "mg"
				},
				"magnesium": {
					"value": 34.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 880,
					"unit": "mg"
				},
				"potassium": {
					"value": 212,
					"unit": "mg"
				},
				"sodium": {
					"value": 1420,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.38,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .065,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 4.42,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2647439/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2647439,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-325198",
		"name": "Cheese, pasteurized process, American, vitamin D fortified",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 366,
			"proteinG": 18,
			"carbohydrateG": 5.27,
			"fatG": 30.6,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 866,
					"unit": "mg"
				},
				"iron": {
					"value": .48,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 540,
					"unit": "mg"
				},
				"potassium": {
					"value": 149,
					"unit": "mg"
				},
				"sodium": {
					"value": 1660,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.42,
					"unit": "mg"
				},
				"copper": {
					"value": .046,
					"unit": "mg"
				},
				"manganese": {
					"value": .038,
					"unit": "mg"
				},
				"selenium": {
					"value": 20.4,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 300,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .79,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 7.5,
					"unit": "µg"
				},
				"thiamin": {
					"value": .015,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .247,
					"unit": "mg"
				},
				"niacin": {
					"value": .095,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .056,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.45,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 3.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/325198/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 325198,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2647440",
		"name": "Cheese, provolone, sliced",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 357,
			"proteinG": 23.5,
			"carbohydrateG": 2.45,
			"fatG": 28.1,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 749,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 494,
					"unit": "mg"
				},
				"potassium": {
					"value": 94.8,
					"unit": "mg"
				},
				"sodium": {
					"value": 601,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.89,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .03,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2647440/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2647440,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2647442",
		"name": "Cheese, queso fresco, solid",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 297,
			"proteinG": 18.9,
			"carbohydrateG": 2.96,
			"fatG": 23.4,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 602,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 27.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 390,
					"unit": "mg"
				},
				"potassium": {
					"value": 126,
					"unit": "mg"
				},
				"sodium": {
					"value": 626,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.91,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2647442/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2647442,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-746766",
		"name": "Cheese, ricotta, whole milk",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 157,
			"proteinG": 7.81,
			"carbohydrateG": 6.86,
			"fatG": 11,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 224,
					"unit": "mg"
				},
				"iron": {
					"value": .1,
					"unit": "mg"
				},
				"magnesium": {
					"value": 19.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 162,
					"unit": "mg"
				},
				"potassium": {
					"value": 230,
					"unit": "mg"
				},
				"sodium": {
					"value": 105,
					"unit": "mg"
				},
				"zinc": {
					"value": .56,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 5.5,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 127,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .27,
					"unit": "mg"
				},
				"thiamin": {
					"value": .043,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .327,
					"unit": "mg"
				},
				"niacin": {
					"value": .168,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .099,
					"unit": "mg"
				},
				"folate": {
					"value": 4,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .78,
					"unit": "µg"
				},
				"vitaminK": {
					"value": .6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746766/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746766,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": .2,
				"unit": "serving",
				"description": "0.2 cup",
				"weightGrams": 64.6
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 cup",
				"weightGrams": 258
			},
			{
				"quantity": .5,
				"unit": "serving",
				"description": "0.5 cup",
				"weightGrams": 129
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 55
			}
		]
	},
	{
		"id": "usda-fdc-746767",
		"name": "Cheese, swiss",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 393,
			"proteinG": 27,
			"carbohydrateG": 1.44,
			"fatG": 31,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 890,
					"unit": "mg"
				},
				"iron": {
					"value": .13,
					"unit": "mg"
				},
				"magnesium": {
					"value": 33.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 574,
					"unit": "mg"
				},
				"potassium": {
					"value": 71,
					"unit": "mg"
				},
				"sodium": {
					"value": 185,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.37,
					"unit": "mg"
				},
				"copper": {
					"value": .047,
					"unit": "mg"
				},
				"manganese": {
					"value": .027,
					"unit": "mg"
				},
				"selenium": {
					"value": 30.1,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 292,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .6,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .011,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .303,
					"unit": "mg"
				},
				"niacin": {
					"value": .06,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .07,
					"unit": "mg"
				},
				"folate": {
					"value": 9,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 3.02,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 1.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746767/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746767,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 regular slice",
				"weightGrams": 21.9
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 thin slice",
				"weightGrams": 10.9
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 30
			}
		]
	},
	{
		"id": "usda-fdc-2346399",
		"name": "Cherries, sweet, dark red, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 63.3,
			"proteinG": 1.04,
			"carbohydrateG": 16.2,
			"fatG": .192,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 12.3,
					"unit": "mg"
				},
				"iron": {
					"value": .105,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 23.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 230,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .065,
					"unit": "mg"
				},
				"copper": {
					"value": .069,
					"unit": "mg"
				},
				"manganese": {
					"value": .073,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 10.4,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .049,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346399/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346399,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710819",
		"name": "Chia seeds, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 490,
			"proteinG": 17,
			"carbohydrateG": 38.3,
			"fatG": 32.9,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 595,
					"unit": "mg"
				},
				"iron": {
					"value": 6.04,
					"unit": "mg"
				},
				"magnesium": {
					"value": 326,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 691,
					"unit": "mg"
				},
				"potassium": {
					"value": 642,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.56,
					"unit": "mg"
				},
				"copper": {
					"value": 1.57,
					"unit": "mg"
				},
				"manganese": {
					"value": 7.56,
					"unit": "mg"
				},
				"thiamin": {
					"value": .5,
					"unit": "mg"
				},
				"niacin": {
					"value": 8.68,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .202,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710819/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710819,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2646170",
		"name": "Chicken, breast, boneless, skinless, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 112,
			"proteinG": 22.5,
			"carbohydrateG": 0,
			"fatG": 1.93,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 3.94,
					"unit": "mg"
				},
				"iron": {
					"value": .354,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 215,
					"unit": "mg"
				},
				"potassium": {
					"value": 330,
					"unit": "mg"
				},
				"sodium": {
					"value": 65.8,
					"unit": "mg"
				},
				"zinc": {
					"value": .654,
					"unit": "mg"
				},
				"copper": {
					"value": .004,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2646170/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2646170,
			"release": "10/26/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2727569",
		"name": "Chicken, breast, meat and skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 133,
			"proteinG": 21.4,
			"carbohydrateG": -.428,
			"fatG": 4.78,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6.9,
					"unit": "mg"
				},
				"iron": {
					"value": .354,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 204,
					"unit": "mg"
				},
				"potassium": {
					"value": 332,
					"unit": "mg"
				},
				"sodium": {
					"value": 48.1,
					"unit": "mg"
				},
				"zinc": {
					"value": .624,
					"unit": "mg"
				},
				"copper": {
					"value": .004,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727569/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727569,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-331960",
		"name": "Chicken, broiler or fryers, breast, skinless, boneless, meat only, cooked, braised",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 166,
			"proteinG": 32.1,
			"carbohydrateG": 0,
			"fatG": 3.24,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6,
					"unit": "mg"
				},
				"iron": {
					"value": .49,
					"unit": "mg"
				},
				"magnesium": {
					"value": 32,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 241,
					"unit": "mg"
				},
				"potassium": {
					"value": 343,
					"unit": "mg"
				},
				"sodium": {
					"value": 47,
					"unit": "mg"
				},
				"zinc": {
					"value": .96,
					"unit": "mg"
				},
				"copper": {
					"value": .044,
					"unit": "mg"
				},
				"manganese": {
					"value": .012,
					"unit": "mg"
				},
				"selenium": {
					"value": 31.9,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .33,
					"unit": "mg"
				},
				"thiamin": {
					"value": .098,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .187,
					"unit": "mg"
				},
				"niacin": {
					"value": 9.45,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .921,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": .2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/331960/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 331960,
			"release": "4/1/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 piece",
			"weightGrams": 174
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-331897",
		"name": "Chicken, broilers or fryers, drumstick, meat only, cooked, braised",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 156,
			"proteinG": 23.9,
			"carbohydrateG": 0,
			"fatG": 5.95,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 12,
					"unit": "mg"
				},
				"iron": {
					"value": .94,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 184,
					"unit": "mg"
				},
				"potassium": {
					"value": 239,
					"unit": "mg"
				},
				"sodium": {
					"value": 117,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.54,
					"unit": "mg"
				},
				"copper": {
					"value": .063,
					"unit": "mg"
				},
				"manganese": {
					"value": .018,
					"unit": "mg"
				},
				"selenium": {
					"value": 27.9,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 7,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .17,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .1,
					"unit": "µg"
				},
				"thiamin": {
					"value": .088,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .18,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.05,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .372,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": .41,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/331897/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 331897,
			"release": "4/1/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 with skin drumstick",
				"weightGrams": 104
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 without skin drumstick",
				"weightGrams": 94.7
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 114
			}
		]
	},
	{
		"id": "usda-fdc-2727566",
		"name": "Chicken, drumstick, meat and skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 130,
			"proteinG": 18.4,
			"carbohydrateG": -.475,
			"fatG": 5.94,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 8.28,
					"unit": "mg"
				},
				"iron": {
					"value": .666,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 152,
					"unit": "mg"
				},
				"potassium": {
					"value": 244,
					"unit": "mg"
				},
				"sodium": {
					"value": 91,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.7,
					"unit": "mg"
				},
				"copper": {
					"value": .044,
					"unit": "mg"
				},
				"manganese": {
					"value": .007,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727566/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727566,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2514746",
		"name": "Chicken, ground, with additives, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 138,
			"proteinG": 17.9,
			"carbohydrateG": 0,
			"fatG": 7.16,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 5.82,
					"unit": "mg"
				},
				"iron": {
					"value": .593,
					"unit": "mg"
				},
				"magnesium": {
					"value": 20.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 166,
					"unit": "mg"
				},
				"potassium": {
					"value": 302,
					"unit": "mg"
				},
				"sodium": {
					"value": 63,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.18,
					"unit": "mg"
				},
				"copper": {
					"value": .036,
					"unit": "mg"
				},
				"manganese": {
					"value": .005,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2514746/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2514746,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2646171",
		"name": "Chicken, thigh, boneless, skinless, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 149,
			"proteinG": 18.6,
			"carbohydrateG": 0,
			"fatG": 7.92,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 5.65,
					"unit": "mg"
				},
				"iron": {
					"value": .602,
					"unit": "mg"
				},
				"magnesium": {
					"value": 21.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 178,
					"unit": "mg"
				},
				"potassium": {
					"value": 272,
					"unit": "mg"
				},
				"sodium": {
					"value": 62.3,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.35,
					"unit": "mg"
				},
				"copper": {
					"value": .042,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2646171/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2646171,
			"release": "10/26/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2727567",
		"name": "Chicken, thigh, meat and skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 193,
			"proteinG": 17.1,
			"carbohydrateG": -.173,
			"fatG": 13.4,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 5.73,
					"unit": "mg"
				},
				"iron": {
					"value": .586,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 154,
					"unit": "mg"
				},
				"potassium": {
					"value": 246,
					"unit": "mg"
				},
				"sodium": {
					"value": 63.6,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.2,
					"unit": "mg"
				},
				"copper": {
					"value": .039,
					"unit": "mg"
				},
				"manganese": {
					"value": .003,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727567/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727567,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2727568",
		"name": "Chicken, wing, meat and skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 173,
			"proteinG": 18.4,
			"carbohydrateG": -.459,
			"fatG": 10.6,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 13.6,
					"unit": "mg"
				},
				"iron": {
					"value": .511,
					"unit": "mg"
				},
				"magnesium": {
					"value": 16.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 133,
					"unit": "mg"
				},
				"potassium": {
					"value": 194,
					"unit": "mg"
				},
				"sodium": {
					"value": 84.1,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.18,
					"unit": "mg"
				},
				"copper": {
					"value": .011,
					"unit": "mg"
				},
				"manganese": {
					"value": .003,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727568/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727568,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2644288",
		"name": "Chickpeas (garbanzo beans, bengal gram), canned, sodium added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 133,
			"proteinG": 7.02,
			"carbohydrateG": 20.3,
			"fatG": 3.1,
			"fiberG": 5.92,
			"micronutrients": {
				"calcium": {
					"value": 40.5,
					"unit": "mg"
				},
				"iron": {
					"value": 1.04,
					"unit": "mg"
				},
				"magnesium": {
					"value": 28.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 86.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 137,
					"unit": "mg"
				},
				"sodium": {
					"value": 202,
					"unit": "mg"
				},
				"zinc": {
					"value": .724,
					"unit": "mg"
				},
				"copper": {
					"value": .267,
					"unit": "mg"
				},
				"manganese": {
					"value": .745,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644288/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644288,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2644282",
		"name": "Chickpeas, (garbanzo beans, bengal gram), dry",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 372,
			"proteinG": 21.3,
			"carbohydrateG": 60.4,
			"fatG": 6.27,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 111,
					"unit": "mg"
				},
				"iron": {
					"value": 5.09,
					"unit": "mg"
				},
				"magnesium": {
					"value": 135,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 353,
					"unit": "mg"
				},
				"potassium": {
					"value": 1070,
					"unit": "mg"
				},
				"sodium": {
					"value": 8.78,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.12,
					"unit": "mg"
				},
				"copper": {
					"value": .804,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.58,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644282/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644282,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 35
		}]
	},
	{
		"id": "usda-fdc-2747654",
		"name": "Cod, Pacific or Alaskan, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 60.8,
			"proteinG": 14.2,
			"carbohydrateG": .524,
			"fatG": .216,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 9.01,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 17.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 279,
					"unit": "mg"
				},
				"potassium": {
					"value": 192,
					"unit": "mg"
				},
				"sodium": {
					"value": 354,
					"unit": "mg"
				},
				"zinc": {
					"value": .269,
					"unit": "mg"
				},
				"copper": {
					"value": .009,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 22.3,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .586,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747654/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747654,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2685574",
		"name": "Collards, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 38.8,
			"proteinG": 2.97,
			"carbohydrateG": 7.02,
			"fatG": .77,
			"fiberG": 3.82,
			"micronutrients": {
				"calcium": {
					"value": 276,
					"unit": "mg"
				},
				"iron": {
					"value": .75,
					"unit": "mg"
				},
				"magnesium": {
					"value": 49.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 45,
					"unit": "mg"
				},
				"potassium": {
					"value": 410,
					"unit": "mg"
				},
				"sodium": {
					"value": 18.4,
					"unit": "mg"
				},
				"zinc": {
					"value": .459,
					"unit": "mg"
				},
				"copper": {
					"value": .111,
					"unit": "mg"
				},
				"manganese": {
					"value": .872,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 89.4,
					"unit": "mg"
				},
				"folate": {
					"value": 168,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685574/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685574,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-333008",
		"name": "Cookies, oatmeal, soft, with raisins",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 430,
			"proteinG": 5.79,
			"carbohydrateG": 69.6,
			"fatG": 14.3,
			"fiberG": 3.3,
			"micronutrients": {
				"calcium": {
					"value": 29,
					"unit": "mg"
				},
				"iron": {
					"value": 2.28,
					"unit": "mg"
				},
				"magnesium": {
					"value": 32.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 111,
					"unit": "mg"
				},
				"potassium": {
					"value": 245,
					"unit": "mg"
				},
				"sodium": {
					"value": 314,
					"unit": "mg"
				},
				"zinc": {
					"value": .62,
					"unit": "mg"
				},
				"copper": {
					"value": .141,
					"unit": "mg"
				},
				"manganese": {
					"value": .755,
					"unit": "mg"
				},
				"selenium": {
					"value": 6,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 2.69,
					"unit": "mg"
				},
				"thiamin": {
					"value": .295,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .218,
					"unit": "mg"
				},
				"niacin": {
					"value": 2.11,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .07,
					"unit": "mg"
				},
				"folate": {
					"value": 34,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 17.1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/333008/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 333008,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cookie",
			"weightGrams": 27
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2710835",
		"name": "Corn flour, masa harina, white or yellow, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 366,
			"proteinG": 7.56,
			"carbohydrateG": 76.7,
			"fatG": 4.34,
			"fiberG": 7.04,
			"micronutrients": {
				"calcium": {
					"value": 112,
					"unit": "mg"
				},
				"iron": {
					"value": 1.7,
					"unit": "mg"
				},
				"magnesium": {
					"value": 93.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 241,
					"unit": "mg"
				},
				"potassium": {
					"value": 277,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.73,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.62,
					"unit": "mg"
				},
				"copper": {
					"value": .13,
					"unit": "mg"
				},
				"manganese": {
					"value": .413,
					"unit": "mg"
				},
				"thiamin": {
					"value": .233,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.69,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .229,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710835/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710835,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2710826",
		"name": "Corn, sweet, yellow and white kernels, \xA0fresh, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 72.9,
			"proteinG": 2.79,
			"carbohydrateG": 14.7,
			"fatG": 1.63,
			"fiberG": 2.43,
			"micronutrients": {
				"calcium": {
					"value": .656,
					"unit": "mg"
				},
				"iron": {
					"value": .388,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 75.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 237,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .556,
					"unit": "mg"
				},
				"copper": {
					"value": .056,
					"unit": "mg"
				},
				"manganese": {
					"value": .19,
					"unit": "mg"
				},
				"thiamin": {
					"value": .079,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .138,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.59,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .15,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710826/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710826,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2346384",
		"name": "Cottage cheese, full fat, large or small curd",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 105,
			"proteinG": 11.6,
			"carbohydrateG": 4.6,
			"fatG": 4.22,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 88.3,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9.19,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 154,
					"unit": "mg"
				},
				"potassium": {
					"value": 124,
					"unit": "mg"
				},
				"sodium": {
					"value": 350,
					"unit": "mg"
				},
				"zinc": {
					"value": .454,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .052,
					"unit": "mg"
				},
				"niacin": {
					"value": .138,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .047,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": .662,
					"unit": "µg"
				},
				"vitaminK": {
					"value": .2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346384/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346384,
			"release": "10/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-2003594",
		"name": "Cranberry juice, not fortified, from concentrate, shelf stable",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 31.3,
			"proteinG": 0,
			"carbohydrateG": 7.26,
			"fatG": .338,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6.64,
					"unit": "mg"
				},
				"iron": {
					"value": .126,
					"unit": "mg"
				},
				"magnesium": {
					"value": 4.38,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 3.3,
					"unit": "mg"
				},
				"potassium": {
					"value": 70.6,
					"unit": "mg"
				},
				"sodium": {
					"value": 6.34,
					"unit": "mg"
				},
				"zinc": {
					"value": .041,
					"unit": "mg"
				},
				"copper": {
					"value": .013,
					"unit": "mg"
				},
				"manganese": {
					"value": .211,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .018,
					"unit": "mg"
				},
				"niacin": {
					"value": .009,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .009,
					"unit": "mg"
				},
				"folate": {
					"value": 8.97,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003594/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003594,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2346385",
		"name": "Cream cheese, full fat, block",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 337,
			"proteinG": 5.79,
			"carbohydrateG": 4.56,
			"fatG": 33.5,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 97.1,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.91,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 108,
					"unit": "mg"
				},
				"potassium": {
					"value": 125,
					"unit": "mg"
				},
				"sodium": {
					"value": 368,
					"unit": "mg"
				},
				"zinc": {
					"value": .589,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .038,
					"unit": "mg"
				},
				"niacin": {
					"value": .092,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .039,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 2.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346385/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346385,
			"release": "10/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2346386",
		"name": "Cream, heavy",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 336,
			"proteinG": 2.02,
			"carbohydrateG": 3.8,
			"fatG": 35.6,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 61.2,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 5.97,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 57,
					"unit": "mg"
				},
				"potassium": {
					"value": 96.9,
					"unit": "mg"
				},
				"sodium": {
					"value": 20.6,
					"unit": "mg"
				},
				"zinc": {
					"value": .223,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .032,
					"unit": "mg"
				},
				"niacin": {
					"value": .061,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .031,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 2.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346386/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346386,
			"release": "10/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 15
		}]
	},
	{
		"id": "usda-fdc-2346387",
		"name": "Cream, sour, full fat",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 193,
			"proteinG": 3.07,
			"carbohydrateG": 5.56,
			"fatG": 18,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 107,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 102,
					"unit": "mg"
				},
				"potassium": {
					"value": 154,
					"unit": "mg"
				},
				"sodium": {
					"value": 50,
					"unit": "mg"
				},
				"zinc": {
					"value": .392,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .043,
					"unit": "mg"
				},
				"niacin": {
					"value": .1,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .038,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": .062,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 1.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346387/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346387,
			"release": "10/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2684446",
		"name": "Crustaceans, crab, blue swimming, lump, pasteurized, refrigerated",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 86,
			"proteinG": 18.6,
			"carbohydrateG": 0,
			"fatG": .808,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 111,
					"unit": "mg"
				},
				"iron": {
					"value": .632,
					"unit": "mg"
				},
				"magnesium": {
					"value": 43.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 278,
					"unit": "mg"
				},
				"potassium": {
					"value": 235,
					"unit": "mg"
				},
				"sodium": {
					"value": 331,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.48,
					"unit": "mg"
				},
				"copper": {
					"value": 1.09,
					"unit": "mg"
				},
				"manganese": {
					"value": .148,
					"unit": "mg"
				},
				"selenium": {
					"value": 45.8,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 3.12,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2684446/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2684446,
			"release": "4/18/2024"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2684443",
		"name": "Crustaceans, shrimp, farm raised, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 75.7,
			"proteinG": 15.6,
			"carbohydrateG": .485,
			"fatG": .801,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 64.6,
					"unit": "mg"
				},
				"iron": {
					"value": .522,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 191,
					"unit": "mg"
				},
				"potassium": {
					"value": 146,
					"unit": "mg"
				},
				"sodium": {
					"value": 475,
					"unit": "mg"
				},
				"zinc": {
					"value": .937,
					"unit": "mg"
				},
				"copper": {
					"value": .208,
					"unit": "mg"
				},
				"manganese": {
					"value": .029,
					"unit": "mg"
				},
				"selenium": {
					"value": 19.5,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .996,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2684443/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2684443,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 115
		}]
	},
	{
		"id": "usda-fdc-2346406",
		"name": "Cucumber, with peel, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 13.9,
			"proteinG": .625,
			"carbohydrateG": 2.95,
			"fatG": .178,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 16.3,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 23.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 170,
					"unit": "mg"
				},
				"sodium": {
					"value": 1.52,
					"unit": "mg"
				},
				"zinc": {
					"value": .204,
					"unit": "mg"
				},
				"copper": {
					"value": .063,
					"unit": "mg"
				},
				"manganese": {
					"value": .085,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 24,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346406/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346406,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-323793",
		"name": "Egg, white, dried",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 376,
			"proteinG": 79.9,
			"carbohydrateG": 6.02,
			"fatG": .65,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 104,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 87.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 107,
					"unit": "mg"
				},
				"potassium": {
					"value": 959,
					"unit": "mg"
				},
				"sodium": {
					"value": 1250,
					"unit": "mg"
				},
				"zinc": {
					"value": .43,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/323793/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 323793,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 tbsp",
			"weightGrams": 7
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 sifted cup",
			"weightGrams": 107
		}]
	},
	{
		"id": "usda-fdc-323697",
		"name": "Egg, white, raw, frozen, pasteurized",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 48,
			"proteinG": 10.1,
			"carbohydrateG": .74,
			"fatG": .16,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 9,
					"unit": "mg"
				},
				"iron": {
					"value": .18,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 0,
					"unit": "mg"
				},
				"potassium": {
					"value": 130,
					"unit": "mg"
				},
				"sodium": {
					"value": 144,
					"unit": "mg"
				},
				"zinc": {
					"value": .02,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/323697/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 323697,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 oz",
			"weightGrams": 28.4
		}]
	},
	{
		"id": "usda-fdc-329490",
		"name": "Egg, whole, dried",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 575,
			"proteinG": 48.1,
			"carbohydrateG": 1.87,
			"fatG": 39.8,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 220,
					"unit": "mg"
				},
				"iron": {
					"value": 6.97,
					"unit": "mg"
				},
				"magnesium": {
					"value": 44.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 770,
					"unit": "mg"
				},
				"potassium": {
					"value": 468,
					"unit": "mg"
				},
				"sodium": {
					"value": 485,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.02,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 9.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/329490/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 329490,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 sifted cup",
				"weightGrams": 85
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 tbsp",
				"weightGrams": 5
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 oz",
				"weightGrams": 28.4
			}
		]
	},
	{
		"id": "usda-fdc-323604",
		"name": "Egg, whole, raw, frozen, pasteurized",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 150,
			"proteinG": 12.3,
			"carbohydrateG": .91,
			"fatG": 10.3,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 55,
					"unit": "mg"
				},
				"iron": {
					"value": 1.77,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 189,
					"unit": "mg"
				},
				"potassium": {
					"value": 117,
					"unit": "mg"
				},
				"sodium": {
					"value": 121,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.2,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 2.3,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/323604/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 323604,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 oz",
			"weightGrams": 28.4
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 50
		}]
	},
	{
		"id": "usda-fdc-329716",
		"name": "Egg, yolk, dried",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 654,
			"proteinG": 34.2,
			"carbohydrateG": 1.07,
			"fatG": 55.5,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 270,
					"unit": "mg"
				},
				"iron": {
					"value": 9.28,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 982,
					"unit": "mg"
				},
				"potassium": {
					"value": 231,
					"unit": "mg"
				},
				"sodium": {
					"value": 149,
					"unit": "mg"
				},
				"zinc": {
					"value": 7.11,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 15.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/329716/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 329716,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 tbsp",
				"weightGrams": 4
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 sifted cup",
				"weightGrams": 67
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 oz",
				"weightGrams": 28.4
			}
		]
	},
	{
		"id": "usda-fdc-329596",
		"name": "Egg, yolk, raw, frozen, pasteurized",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 296,
			"proteinG": 15.6,
			"carbohydrateG": .59,
			"fatG": 25.1,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 119,
					"unit": "mg"
				},
				"iron": {
					"value": 4.13,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 443,
					"unit": "mg"
				},
				"potassium": {
					"value": 102,
					"unit": "mg"
				},
				"sodium": {
					"value": 66,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.93,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .068,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 5.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/329596/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 329596,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 oz",
			"weightGrams": 28.4
		}]
	},
	{
		"id": "usda-fdc-2685577",
		"name": "Eggplant, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 22.4,
			"proteinG": .852,
			"carbohydrateG": 5.4,
			"fatG": .12,
			"fiberG": 2.45,
			"micronutrients": {
				"calcium": {
					"value": 11.1,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 22.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 222,
					"unit": "mg"
				},
				"sodium": {
					"value": .442,
					"unit": "mg"
				},
				"zinc": {
					"value": .119,
					"unit": "mg"
				},
				"copper": {
					"value": .061,
					"unit": "mg"
				},
				"manganese": {
					"value": .106,
					"unit": "mg"
				},
				"vitaminC": {
					"value": .8,
					"unit": "mg"
				},
				"folate": {
					"value": 20,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685577/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685577,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-747997",
		"name": "Eggs, Grade A, Large, egg white",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 55,
			"proteinG": 10.7,
			"carbohydrateG": 2.36,
			"fatG": 0,
			"fiberG": null,
			"micronutrients": {
				"selenium": {
					"value": 17.9,
					"unit": "µg"
				},
				"riboflavin": {
					"value": .391,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747997/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747997,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 white egg",
			"weightGrams": 34
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 50
		}]
	},
	{
		"id": "usda-fdc-748967",
		"name": "Eggs, Grade A, Large, egg whole",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 148,
			"proteinG": 12.4,
			"carbohydrateG": .96,
			"fatG": 9.96,
			"fiberG": 0,
			"micronutrients": {
				"calcium": {
					"value": 48,
					"unit": "mg"
				},
				"iron": {
					"value": 1.67,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 184,
					"unit": "mg"
				},
				"potassium": {
					"value": 132,
					"unit": "mg"
				},
				"sodium": {
					"value": 129,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.24,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 31.1,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 180,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 2.46,
					"unit": "µg"
				},
				"thiamin": {
					"value": .077,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .419,
					"unit": "mg"
				},
				"niacin": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .063,
					"unit": "mg"
				},
				"folate": {
					"value": 71,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.02,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/748967/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 748967,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 whole without shell egg",
			"weightGrams": 50.3
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 50
		}]
	},
	{
		"id": "usda-fdc-748236",
		"name": "Eggs, Grade A, Large, egg yolk",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 334,
			"proteinG": 16.2,
			"carbohydrateG": 1.02,
			"fatG": 28.8,
			"fiberG": null,
			"micronutrients": {
				"selenium": {
					"value": 55.8,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 5.64,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .467,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/748236/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 748236,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 yolk egg",
			"weightGrams": 17
		}]
	},
	{
		"id": "usda-fdc-2710827",
		"name": "Einkorn, grain, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 346,
			"proteinG": 15.1,
			"carbohydrateG": 68.7,
			"fatG": 3.81,
			"fiberG": 8.91,
			"micronutrients": {
				"calcium": {
					"value": 41.4,
					"unit": "mg"
				},
				"iron": {
					"value": 3.69,
					"unit": "mg"
				},
				"magnesium": {
					"value": 140,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 436,
					"unit": "mg"
				},
				"potassium": {
					"value": 432,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.23,
					"unit": "mg"
				},
				"copper": {
					"value": .549,
					"unit": "mg"
				},
				"manganese": {
					"value": 4.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": .49,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.69,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .264,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710827/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710827,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2710828",
		"name": "Farro, pearled, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 344,
			"proteinG": 12.6,
			"carbohydrateG": 72.1,
			"fatG": 3.1,
			"fiberG": 7.31,
			"micronutrients": {
				"calcium": {
					"value": 25.9,
					"unit": "mg"
				},
				"iron": {
					"value": 3.2,
					"unit": "mg"
				},
				"magnesium": {
					"value": 119,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 368,
					"unit": "mg"
				},
				"potassium": {
					"value": 385,
					"unit": "mg"
				},
				"sodium": {
					"value": .845,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.97,
					"unit": "mg"
				},
				"copper": {
					"value": .47,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.6,
					"unit": "mg"
				},
				"thiamin": {
					"value": .376,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.82,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .235,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710828/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710828,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2747655",
		"name": "Fennel, bulb, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 26.9,
			"proteinG": .922,
			"carbohydrateG": 5.49,
			"fatG": .14,
			"fiberG": 2.05,
			"micronutrients": {
				"calcium": {
					"value": 41.3,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 33.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 332,
					"unit": "mg"
				},
				"sodium": {
					"value": 49,
					"unit": "mg"
				},
				"zinc": {
					"value": .141,
					"unit": "mg"
				},
				"copper": {
					"value": .073,
					"unit": "mg"
				},
				"manganese": {
					"value": .124,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 14.7,
					"unit": "mg"
				},
				"folate": {
					"value": 37,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747655/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747655,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-746768",
		"name": "Figs, dried, uncooked",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 249,
			"proteinG": 3.3,
			"carbohydrateG": 63.9,
			"fatG": .92,
			"fiberG": 9.8,
			"micronutrients": {
				"calcium": {
					"value": 162,
					"unit": "mg"
				},
				"iron": {
					"value": 2.03,
					"unit": "mg"
				},
				"magnesium": {
					"value": 67.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 67,
					"unit": "mg"
				},
				"potassium": {
					"value": 680,
					"unit": "mg"
				},
				"sodium": {
					"value": 10,
					"unit": "mg"
				},
				"zinc": {
					"value": .66,
					"unit": "mg"
				},
				"copper": {
					"value": .287,
					"unit": "mg"
				},
				"manganese": {
					"value": .51,
					"unit": "mg"
				},
				"selenium": {
					"value": .6,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .36,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 1.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": .085,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .082,
					"unit": "mg"
				},
				"niacin": {
					"value": .619,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .106,
					"unit": "mg"
				},
				"folate": {
					"value": 9,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 15.6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746768/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746768,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 each",
				"weightGrams": 8.4
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 cup",
				"weightGrams": 149
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 140
			}
		]
	},
	{
		"id": "usda-fdc-2684445",
		"name": "Fish, catfish, farm raised, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 134,
			"proteinG": 16.5,
			"carbohydrateG": 0,
			"fatG": 7.31,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 7.8,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 20.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 166,
					"unit": "mg"
				},
				"potassium": {
					"value": 292,
					"unit": "mg"
				},
				"sodium": {
					"value": 60.5,
					"unit": "mg"
				},
				"zinc": {
					"value": .475,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				},
				"selenium": {
					"value": 9.28,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 2.27,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2684445/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2684445,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 115
		}]
	},
	{
		"id": "usda-fdc-2684444",
		"name": "Fish, cod, Atlantic, wild caught, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 70.5,
			"proteinG": 16.1,
			"carbohydrateG": 0,
			"fatG": .668,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6.59,
					"unit": "mg"
				},
				"iron": {
					"value": .065,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 224,
					"unit": "mg"
				},
				"potassium": {
					"value": 245,
					"unit": "mg"
				},
				"sodium": {
					"value": 299,
					"unit": "mg"
				},
				"zinc": {
					"value": .305,
					"unit": "mg"
				},
				"copper": {
					"value": .004,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 22.8,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.25,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2684444/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2684444,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 115
		}]
	},
	{
		"id": "usda-fdc-333374",
		"name": "Fish, haddock, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 74,
			"proteinG": 16.3,
			"carbohydrateG": 0,
			"fatG": .45,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 11,
					"unit": "mg"
				},
				"iron": {
					"value": .17,
					"unit": "mg"
				},
				"magnesium": {
					"value": 21.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 227,
					"unit": "mg"
				},
				"potassium": {
					"value": 286,
					"unit": "mg"
				},
				"sodium": {
					"value": 213,
					"unit": "mg"
				},
				"zinc": {
					"value": .32,
					"unit": "mg"
				},
				"copper": {
					"value": .021,
					"unit": "mg"
				},
				"manganese": {
					"value": .011,
					"unit": "mg"
				},
				"selenium": {
					"value": 25.9,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .45,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .5,
					"unit": "µg"
				},
				"thiamin": {
					"value": .02,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .057,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.36,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .281,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.83,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/333374/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 333374,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 fillet",
			"weightGrams": 176
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 115
		}]
	},
	{
		"id": "usda-fdc-333476",
		"name": "Fish, pollock, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 56,
			"proteinG": 12.3,
			"carbohydrateG": 0,
			"fatG": .41,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 15,
					"unit": "mg"
				},
				"iron": {
					"value": .22,
					"unit": "mg"
				},
				"magnesium": {
					"value": 16.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 284,
					"unit": "mg"
				},
				"potassium": {
					"value": 160,
					"unit": "mg"
				},
				"sodium": {
					"value": 333,
					"unit": "mg"
				},
				"zinc": {
					"value": .31,
					"unit": "mg"
				},
				"copper": {
					"value": .031,
					"unit": "mg"
				},
				"manganese": {
					"value": .011,
					"unit": "mg"
				},
				"selenium": {
					"value": 15.9,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 3,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .49,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .2,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .03,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .08,
					"unit": "mg"
				},
				"niacin": {
					"value": .653,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .069,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.63,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/333476/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 333476,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 fillet",
			"weightGrams": 177
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 115
		}]
	},
	{
		"id": "usda-fdc-2684441",
		"name": "Fish, salmon, Atlantic, farm raised, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 203,
			"proteinG": 20.3,
			"carbohydrateG": 0,
			"fatG": 13.1,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 9.42,
					"unit": "mg"
				},
				"iron": {
					"value": .259,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 230,
					"unit": "mg"
				},
				"potassium": {
					"value": 378,
					"unit": "mg"
				},
				"sodium": {
					"value": 49.5,
					"unit": "mg"
				},
				"zinc": {
					"value": .339,
					"unit": "mg"
				},
				"copper": {
					"value": .025,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 22.8,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 5.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2684441/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2684441,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 115
		}]
	},
	{
		"id": "usda-fdc-2684440",
		"name": "Fish, salmon, sockeye, wild caught, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 136,
			"proteinG": 22.3,
			"carbohydrateG": 0,
			"fatG": 4.94,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 14.8,
					"unit": "mg"
				},
				"iron": {
					"value": .402,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 226,
					"unit": "mg"
				},
				"potassium": {
					"value": 330,
					"unit": "mg"
				},
				"sodium": {
					"value": 53.3,
					"unit": "mg"
				},
				"zinc": {
					"value": .425,
					"unit": "mg"
				},
				"copper": {
					"value": .062,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 30.2,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 5.16,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2684440/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2684440,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 115
		}]
	},
	{
		"id": "usda-fdc-2684442",
		"name": "Fish, tilapia, farm raised, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 100,
			"proteinG": 19,
			"carbohydrateG": 0,
			"fatG": 2.48,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 8.63,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 24.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 159,
					"unit": "mg"
				},
				"potassium": {
					"value": 342,
					"unit": "mg"
				},
				"sodium": {
					"value": 93.7,
					"unit": "mg"
				},
				"zinc": {
					"value": .3,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .005,
					"unit": "mg"
				},
				"selenium": {
					"value": 20.5,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .759,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2684442/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2684442,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 115
		}]
	},
	{
		"id": "usda-fdc-334194",
		"name": "Fish, tuna, light, canned in water, drained solids",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 90,
			"proteinG": 19,
			"carbohydrateG": .08,
			"fatG": .94,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 18,
					"unit": "mg"
				},
				"iron": {
					"value": 1.67,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 137,
					"unit": "mg"
				},
				"potassium": {
					"value": 176,
					"unit": "mg"
				},
				"sodium": {
					"value": 219,
					"unit": "mg"
				},
				"zinc": {
					"value": .66,
					"unit": "mg"
				},
				"copper": {
					"value": .048,
					"unit": "mg"
				},
				"manganese": {
					"value": .019,
					"unit": "mg"
				},
				"selenium": {
					"value": 67.8,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 1.2,
					"unit": "µg"
				},
				"thiamin": {
					"value": .03,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .082,
					"unit": "mg"
				},
				"niacin": {
					"value": 9.92,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .32,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 2.57,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/334194/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 334194,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 total can contents can",
				"weightGrams": 142
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 drained solids can",
				"weightGrams": 107
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 85
			}
		]
	},
	{
		"id": "usda-fdc-2262075",
		"name": "Flaxseed, ground",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 514,
			"proteinG": 18,
			"carbohydrateG": 34.4,
			"fatG": 37.3,
			"fiberG": 23.1,
			"micronutrients": {
				"calcium": {
					"value": 230,
					"unit": "mg"
				},
				"iron": {
					"value": 5.78,
					"unit": "mg"
				},
				"magnesium": {
					"value": 372,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 556,
					"unit": "mg"
				},
				"potassium": {
					"value": 793,
					"unit": "mg"
				},
				"sodium": {
					"value": 36.7,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.74,
					"unit": "mg"
				},
				"copper": {
					"value": 1.34,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.4,
					"unit": "mg"
				},
				"selenium": {
					"value": 136,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .537,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.76,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .393,
					"unit": "mg"
				},
				"folate": {
					"value": 41.4,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 3.68,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2262075/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2262075,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 15
		}]
	},
	{
		"id": "usda-fdc-2003586",
		"name": "Flour, 00",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 366,
			"proteinG": 11.4,
			"carbohydrateG": 74.4,
			"fatG": 1.52,
			"fiberG": 2.66,
			"micronutrients": {
				"calcium": {
					"value": 18.7,
					"unit": "mg"
				},
				"iron": {
					"value": .986,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 106,
					"unit": "mg"
				},
				"potassium": {
					"value": 136,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .791,
					"unit": "mg"
				},
				"copper": {
					"value": .168,
					"unit": "mg"
				},
				"manganese": {
					"value": .552,
					"unit": "mg"
				},
				"selenium": {
					"value": 10.3,
					"unit": "µg"
				},
				"thiamin": {
					"value": .125,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .091,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.36,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .055,
					"unit": "mg"
				},
				"folate": {
					"value": 13.5,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003586/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003586,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2261420",
		"name": "Flour, almond",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 578,
			"proteinG": 26.2,
			"carbohydrateG": 16.2,
			"fatG": 50.2,
			"fiberG": 9.27,
			"micronutrients": {
				"calcium": {
					"value": 232,
					"unit": "mg"
				},
				"iron": {
					"value": 3.22,
					"unit": "mg"
				},
				"magnesium": {
					"value": 251,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 512,
					"unit": "mg"
				},
				"potassium": {
					"value": 667,
					"unit": "mg"
				},
				"sodium": {
					"value": .894,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.8,
					"unit": "mg"
				},
				"copper": {
					"value": .975,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.81,
					"unit": "mg"
				},
				"selenium": {
					"value": .742,
					"unit": "µg"
				},
				"thiamin": {
					"value": .112,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .748,
					"unit": "mg"
				},
				"niacin": {
					"value": 4,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .1,
					"unit": "mg"
				},
				"folate": {
					"value": 37.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2261420/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2261420,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 15
		}]
	},
	{
		"id": "usda-fdc-2512371",
		"name": "Flour, amaranth",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 378,
			"proteinG": 13.2,
			"carbohydrateG": 68.8,
			"fatG": 6.24,
			"fiberG": 7.21,
			"micronutrients": {
				"calcium": {
					"value": 135,
					"unit": "mg"
				},
				"iron": {
					"value": 7.56,
					"unit": "mg"
				},
				"magnesium": {
					"value": 233,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 425,
					"unit": "mg"
				},
				"potassium": {
					"value": 396,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 3,
					"unit": "mg"
				},
				"copper": {
					"value": .518,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.3,
					"unit": "mg"
				},
				"selenium": {
					"value": 21.1,
					"unit": "µg"
				},
				"thiamin": {
					"value": .059,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .175,
					"unit": "mg"
				},
				"niacin": {
					"value": .748,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .387,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512371/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512371,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2512376",
		"name": "Flour, barley",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 357,
			"proteinG": 8.72,
			"carbohydrateG": 77.4,
			"fatG": 2.45,
			"fiberG": 12.8,
			"micronutrients": {
				"calcium": {
					"value": 35.6,
					"unit": "mg"
				},
				"iron": {
					"value": 3.3,
					"unit": "mg"
				},
				"magnesium": {
					"value": 88,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 234,
					"unit": "mg"
				},
				"potassium": {
					"value": 367,
					"unit": "mg"
				},
				"sodium": {
					"value": 20.3,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.14,
					"unit": "mg"
				},
				"copper": {
					"value": .394,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.18,
					"unit": "mg"
				},
				"selenium": {
					"value": 13.1,
					"unit": "µg"
				},
				"thiamin": {
					"value": .225,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .146,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.94,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .2,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512376/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512376,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-790146",
		"name": "Flour, bread, white, enriched, unbleached",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 363,
			"proteinG": 14.3,
			"carbohydrateG": 72.8,
			"fatG": 1.65,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 19,
					"unit": "mg"
				},
				"iron": {
					"value": 5.55,
					"unit": "mg"
				},
				"magnesium": {
					"value": 35.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 124,
					"unit": "mg"
				},
				"potassium": {
					"value": 127,
					"unit": "mg"
				},
				"sodium": {
					"value": 3,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.06,
					"unit": "mg"
				},
				"copper": {
					"value": .194,
					"unit": "mg"
				},
				"manganese": {
					"value": .751,
					"unit": "mg"
				},
				"selenium": {
					"value": 33.3,
					"unit": "µg"
				},
				"thiamin": {
					"value": .953,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .436,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.56,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .079,
					"unit": "mg"
				},
				"folate": {
					"value": 145,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/790146/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 790146,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2512374",
		"name": "Flour, buckwheat",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 334,
			"proteinG": 8.88,
			"carbohydrateG": 75,
			"fatG": 2.48,
			"fiberG": 10.4,
			"micronutrients": {
				"calcium": {
					"value": 30.6,
					"unit": "mg"
				},
				"iron": {
					"value": 3.84,
					"unit": "mg"
				},
				"magnesium": {
					"value": 167,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 282,
					"unit": "mg"
				},
				"potassium": {
					"value": 378,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.76,
					"unit": "mg"
				},
				"copper": {
					"value": .53,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.54,
					"unit": "mg"
				},
				"selenium": {
					"value": 15.7,
					"unit": "µg"
				},
				"thiamin": {
					"value": .241,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .16,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.84,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .17,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512374/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512374,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2512377",
		"name": "Flour, cassava",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 359,
			"proteinG": .918,
			"carbohydrateG": 87.3,
			"fatG": .494,
			"fiberG": 4.83,
			"micronutrients": {
				"calcium": {
					"value": 74.6,
					"unit": "mg"
				},
				"iron": {
					"value": 3.99,
					"unit": "mg"
				},
				"magnesium": {
					"value": 33.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 39.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 198,
					"unit": "mg"
				},
				"sodium": {
					"value": 13.1,
					"unit": "mg"
				},
				"zinc": {
					"value": .41,
					"unit": "mg"
				},
				"copper": {
					"value": .077,
					"unit": "mg"
				},
				"manganese": {
					"value": .395,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .051,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .068,
					"unit": "mg"
				},
				"niacin": {
					"value": .6,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .05,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512377/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512377,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2515377",
		"name": "Flour, chestnut",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 385,
			"proteinG": 5.29,
			"carbohydrateG": 80.5,
			"fatG": 4.64,
			"fiberG": 8.71,
			"micronutrients": {
				"calcium": {
					"value": 55.8,
					"unit": "mg"
				},
				"iron": {
					"value": 1.62,
					"unit": "mg"
				},
				"magnesium": {
					"value": 68.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 134,
					"unit": "mg"
				},
				"potassium": {
					"value": 1030,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.04,
					"unit": "mg"
				},
				"copper": {
					"value": .581,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.9,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 4.05,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515377/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515377,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2515382",
		"name": "Flour, coconut",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 424,
			"proteinG": 16.1,
			"carbohydrateG": 58.9,
			"fatG": 15.3,
			"fiberG": 34.2,
			"micronutrients": {
				"calcium": {
					"value": 36,
					"unit": "mg"
				},
				"iron": {
					"value": 8.02,
					"unit": "mg"
				},
				"magnesium": {
					"value": 248,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 507,
					"unit": "mg"
				},
				"potassium": {
					"value": 2090,
					"unit": "mg"
				},
				"sodium": {
					"value": 46.9,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.7,
					"unit": "mg"
				},
				"copper": {
					"value": 2.08,
					"unit": "mg"
				},
				"manganese": {
					"value": 5.29,
					"unit": "mg"
				},
				"selenium": {
					"value": 26.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515382/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515382,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 15
		}]
	},
	{
		"id": "usda-fdc-790276",
		"name": "Flour, corn, yellow, fine meal, enriched",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 364,
			"proteinG": 6.2,
			"carbohydrateG": 80.8,
			"fatG": 1.74,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 0,
					"unit": "mg"
				},
				"iron": {
					"value": 4.44,
					"unit": "mg"
				},
				"magnesium": {
					"value": 30.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 92,
					"unit": "mg"
				},
				"potassium": {
					"value": 144,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .62,
					"unit": "mg"
				},
				"copper": {
					"value": .082,
					"unit": "mg"
				},
				"manganese": {
					"value": .172,
					"unit": "mg"
				},
				"selenium": {
					"value": 8.3,
					"unit": "µg"
				},
				"thiamin": {
					"value": .662,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .354,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.75,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .13,
					"unit": "mg"
				},
				"folate": {
					"value": 155,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/790276/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 790276,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2261421",
		"name": "Flour, oat, whole grain",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 386,
			"proteinG": 13.2,
			"carbohydrateG": 69.9,
			"fatG": 6.31,
			"fiberG": 10.5,
			"micronutrients": {
				"calcium": {
					"value": 42.8,
					"unit": "mg"
				},
				"iron": {
					"value": 4,
					"unit": "mg"
				},
				"magnesium": {
					"value": 125,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 372,
					"unit": "mg"
				},
				"potassium": {
					"value": 373,
					"unit": "mg"
				},
				"sodium": {
					"value": 3.62,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.75,
					"unit": "mg"
				},
				"copper": {
					"value": .443,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.26,
					"unit": "mg"
				},
				"selenium": {
					"value": 38.2,
					"unit": "µg"
				},
				"thiamin": {
					"value": .39,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .161,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.94,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .148,
					"unit": "mg"
				},
				"folate": {
					"value": 34.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2261421/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2261421,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-1104913",
		"name": "Flour, pastry, unenriched, unbleached",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 358,
			"proteinG": 8.75,
			"carbohydrateG": 77.2,
			"fatG": 1.64,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 17,
					"unit": "mg"
				},
				"iron": {
					"value": .87,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 102,
					"unit": "mg"
				},
				"potassium": {
					"value": 142,
					"unit": "mg"
				},
				"sodium": {
					"value": 1,
					"unit": "mg"
				},
				"zinc": {
					"value": .74,
					"unit": "mg"
				},
				"copper": {
					"value": .159,
					"unit": "mg"
				},
				"manganese": {
					"value": .635,
					"unit": "mg"
				},
				"selenium": {
					"value": 5,
					"unit": "µg"
				},
				"thiamin": {
					"value": .146,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": .988,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .065,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1104913/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1104913,
			"release": "10/30/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2261422",
		"name": "Flour, potato",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 353,
			"proteinG": 8.11,
			"carbohydrateG": 79.9,
			"fatG": .951,
			"fiberG": 5.4,
			"micronutrients": {
				"calcium": {
					"value": 44.1,
					"unit": "mg"
				},
				"iron": {
					"value": 12,
					"unit": "mg"
				},
				"magnesium": {
					"value": 73.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 197,
					"unit": "mg"
				},
				"potassium": {
					"value": 1270,
					"unit": "mg"
				},
				"sodium": {
					"value": 47.7,
					"unit": "mg"
				},
				"zinc": {
					"value": .9,
					"unit": "mg"
				},
				"copper": {
					"value": .231,
					"unit": "mg"
				},
				"manganese": {
					"value": .676,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.42,
					"unit": "µg"
				},
				"thiamin": {
					"value": .198,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .115,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.63,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .582,
					"unit": "mg"
				},
				"folate": {
					"value": 41.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2261422/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2261422,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2512372",
		"name": "Flour, quinoa",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 378,
			"proteinG": 11.9,
			"carbohydrateG": 69.5,
			"fatG": 6.6,
			"fiberG": 6.3,
			"micronutrients": {
				"calcium": {
					"value": 37.6,
					"unit": "mg"
				},
				"iron": {
					"value": 4.53,
					"unit": "mg"
				},
				"magnesium": {
					"value": 164,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 369,
					"unit": "mg"
				},
				"potassium": {
					"value": 551,
					"unit": "mg"
				},
				"sodium": {
					"value": 6.32,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.77,
					"unit": "mg"
				},
				"copper": {
					"value": .482,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.02,
					"unit": "mg"
				},
				"selenium": {
					"value": 4.1,
					"unit": "µg"
				},
				"thiamin": {
					"value": .345,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .316,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.21,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .222,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512372/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512372,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-1104812",
		"name": "Flour, rice, brown",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 365,
			"proteinG": 7.19,
			"carbohydrateG": 75.5,
			"fatG": 3.85,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 10,
					"unit": "mg"
				},
				"iron": {
					"value": 1.5,
					"unit": "mg"
				},
				"magnesium": {
					"value": 124,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 319,
					"unit": "mg"
				},
				"potassium": {
					"value": 265,
					"unit": "mg"
				},
				"sodium": {
					"value": 1,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.91,
					"unit": "mg"
				},
				"copper": {
					"value": .286,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.84,
					"unit": "mg"
				},
				"selenium": {
					"value": 9.68,
					"unit": "µg"
				},
				"thiamin": {
					"value": .322,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .008,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.99,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .132,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1104812/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1104812,
			"release": "10/30/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-1104867",
		"name": "Flour, rice, glutinous",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 358,
			"proteinG": 6.69,
			"carbohydrateG": 80.1,
			"fatG": 1.16,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 10,
					"unit": "mg"
				},
				"iron": {
					"value": .34,
					"unit": "mg"
				},
				"magnesium": {
					"value": 21.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 63,
					"unit": "mg"
				},
				"potassium": {
					"value": 80,
					"unit": "mg"
				},
				"sodium": {
					"value": 6,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.34,
					"unit": "mg"
				},
				"copper": {
					"value": .17,
					"unit": "mg"
				},
				"manganese": {
					"value": .995,
					"unit": "mg"
				},
				"selenium": {
					"value": 2,
					"unit": "µg"
				},
				"thiamin": {
					"value": .053,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.12,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .044,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1104867/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1104867,
			"release": "10/30/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-790214",
		"name": "Flour, rice, white, unenriched",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 359,
			"proteinG": 6.94,
			"carbohydrateG": 79.8,
			"fatG": 1.3,
			"fiberG": .5,
			"micronutrients": {
				"calcium": {
					"value": 6,
					"unit": "mg"
				},
				"iron": {
					"value": .22,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 94,
					"unit": "mg"
				},
				"potassium": {
					"value": 75,
					"unit": "mg"
				},
				"sodium": {
					"value": 5,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.19,
					"unit": "mg"
				},
				"copper": {
					"value": .209,
					"unit": "mg"
				},
				"manganese": {
					"value": .892,
					"unit": "mg"
				},
				"selenium": {
					"value": 5.3,
					"unit": "µg"
				},
				"thiamin": {
					"value": .09,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.25,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .052,
					"unit": "mg"
				},
				"folate": {
					"value": 16,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/790214/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 790214,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2512375",
		"name": "Flour, rye",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 351,
			"proteinG": 8.4,
			"carbohydrateG": 77.2,
			"fatG": 1.91,
			"fiberG": 13.7,
			"micronutrients": {
				"calcium": {
					"value": 32.2,
					"unit": "mg"
				},
				"iron": {
					"value": 2.54,
					"unit": "mg"
				},
				"magnesium": {
					"value": 95.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 280,
					"unit": "mg"
				},
				"potassium": {
					"value": 434,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.33,
					"unit": "mg"
				},
				"copper": {
					"value": .338,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.13,
					"unit": "mg"
				},
				"selenium": {
					"value": 16.6,
					"unit": "µg"
				},
				"thiamin": {
					"value": .216,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .17,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.16,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .164,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512375/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512375,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2003588",
		"name": "Flour, semolina, coarse and semi-coarse",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 365,
			"proteinG": 11.7,
			"carbohydrateG": 73.8,
			"fatG": 1.6,
			"fiberG": 3.22,
			"micronutrients": {
				"calcium": {
					"value": 17.2,
					"unit": "mg"
				},
				"iron": {
					"value": 1.55,
					"unit": "mg"
				},
				"magnesium": {
					"value": 35.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 130,
					"unit": "mg"
				},
				"potassium": {
					"value": 174,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .947,
					"unit": "mg"
				},
				"copper": {
					"value": .227,
					"unit": "mg"
				},
				"manganese": {
					"value": .647,
					"unit": "mg"
				},
				"selenium": {
					"value": 29.8,
					"unit": "µg"
				},
				"thiamin": {
					"value": .405,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .247,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.63,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .083,
					"unit": "mg"
				},
				"folate": {
					"value": 168,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003588/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003588,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2003589",
		"name": "Flour, semolina, fine",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 366,
			"proteinG": 13.3,
			"carbohydrateG": 72,
			"fatG": 1.84,
			"fiberG": 3.68,
			"micronutrients": {
				"calcium": {
					"value": 19.8,
					"unit": "mg"
				},
				"iron": {
					"value": 2.43,
					"unit": "mg"
				},
				"magnesium": {
					"value": 46.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 163,
					"unit": "mg"
				},
				"potassium": {
					"value": 208,
					"unit": "mg"
				},
				"sodium": {
					"value": .426,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.24,
					"unit": "mg"
				},
				"copper": {
					"value": .286,
					"unit": "mg"
				},
				"manganese": {
					"value": .842,
					"unit": "mg"
				},
				"selenium": {
					"value": 44.1,
					"unit": "µg"
				},
				"thiamin": {
					"value": .695,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .34,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.6,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .108,
					"unit": "mg"
				},
				"folate": {
					"value": 164,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003589/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003589,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2512373",
		"name": "Flour, sorghum",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 364,
			"proteinG": 8.27,
			"carbohydrateG": 77.4,
			"fatG": 3.59,
			"fiberG": 6.02,
			"micronutrients": {
				"calcium": {
					"value": 11.4,
					"unit": "mg"
				},
				"iron": {
					"value": 3.72,
					"unit": "mg"
				},
				"magnesium": {
					"value": 116,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 262,
					"unit": "mg"
				},
				"potassium": {
					"value": 335,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.66,
					"unit": "mg"
				},
				"copper": {
					"value": .237,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.08,
					"unit": "mg"
				},
				"selenium": {
					"value": 12.4,
					"unit": "µg"
				},
				"thiamin": {
					"value": .27,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .15,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.95,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .166,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512373/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512373,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-1104705",
		"name": "Flour, soy, defatted",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 366,
			"proteinG": 51.1,
			"carbohydrateG": 32.9,
			"fatG": 3.33,
			"fiberG": 24.3,
			"micronutrients": {
				"calcium": {
					"value": 338,
					"unit": "mg"
				},
				"iron": {
					"value": 7.34,
					"unit": "mg"
				},
				"magnesium": {
					"value": 313,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 726,
					"unit": "mg"
				},
				"potassium": {
					"value": 2480,
					"unit": "mg"
				},
				"sodium": {
					"value": 2,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.44,
					"unit": "mg"
				},
				"copper": {
					"value": 1.51,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.81,
					"unit": "mg"
				},
				"selenium": {
					"value": 45.8,
					"unit": "µg"
				},
				"thiamin": {
					"value": .542,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .298,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.43,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .618,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1104705/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1104705,
			"release": "10/30/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-1104766",
		"name": "Flour, soy, full-fat",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 452,
			"proteinG": 38.6,
			"carbohydrateG": 27.9,
			"fatG": 20.7,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 258,
					"unit": "mg"
				},
				"iron": {
					"value": 9.51,
					"unit": "mg"
				},
				"magnesium": {
					"value": 254,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 607,
					"unit": "mg"
				},
				"potassium": {
					"value": 1860,
					"unit": "mg"
				},
				"sodium": {
					"value": 2,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.75,
					"unit": "mg"
				},
				"copper": {
					"value": 1.09,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.16,
					"unit": "mg"
				},
				"selenium": {
					"value": 14.3,
					"unit": "µg"
				},
				"thiamin": {
					"value": .362,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .363,
					"unit": "mg"
				},
				"niacin": {
					"value": 2.74,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .34,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1104766/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1104766,
			"release": "10/30/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2003587",
		"name": "Flour, spelt, whole grain",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 341,
			"proteinG": 14.5,
			"carbohydrateG": 70.7,
			"fatG": 2.54,
			"fiberG": 9.34,
			"micronutrients": {
				"calcium": {
					"value": 30,
					"unit": "mg"
				},
				"iron": {
					"value": 3.77,
					"unit": "mg"
				},
				"magnesium": {
					"value": 124,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 362,
					"unit": "mg"
				},
				"potassium": {
					"value": 350,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.59,
					"unit": "mg"
				},
				"copper": {
					"value": .531,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.94,
					"unit": "mg"
				},
				"selenium": {
					"value": 9.48,
					"unit": "µg"
				},
				"thiamin": {
					"value": .298,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .143,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.47,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .236,
					"unit": "mg"
				},
				"folate": {
					"value": 38.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003587/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003587,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-789890",
		"name": "Flour, wheat, all-purpose, enriched, bleached",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 366,
			"proteinG": 10.9,
			"carbohydrateG": 77.3,
			"fatG": 1.48,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 19,
					"unit": "mg"
				},
				"iron": {
					"value": 5.62,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 108,
					"unit": "mg"
				},
				"potassium": {
					"value": 136,
					"unit": "mg"
				},
				"sodium": {
					"value": 2,
					"unit": "mg"
				},
				"zinc": {
					"value": .72,
					"unit": "mg"
				},
				"copper": {
					"value": .155,
					"unit": "mg"
				},
				"manganese": {
					"value": .758,
					"unit": "mg"
				},
				"selenium": {
					"value": 15.7,
					"unit": "µg"
				},
				"thiamin": {
					"value": .939,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .443,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.74,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .066,
					"unit": "mg"
				},
				"folate": {
					"value": 160,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/789890/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 789890,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-789951",
		"name": "Flour, wheat, all-purpose, enriched, unbleached",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 358,
			"proteinG": 13.1,
			"carbohydrateG": 73.2,
			"fatG": 1.48,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 21,
					"unit": "mg"
				},
				"iron": {
					"value": 5.41,
					"unit": "mg"
				},
				"magnesium": {
					"value": 33.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 115,
					"unit": "mg"
				},
				"potassium": {
					"value": 135,
					"unit": "mg"
				},
				"sodium": {
					"value": 4,
					"unit": "mg"
				},
				"zinc": {
					"value": .9,
					"unit": "mg"
				},
				"copper": {
					"value": .172,
					"unit": "mg"
				},
				"manganese": {
					"value": .875,
					"unit": "mg"
				},
				"selenium": {
					"value": 14.2,
					"unit": "µg"
				},
				"thiamin": {
					"value": 1.05,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .467,
					"unit": "mg"
				},
				"niacin": {
					"value": 7.07,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .079,
					"unit": "mg"
				},
				"folate": {
					"value": 159,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/789951/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 789951,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-790018",
		"name": "Flour, wheat, all-purpose, unenriched, unbleached",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 362,
			"proteinG": 12,
			"carbohydrateG": 74.6,
			"fatG": 1.7,
			"fiberG": 3,
			"micronutrients": {
				"calcium": {
					"value": 22,
					"unit": "mg"
				},
				"iron": {
					"value": 1.18,
					"unit": "mg"
				},
				"magnesium": {
					"value": 36.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 134,
					"unit": "mg"
				},
				"potassium": {
					"value": 150,
					"unit": "mg"
				},
				"sodium": {
					"value": 2,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.15,
					"unit": "mg"
				},
				"copper": {
					"value": .212,
					"unit": "mg"
				},
				"manganese": {
					"value": .819,
					"unit": "mg"
				},
				"selenium": {
					"value": 20.1,
					"unit": "µg"
				},
				"thiamin": {
					"value": .298,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.59,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .085,
					"unit": "mg"
				},
				"folate": {
					"value": 23,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/790018/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 790018,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-790085",
		"name": "Flour, whole wheat, unenriched",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 370,
			"proteinG": 15.1,
			"carbohydrateG": 71.2,
			"fatG": 2.73,
			"fiberG": 10.6,
			"micronutrients": {
				"calcium": {
					"value": 38,
					"unit": "mg"
				},
				"iron": {
					"value": 3.86,
					"unit": "mg"
				},
				"magnesium": {
					"value": 136,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 352,
					"unit": "mg"
				},
				"potassium": {
					"value": 376,
					"unit": "mg"
				},
				"sodium": {
					"value": 3,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.24,
					"unit": "mg"
				},
				"copper": {
					"value": .452,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.56,
					"unit": "mg"
				},
				"selenium": {
					"value": 23.6,
					"unit": "µg"
				},
				"thiamin": {
					"value": .504,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .128,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.55,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .268,
					"unit": "mg"
				},
				"folate": {
					"value": 39,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/790085/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 790085,
			"release": "4/1/2020"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2710829",
		"name": "Fonio, grain, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 377,
			"proteinG": 7.17,
			"carbohydrateG": 81.3,
			"fatG": 1.69,
			"fiberG": 2.2,
			"micronutrients": {
				"calcium": {
					"value": 11.6,
					"unit": "mg"
				},
				"iron": {
					"value": 2.66,
					"unit": "mg"
				},
				"magnesium": {
					"value": 39.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 93.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 43.8,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.97,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.85,
					"unit": "mg"
				},
				"copper": {
					"value": .36,
					"unit": "mg"
				},
				"manganese": {
					"value": .418,
					"unit": "mg"
				},
				"thiamin": {
					"value": .086,
					"unit": "mg"
				},
				"niacin": {
					"value": .716,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .025,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710829/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710829,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-323121",
		"name": "Frankfurter, beef, unheated",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 314,
			"proteinG": 11.7,
			"carbohydrateG": 2.89,
			"fatG": 28,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 15,
					"unit": "mg"
				},
				"iron": {
					"value": 1.14,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 128,
					"unit": "mg"
				},
				"potassium": {
					"value": 343,
					"unit": "mg"
				},
				"sodium": {
					"value": 872,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.06,
					"unit": "mg"
				},
				"copper": {
					"value": .046,
					"unit": "mg"
				},
				"manganese": {
					"value": .031,
					"unit": "mg"
				},
				"vitaminA": {
					"value": 3,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .51,
					"unit": "mg"
				},
				"thiamin": {
					"value": .033,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .154,
					"unit": "mg"
				},
				"niacin": {
					"value": 2.25,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .13,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .97,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/323121/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 323121,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 piece",
			"weightGrams": 48.6
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-1104647",
		"name": "Garlic, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 143,
			"proteinG": 6.62,
			"carbohydrateG": 28.2,
			"fatG": .38,
			"fiberG": 2.7,
			"micronutrients": {
				"selenium": {
					"value": 9.8,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 10,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1104647/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1104647,
			"release": "10/30/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003592",
		"name": "Grape juice, purple, with added vitamin C, from concentrate, shelf stable",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 64.5,
			"proteinG": .258,
			"carbohydrateG": 15.6,
			"fatG": .288,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 9.74,
					"unit": "mg"
				},
				"iron": {
					"value": .041,
					"unit": "mg"
				},
				"magnesium": {
					"value": 7.87,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 12,
					"unit": "mg"
				},
				"potassium": {
					"value": 49.8,
					"unit": "mg"
				},
				"sodium": {
					"value": 4.02,
					"unit": "mg"
				},
				"zinc": {
					"value": .057,
					"unit": "mg"
				},
				"copper": {
					"value": .015,
					"unit": "mg"
				},
				"manganese": {
					"value": .166,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 45.6,
					"unit": "mg"
				},
				"thiamin": {
					"value": .026,
					"unit": "mg"
				},
				"niacin": {
					"value": .016,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .039,
					"unit": "mg"
				},
				"folate": {
					"value": .664,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003592/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003592,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2003593",
		"name": "Grape juice, white, with added vitamin C, from concentrate, shelf stable",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 64.6,
			"proteinG": .094,
			"carbohydrateG": 15.8,
			"fatG": .265,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 7.32,
					"unit": "mg"
				},
				"iron": {
					"value": .119,
					"unit": "mg"
				},
				"magnesium": {
					"value": 4.27,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 12.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 49,
					"unit": "mg"
				},
				"sodium": {
					"value": 7.19,
					"unit": "mg"
				},
				"zinc": {
					"value": .018,
					"unit": "mg"
				},
				"copper": {
					"value": .004,
					"unit": "mg"
				},
				"manganese": {
					"value": .061,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 55.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": .006,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .014,
					"unit": "mg"
				},
				"folate": {
					"value": 1.73,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003593/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003593,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2003595",
		"name": "Grapefruit juice, red, not fortified, not from concentrate, refrigerated",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 39.8,
			"proteinG": .57,
			"carbohydrateG": 9.1,
			"fatG": .267,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 8.88,
					"unit": "mg"
				},
				"iron": {
					"value": .015,
					"unit": "mg"
				},
				"magnesium": {
					"value": 7.75,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 14.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 128,
					"unit": "mg"
				},
				"sodium": {
					"value": 1.03,
					"unit": "mg"
				},
				"zinc": {
					"value": .027,
					"unit": "mg"
				},
				"copper": {
					"value": .024,
					"unit": "mg"
				},
				"manganese": {
					"value": .015,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 24.1,
					"unit": "mg"
				},
				"thiamin": {
					"value": .033,
					"unit": "mg"
				},
				"niacin": {
					"value": .019,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .022,
					"unit": "mg"
				},
				"folate": {
					"value": 19,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003595/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003595,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-325287",
		"name": "Grapefruit juice, white, canned or bottled, unsweetened",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 37,
			"proteinG": .55,
			"carbohydrateG": 7.59,
			"fatG": .7,
			"fiberG": .2,
			"micronutrients": {
				"calcium": {
					"value": 16,
					"unit": "mg"
				},
				"iron": {
					"value": .07,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 17,
					"unit": "mg"
				},
				"potassium": {
					"value": 141,
					"unit": "mg"
				},
				"sodium": {
					"value": 1,
					"unit": "mg"
				},
				"zinc": {
					"value": .04,
					"unit": "mg"
				},
				"copper": {
					"value": .032,
					"unit": "mg"
				},
				"manganese": {
					"value": .02,
					"unit": "mg"
				},
				"vitaminE": {
					"value": .22,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 39.4,
					"unit": "mg"
				},
				"thiamin": {
					"value": .062,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .02,
					"unit": "mg"
				},
				"niacin": {
					"value": .253,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": 0,
					"unit": "mg"
				},
				"folate": {
					"value": 12,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/325287/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 325287,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 257
		}]
	},
	{
		"id": "usda-fdc-2346413",
		"name": "Grapes, green, seedless, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 71.9,
			"proteinG": .899,
			"carbohydrateG": 18.6,
			"fatG": .232,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 9.9,
					"unit": "mg"
				},
				"iron": {
					"value": .199,
					"unit": "mg"
				},
				"magnesium": {
					"value": 7.12,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 22,
					"unit": "mg"
				},
				"potassium": {
					"value": 218,
					"unit": "mg"
				},
				"sodium": {
					"value": 3.17,
					"unit": "mg"
				},
				"zinc": {
					"value": .027,
					"unit": "mg"
				},
				"copper": {
					"value": .061,
					"unit": "mg"
				},
				"manganese": {
					"value": .084,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 3.02,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346413/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346413,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2346412",
		"name": "Grapes, red, seedless, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 77.2,
			"proteinG": .914,
			"carbohydrateG": 20.2,
			"fatG": .164,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 10.2,
					"unit": "mg"
				},
				"iron": {
					"value": .162,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.56,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 24.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 229,
					"unit": "mg"
				},
				"sodium": {
					"value": 7,
					"unit": "mg"
				},
				"zinc": {
					"value": .036,
					"unit": "mg"
				},
				"copper": {
					"value": .081,
					"unit": "mg"
				},
				"manganese": {
					"value": .098,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 3.31,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346412/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346412,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2727585",
		"name": "Green onion, (scallion), bulb and greens, root removed, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": .669,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 2.3,
			"micronutrients": {
				"calcium": {
					"value": 59.4,
					"unit": "mg"
				},
				"iron": {
					"value": 1.04,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 27.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 232,
					"unit": "mg"
				},
				"sodium": {
					"value": 9.95,
					"unit": "mg"
				},
				"zinc": {
					"value": .248,
					"unit": "mg"
				},
				"copper": {
					"value": .035,
					"unit": "mg"
				},
				"manganese": {
					"value": .271,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727585/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727585,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2747656",
		"name": "Halibut, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 81.3,
			"proteinG": 19.1,
			"carbohydrateG": -.06,
			"fatG": .592,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.1,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 23.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 217,
					"unit": "mg"
				},
				"potassium": {
					"value": 430,
					"unit": "mg"
				},
				"sodium": {
					"value": 108,
					"unit": "mg"
				},
				"zinc": {
					"value": .327,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 53.7,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .582,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747656/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747656,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-332397",
		"name": "Ham, sliced, pre-packaged, deli meat (96%fat free, water added)",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 106,
			"proteinG": 16.7,
			"carbohydrateG": .27,
			"fatG": 3.73,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 5,
					"unit": "mg"
				},
				"iron": {
					"value": .58,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 261,
					"unit": "mg"
				},
				"potassium": {
					"value": 425,
					"unit": "mg"
				},
				"sodium": {
					"value": 1040,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.52,
					"unit": "mg"
				},
				"copper": {
					"value": .05,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/332397/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 332397,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 slice",
			"weightGrams": 13.5
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-746952",
		"name": "Ham, sliced, restaurant",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 121,
			"proteinG": 19.6,
			"carbohydrateG": 2.36,
			"fatG": 3.68,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6,
					"unit": "mg"
				},
				"iron": {
					"value": .86,
					"unit": "mg"
				},
				"magnesium": {
					"value": 20.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 246,
					"unit": "mg"
				},
				"potassium": {
					"value": 484,
					"unit": "mg"
				},
				"sodium": {
					"value": 1030,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.76,
					"unit": "mg"
				},
				"copper": {
					"value": .041,
					"unit": "mg"
				},
				"manganese": {
					"value": .015,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746952/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746952,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 slice",
			"weightGrams": 16.2
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-321358",
		"name": "Hummus, commercial",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 229,
			"proteinG": 7.35,
			"carbohydrateG": 14.9,
			"fatG": 17.1,
			"fiberG": 5.4,
			"micronutrients": {
				"calcium": {
					"value": 41,
					"unit": "mg"
				},
				"iron": {
					"value": 2.41,
					"unit": "mg"
				},
				"magnesium": {
					"value": 71.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 166,
					"unit": "mg"
				},
				"potassium": {
					"value": 289,
					"unit": "mg"
				},
				"sodium": {
					"value": 438,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.38,
					"unit": "mg"
				},
				"copper": {
					"value": .348,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.06,
					"unit": "mg"
				},
				"selenium": {
					"value": 16.2,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 1,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 1.74,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .15,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .115,
					"unit": "mg"
				},
				"niacin": {
					"value": .948,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .143,
					"unit": "mg"
				},
				"folate": {
					"value": 36,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 17.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/321358/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 321358,
			"release": "4/1/2019"
		},
		"preparationState": "prepared",
		"servingOptions": [{
			"quantity": 2,
			"unit": "serving",
			"description": "2 tbsp",
			"weightGrams": 33.9
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2727588",
		"name": "Juice, pomegranate, from concentrate, shelf-stable",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 0,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 11,
					"unit": "mg"
				},
				"iron": {
					"value": .031,
					"unit": "mg"
				},
				"magnesium": {
					"value": 6.86,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 8.94,
					"unit": "mg"
				},
				"potassium": {
					"value": 166,
					"unit": "mg"
				},
				"sodium": {
					"value": 4.04,
					"unit": "mg"
				},
				"zinc": {
					"value": .082,
					"unit": "mg"
				},
				"copper": {
					"value": .01,
					"unit": "mg"
				},
				"manganese": {
					"value": .052,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"folate": {
					"value": 5.87,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727588/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727588,
			"release": "4/24/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2727587",
		"name": "Juice, prune, shelf-stable",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": .423,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 16.2,
					"unit": "mg"
				},
				"iron": {
					"value": .444,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 19,
					"unit": "mg"
				},
				"potassium": {
					"value": 216,
					"unit": "mg"
				},
				"sodium": {
					"value": 10.3,
					"unit": "mg"
				},
				"zinc": {
					"value": .122,
					"unit": "mg"
				},
				"copper": {
					"value": .022,
					"unit": "mg"
				},
				"manganese": {
					"value": .125,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .081,
					"unit": "mg"
				},
				"folate": {
					"value": 5.29,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727587/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727587,
			"release": "4/24/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2727589",
		"name": "Juice, tart cherry, from concentrate, shelf-stable",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": .147,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 16.2,
					"unit": "mg"
				},
				"iron": {
					"value": .203,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 16.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 170,
					"unit": "mg"
				},
				"sodium": {
					"value": 1.36,
					"unit": "mg"
				},
				"zinc": {
					"value": .033,
					"unit": "mg"
				},
				"copper": {
					"value": .014,
					"unit": "mg"
				},
				"manganese": {
					"value": .089,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"folate": {
					"value": 4.67,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727589/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727589,
			"release": "4/24/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-326196",
		"name": "Kale, frozen, cooked, boiled, drained, without salt",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 36,
			"proteinG": 2.94,
			"carbohydrateG": 5.3,
			"fatG": 1.21,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 150,
					"unit": "mg"
				},
				"iron": {
					"value": .84,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 42,
					"unit": "mg"
				},
				"potassium": {
					"value": 144,
					"unit": "mg"
				},
				"sodium": {
					"value": 16,
					"unit": "mg"
				},
				"zinc": {
					"value": .27,
					"unit": "mg"
				},
				"copper": {
					"value": .067,
					"unit": "mg"
				},
				"manganese": {
					"value": .542,
					"unit": "mg"
				},
				"vitaminA": {
					"value": 146,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 1.61,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 17.8,
					"unit": "mg"
				},
				"thiamin": {
					"value": .063,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .14,
					"unit": "mg"
				},
				"niacin": {
					"value": .457,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .063,
					"unit": "mg"
				},
				"folate": {
					"value": 65,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 418,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/326196/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 326196,
			"release": "4/1/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cooked cup",
			"weightGrams": 118
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-323505",
		"name": "Kale, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 35,
			"proteinG": 2.92,
			"carbohydrateG": 4.42,
			"fatG": 1.49,
			"fiberG": 4.1,
			"micronutrients": {
				"calcium": {
					"value": 254,
					"unit": "mg"
				},
				"iron": {
					"value": 1.6,
					"unit": "mg"
				},
				"magnesium": {
					"value": 32.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 55,
					"unit": "mg"
				},
				"potassium": {
					"value": 348,
					"unit": "mg"
				},
				"sodium": {
					"value": 53,
					"unit": "mg"
				},
				"zinc": {
					"value": .39,
					"unit": "mg"
				},
				"copper": {
					"value": .053,
					"unit": "mg"
				},
				"manganese": {
					"value": .92,
					"unit": "mg"
				},
				"vitaminA": {
					"value": 241,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .66,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 93.4,
					"unit": "mg"
				},
				"thiamin": {
					"value": .113,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .347,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.18,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .147,
					"unit": "mg"
				},
				"folate": {
					"value": 62,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 390,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/323505/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 323505,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 pieces of ~1\" cup",
			"weightGrams": 20.6
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-747693",
		"name": "Ketchup, restaurant",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 117,
			"proteinG": 1.11,
			"carbohydrateG": 26.8,
			"fatG": .55,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 14,
					"unit": "mg"
				},
				"iron": {
					"value": .43,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 25,
					"unit": "mg"
				},
				"potassium": {
					"value": 249,
					"unit": "mg"
				},
				"sodium": {
					"value": 949,
					"unit": "mg"
				},
				"zinc": {
					"value": .16,
					"unit": "mg"
				},
				"copper": {
					"value": .066,
					"unit": "mg"
				},
				"manganese": {
					"value": .086,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/747693/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 747693,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2710830",
		"name": "Khorasan, grain, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 348,
			"proteinG": 14.8,
			"carbohydrateG": 71.8,
			"fatG": 2.8,
			"fiberG": 10.5,
			"micronutrients": {
				"calcium": {
					"value": 24.1,
					"unit": "mg"
				},
				"iron": {
					"value": 3.87,
					"unit": "mg"
				},
				"magnesium": {
					"value": 130,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 371,
					"unit": "mg"
				},
				"potassium": {
					"value": 450,
					"unit": "mg"
				},
				"sodium": {
					"value": 3.94,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.46,
					"unit": "mg"
				},
				"copper": {
					"value": .594,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.26,
					"unit": "mg"
				},
				"thiamin": {
					"value": .478,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.66,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .258,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710830/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710830,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2710831",
		"name": "Kiwifruit (kiwi), green, peeled, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 58.5,
			"proteinG": 1.01,
			"carbohydrateG": 13.8,
			"fatG": .64,
			"fiberG": 2.13,
			"micronutrients": {
				"calcium": {
					"value": 24.4,
					"unit": "mg"
				},
				"iron": {
					"value": .037,
					"unit": "mg"
				},
				"magnesium": {
					"value": 14.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 27.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 302,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.28,
					"unit": "mg"
				},
				"zinc": {
					"value": .455,
					"unit": "mg"
				},
				"copper": {
					"value": .128,
					"unit": "mg"
				},
				"manganese": {
					"value": .068,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 58.8,
					"unit": "mg"
				},
				"folate": {
					"value": 32.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710831/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710831,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-327046",
		"name": "Kiwifruit, green, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 58,
			"proteinG": 1.06,
			"carbohydrateG": 14,
			"fatG": .44,
			"fiberG": 3,
			"micronutrients": {
				"calcium": {
					"value": 35,
					"unit": "mg"
				},
				"iron": {
					"value": .24,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 34,
					"unit": "mg"
				},
				"potassium": {
					"value": 198,
					"unit": "mg"
				},
				"sodium": {
					"value": 5,
					"unit": "mg"
				},
				"zinc": {
					"value": .14,
					"unit": "mg"
				},
				"copper": {
					"value": .134,
					"unit": "mg"
				},
				"manganese": {
					"value": .064,
					"unit": "mg"
				},
				"selenium": {
					"value": .2,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 4,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 1.3,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 74.7,
					"unit": "mg"
				},
				"thiamin": {
					"value": .027,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .025,
					"unit": "mg"
				},
				"niacin": {
					"value": .37,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .061,
					"unit": "mg"
				},
				"folate": {
					"value": 26,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 40.3,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/327046/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 327046,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2727570",
		"name": "Lamb, ground, raw",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 242,
			"proteinG": 17.5,
			"carbohydrateG": -.251,
			"fatG": 18.6,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6.58,
					"unit": "mg"
				},
				"iron": {
					"value": 1.64,
					"unit": "mg"
				},
				"magnesium": {
					"value": 17.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 156,
					"unit": "mg"
				},
				"potassium": {
					"value": 272,
					"unit": "mg"
				},
				"sodium": {
					"value": 53.4,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.13,
					"unit": "mg"
				},
				"copper": {
					"value": .085,
					"unit": "mg"
				},
				"manganese": {
					"value": .004,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727570/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727570,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2727584",
		"name": "Leeks, bulb and greens, root removed, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 1.47,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 3,
			"micronutrients": {
				"calcium": {
					"value": 51.4,
					"unit": "mg"
				},
				"iron": {
					"value": .761,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 34.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 319,
					"unit": "mg"
				},
				"sodium": {
					"value": 17.7,
					"unit": "mg"
				},
				"zinc": {
					"value": .293,
					"unit": "mg"
				},
				"copper": {
					"value": .057,
					"unit": "mg"
				},
				"manganese": {
					"value": .124,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .208,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727584/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727584,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2644283",
		"name": "Lentils, dry",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 351,
			"proteinG": 23.6,
			"carbohydrateG": 62.2,
			"fatG": 1.92,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 61.8,
					"unit": "mg"
				},
				"iron": {
					"value": 7.16,
					"unit": "mg"
				},
				"magnesium": {
					"value": 107,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 374,
					"unit": "mg"
				},
				"potassium": {
					"value": 949,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.86,
					"unit": "mg"
				},
				"copper": {
					"value": .838,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.57,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644283/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644283,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 35
		}]
	},
	{
		"id": "usda-fdc-746769",
		"name": "Lettuce, cos or romaine, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 17,
			"proteinG": 1.24,
			"carbohydrateG": 3.24,
			"fatG": .26,
			"fiberG": 1.8,
			"micronutrients": {
				"calcium": {
					"value": 35,
					"unit": "mg"
				},
				"iron": {
					"value": .95,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 30,
					"unit": "mg"
				},
				"potassium": {
					"value": 253,
					"unit": "mg"
				},
				"zinc": {
					"value": .25,
					"unit": "mg"
				},
				"copper": {
					"value": .048,
					"unit": "mg"
				},
				"manganese": {
					"value": .127,
					"unit": "mg"
				},
				"selenium": {
					"value": .4,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 436,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .14,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 4.6,
					"unit": "mg"
				},
				"thiamin": {
					"value": .079,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .072,
					"unit": "mg"
				},
				"niacin": {
					"value": .323,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .078,
					"unit": "mg"
				},
				"folate": {
					"value": 50,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 102,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746769/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746769,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 bunch",
			"weightGrams": 581
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2346388",
		"name": "Lettuce, iceberg, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 14.5,
			"proteinG": .742,
			"carbohydrateG": 3.37,
			"fatG": .074,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 14.2,
					"unit": "mg"
				},
				"iron": {
					"value": .033,
					"unit": "mg"
				},
				"magnesium": {
					"value": 6.31,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 19.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 139,
					"unit": "mg"
				},
				"sodium": {
					"value": 16.1,
					"unit": "mg"
				},
				"zinc": {
					"value": .173,
					"unit": "mg"
				},
				"copper": {
					"value": .033,
					"unit": "mg"
				},
				"manganese": {
					"value": .082,
					"unit": "mg"
				},
				"thiamin": {
					"value": .056,
					"unit": "mg"
				},
				"niacin": {
					"value": .218,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .04,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 20.5,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346388/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346388,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2346391",
		"name": "Lettuce, leaf, green, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 18.5,
			"proteinG": 1.09,
			"carbohydrateG": 4.07,
			"fatG": .156,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 39.8,
					"unit": "mg"
				},
				"iron": {
					"value": .32,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 26.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 277,
					"unit": "mg"
				},
				"sodium": {
					"value": 28.9,
					"unit": "mg"
				},
				"zinc": {
					"value": .31,
					"unit": "mg"
				},
				"copper": {
					"value": .04,
					"unit": "mg"
				},
				"manganese": {
					"value": .156,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 15.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": .082,
					"unit": "mg"
				},
				"niacin": {
					"value": .375,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .071,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 118,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346391/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346391,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2346390",
		"name": "Lettuce, leaf, red, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 14.7,
			"proteinG": .883,
			"carbohydrateG": 3.26,
			"fatG": .106,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 42.6,
					"unit": "mg"
				},
				"iron": {
					"value": .402,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 24.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 321,
					"unit": "mg"
				},
				"sodium": {
					"value": 24.9,
					"unit": "mg"
				},
				"zinc": {
					"value": .303,
					"unit": "mg"
				},
				"copper": {
					"value": .038,
					"unit": "mg"
				},
				"manganese": {
					"value": .177,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 9.34,
					"unit": "mg"
				},
				"thiamin": {
					"value": .061,
					"unit": "mg"
				},
				"niacin": {
					"value": .329,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .074,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 73.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346390/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346390,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2346389",
		"name": "Lettuce, romaine, green, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 17.5,
			"proteinG": .977,
			"carbohydrateG": 4.06,
			"fatG": .071,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 27.6,
					"unit": "mg"
				},
				"iron": {
					"value": .267,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 23.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 260,
					"unit": "mg"
				},
				"sodium": {
					"value": 23,
					"unit": "mg"
				},
				"zinc": {
					"value": .252,
					"unit": "mg"
				},
				"copper": {
					"value": .049,
					"unit": "mg"
				},
				"manganese": {
					"value": .227,
					"unit": "mg"
				},
				"thiamin": {
					"value": .063,
					"unit": "mg"
				},
				"niacin": {
					"value": .371,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .063,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 83.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346389/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346389,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2747657",
		"name": "Lobster, tail only, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 58.8,
			"proteinG": 13,
			"carbohydrateG": .886,
			"fatG": .367,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 71.6,
					"unit": "mg"
				},
				"iron": {
					"value": .173,
					"unit": "mg"
				},
				"magnesium": {
					"value": 39,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 175,
					"unit": "mg"
				},
				"potassium": {
					"value": 213,
					"unit": "mg"
				},
				"sodium": {
					"value": 509,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.54,
					"unit": "mg"
				},
				"copper": {
					"value": .243,
					"unit": "mg"
				},
				"manganese": {
					"value": .064,
					"unit": "mg"
				},
				"selenium": {
					"value": 63.1,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .995,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747657/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747657,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2747658",
		"name": "Mahi mahi, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 83.7,
			"proteinG": 19.8,
			"carbohydrateG": .287,
			"fatG": .377,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6,
					"unit": "mg"
				},
				"iron": {
					"value": .052,
					"unit": "mg"
				},
				"magnesium": {
					"value": 28,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 224,
					"unit": "mg"
				},
				"potassium": {
					"value": 408,
					"unit": "mg"
				},
				"sodium": {
					"value": 51.9,
					"unit": "mg"
				},
				"zinc": {
					"value": .296,
					"unit": "mg"
				},
				"copper": {
					"value": .029,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 50.2,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.34,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747658/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747658,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2710832",
		"name": "Mandarin, seedless, peeled, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 55.6,
			"proteinG": 1.04,
			"carbohydrateG": 13.4,
			"fatG": .458,
			"fiberG": 1.33,
			"micronutrients": {
				"calcium": {
					"value": 44,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 19.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 167,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .069,
					"unit": "mg"
				},
				"copper": {
					"value": .043,
					"unit": "mg"
				},
				"manganese": {
					"value": .05,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 21.2,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710832/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710832,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710834",
		"name": "Mango, Ataulfo, peeled, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 70.6,
			"proteinG": .688,
			"carbohydrateG": 17.4,
			"fatG": .681,
			"fiberG": 1.29,
			"micronutrients": {
				"calcium": {
					"value": 10,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 17.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 204,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .102,
					"unit": "mg"
				},
				"copper": {
					"value": .103,
					"unit": "mg"
				},
				"manganese": {
					"value": .104,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 168,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .108,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710834/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710834,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710833",
		"name": "Mango, Tommy Atkins, peeled, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 61.6,
			"proteinG": .562,
			"carbohydrateG": 15.3,
			"fatG": .572,
			"fiberG": 1.75,
			"micronutrients": {
				"calcium": {
					"value": 12.4,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 16.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 165,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .066,
					"unit": "mg"
				},
				"copper": {
					"value": .091,
					"unit": "mg"
				},
				"manganese": {
					"value": .106,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 25.5,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .071,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710833/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710833,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-746770",
		"name": "Melons, cantaloupe, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 34,
			"proteinG": .82,
			"carbohydrateG": 8.16,
			"fatG": .18,
			"fiberG": .8,
			"micronutrients": {
				"calcium": {
					"value": 9,
					"unit": "mg"
				},
				"iron": {
					"value": .38,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 17,
					"unit": "mg"
				},
				"potassium": {
					"value": 157,
					"unit": "mg"
				},
				"sodium": {
					"value": 30,
					"unit": "mg"
				},
				"zinc": {
					"value": .44,
					"unit": "mg"
				},
				"copper": {
					"value": .085,
					"unit": "mg"
				},
				"manganese": {
					"value": .046,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.7,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 232,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 10.9,
					"unit": "mg"
				},
				"thiamin": {
					"value": .049,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .027,
					"unit": "mg"
				},
				"niacin": {
					"value": .694,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .04,
					"unit": "mg"
				},
				"folate": {
					"value": 14,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 2.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746770/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746770,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 medium (1/8 of medium melon) wedge",
				"weightGrams": 69
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 large (1/8 of large melon) wedge",
				"weightGrams": 102
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 small (about 4-1/4\" dia) each",
				"weightGrams": 441
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 large (about 6-1/2\" dia) each",
				"weightGrams": 814
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 cubes cup",
				"weightGrams": 160
			},
			{
				"quantity": 10,
				"unit": "serving",
				"description": "10 balls pieces",
				"weightGrams": 138
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 diced cup",
				"weightGrams": 156
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 medium (about 5\" dia) each",
				"weightGrams": 552
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 small (1/8 of small melon) wedge",
				"weightGrams": 55
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 140
			}
		]
	},
	{
		"id": "usda-fdc-2710816",
		"name": "Melons, honeydew, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 32.9,
			"proteinG": .531,
			"carbohydrateG": 8.15,
			"fatG": .216,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6.58,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 11.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 209,
					"unit": "mg"
				},
				"sodium": {
					"value": 21.2,
					"unit": "mg"
				},
				"zinc": {
					"value": .06,
					"unit": "mg"
				},
				"copper": {
					"value": .009,
					"unit": "mg"
				},
				"manganese": {
					"value": .035,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 15.7,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710816/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710816,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-746772",
		"name": "Milk, lowfat, fluid, 1% milkfat, with added vitamin A and vitamin D",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 43,
			"proteinG": 3.38,
			"carbohydrateG": 5.18,
			"fatG": .95,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 126,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 103,
					"unit": "mg"
				},
				"potassium": {
					"value": 159,
					"unit": "mg"
				},
				"sodium": {
					"value": 39,
					"unit": "mg"
				},
				"zinc": {
					"value": .43,
					"unit": "mg"
				},
				"copper": {
					"value": .001,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 2.1,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 58,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .02,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 1.06,
					"unit": "µg"
				},
				"thiamin": {
					"value": .057,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .14,
					"unit": "mg"
				},
				"niacin": {
					"value": .113,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .06,
					"unit": "mg"
				},
				"folate": {
					"value": 2,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .61,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746772/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746772,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 246
		}]
	},
	{
		"id": "usda-fdc-746776",
		"name": "Milk, nonfat, fluid, with added vitamin A and vitamin D (fat free or skim)",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 34,
			"proteinG": 3.43,
			"carbohydrateG": 4.92,
			"fatG": .08,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 132,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 107,
					"unit": "mg"
				},
				"potassium": {
					"value": 167,
					"unit": "mg"
				},
				"sodium": {
					"value": 41,
					"unit": "mg"
				},
				"zinc": {
					"value": .45,
					"unit": "mg"
				},
				"copper": {
					"value": .002,
					"unit": "mg"
				},
				"manganese": {
					"value": .001,
					"unit": "mg"
				},
				"selenium": {
					"value": 2,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 64,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 1.1,
					"unit": "µg"
				},
				"thiamin": {
					"value": .056,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .131,
					"unit": "mg"
				},
				"niacin": {
					"value": .118,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .058,
					"unit": "mg"
				},
				"folate": {
					"value": 2,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .58,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746776/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746776,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 246
		}]
	},
	{
		"id": "usda-fdc-746778",
		"name": "Milk, reduced fat, fluid, 2% milkfat, with added vitamin A and vitamin D",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 50,
			"proteinG": 3.36,
			"carbohydrateG": 4.9,
			"fatG": 1.9,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 126,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 103,
					"unit": "mg"
				},
				"potassium": {
					"value": 159,
					"unit": "mg"
				},
				"sodium": {
					"value": 39,
					"unit": "mg"
				},
				"zinc": {
					"value": .43,
					"unit": "mg"
				},
				"copper": {
					"value": .001,
					"unit": "mg"
				},
				"manganese": {
					"value": .001,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.8,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 83,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .03,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 1.13,
					"unit": "µg"
				},
				"thiamin": {
					"value": .059,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .137,
					"unit": "mg"
				},
				"niacin": {
					"value": .112,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .061,
					"unit": "mg"
				},
				"folate": {
					"value": 2,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .55,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746778/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746778,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 245
		}]
	},
	{
		"id": "usda-fdc-746782",
		"name": "Milk, whole, 3.25% milkfat, with added vitamin D",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 60,
			"proteinG": 3.27,
			"carbohydrateG": 4.63,
			"fatG": 3.2,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 123,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 101,
					"unit": "mg"
				},
				"potassium": {
					"value": 150,
					"unit": "mg"
				},
				"sodium": {
					"value": 38,
					"unit": "mg"
				},
				"zinc": {
					"value": .42,
					"unit": "mg"
				},
				"copper": {
					"value": .001,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.9,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 32,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .05,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .96,
					"unit": "µg"
				},
				"thiamin": {
					"value": .056,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .138,
					"unit": "mg"
				},
				"niacin": {
					"value": .105,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .061,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .54,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746782/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746782,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 249
		}]
	},
	{
		"id": "usda-fdc-2512379",
		"name": "Millet, whole grain",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 381,
			"proteinG": 10,
			"carbohydrateG": 74.4,
			"fatG": 4.19,
			"fiberG": 2.62,
			"micronutrients": {
				"calcium": {
					"value": 9.1,
					"unit": "mg"
				},
				"iron": {
					"value": 2.53,
					"unit": "mg"
				},
				"magnesium": {
					"value": 106,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 258,
					"unit": "mg"
				},
				"potassium": {
					"value": 214,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.26,
					"unit": "mg"
				},
				"copper": {
					"value": .488,
					"unit": "mg"
				},
				"manganese": {
					"value": .924,
					"unit": "mg"
				},
				"selenium": {
					"value": 23.1,
					"unit": "µg"
				},
				"thiamin": {
					"value": .411,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .136,
					"unit": "mg"
				},
				"niacin": {
					"value": 4.86,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .192,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512379/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512379,
			"release": "4/20/2023"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2003603",
		"name": "Mushroom, beech",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 33,
			"proteinG": 2.18,
			"carbohydrateG": 6.76,
			"fatG": .449,
			"fiberG": 3.14,
			"micronutrients": {
				"calcium": {
					"value": .432,
					"unit": "mg"
				},
				"iron": {
					"value": .739,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 85.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 376,
					"unit": "mg"
				},
				"sodium": {
					"value": .891,
					"unit": "mg"
				},
				"zinc": {
					"value": .498,
					"unit": "mg"
				},
				"copper": {
					"value": .073,
					"unit": "mg"
				},
				"manganese": {
					"value": .156,
					"unit": "mg"
				},
				"selenium": {
					"value": .38,
					"unit": "µg"
				},
				"vitaminD": {
					"value": .37,
					"unit": "µg"
				},
				"thiamin": {
					"value": .008,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .208,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.4,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .105,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003603/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003603,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003601",
		"name": "Mushroom, crimini",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 23.7,
			"proteinG": 3.09,
			"carbohydrateG": 4.01,
			"fatG": .197,
			"fiberG": 1.78,
			"micronutrients": {
				"calcium": {
					"value": 4.1,
					"unit": "mg"
				},
				"iron": {
					"value": .312,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 100,
					"unit": "mg"
				},
				"potassium": {
					"value": 380,
					"unit": "mg"
				},
				"sodium": {
					"value": 4.57,
					"unit": "mg"
				},
				"zinc": {
					"value": .512,
					"unit": "mg"
				},
				"copper": {
					"value": .321,
					"unit": "mg"
				},
				"manganese": {
					"value": .061,
					"unit": "mg"
				},
				"selenium": {
					"value": 15.3,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .004,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .517,
					"unit": "mg"
				},
				"niacin": {
					"value": 4.17,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .112,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003601/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003601,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003600",
		"name": "Mushroom, enoki",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 36.7,
			"proteinG": 2.42,
			"carbohydrateG": 8.14,
			"fatG": .245,
			"fiberG": 2.94,
			"micronutrients": {
				"calcium": {
					"value": 1.43,
					"unit": "mg"
				},
				"iron": {
					"value": 1.28,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 84.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 402,
					"unit": "mg"
				},
				"sodium": {
					"value": .417,
					"unit": "mg"
				},
				"zinc": {
					"value": .482,
					"unit": "mg"
				},
				"copper": {
					"value": .093,
					"unit": "mg"
				},
				"manganese": {
					"value": .09,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .012,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .24,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.99,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .119,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003600/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003600,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003599",
		"name": "Mushroom, king oyster",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 38.5,
			"proteinG": 2.41,
			"carbohydrateG": 8.5,
			"fatG": .308,
			"fiberG": 3.01,
			"micronutrients": {
				"calcium": {
					"value": 0,
					"unit": "mg"
				},
				"iron": {
					"value": .338,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 89.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 294,
					"unit": "mg"
				},
				"sodium": {
					"value": .771,
					"unit": "mg"
				},
				"zinc": {
					"value": .625,
					"unit": "mg"
				},
				"copper": {
					"value": .047,
					"unit": "mg"
				},
				"manganese": {
					"value": .091,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.2,
					"unit": "µg"
				},
				"vitaminD": {
					"value": .07,
					"unit": "µg"
				},
				"thiamin": {
					"value": .006,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .244,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.45,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .119,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003599/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003599,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-1999626",
		"name": "Mushroom, lion's mane",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 35.1,
			"proteinG": 2.5,
			"carbohydrateG": 7.59,
			"fatG": .256,
			"fiberG": 4.38,
			"micronutrients": {
				"calcium": {
					"value": 0,
					"unit": "mg"
				},
				"iron": {
					"value": .688,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 94,
					"unit": "mg"
				},
				"potassium": {
					"value": 443,
					"unit": "mg"
				},
				"sodium": {
					"value": .336,
					"unit": "mg"
				},
				"zinc": {
					"value": .745,
					"unit": "mg"
				},
				"copper": {
					"value": .177,
					"unit": "mg"
				},
				"manganese": {
					"value": .18,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.77,
					"unit": "µg"
				},
				"vitaminD": {
					"value": .021,
					"unit": "µg"
				},
				"thiamin": {
					"value": .146,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .363,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.63,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .066,
					"unit": "mg"
				},
				"folate": {
					"value": 29.6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999626/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999626,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003602",
		"name": "Mushroom, maitake",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 31,
			"proteinG": 2.2,
			"carbohydrateG": 6.6,
			"fatG": .265,
			"fiberG": 3.07,
			"micronutrients": {
				"calcium": {
					"value": 0,
					"unit": "mg"
				},
				"iron": {
					"value": .209,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 72.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 260,
					"unit": "mg"
				},
				"sodium": {
					"value": .345,
					"unit": "mg"
				},
				"zinc": {
					"value": .763,
					"unit": "mg"
				},
				"copper": {
					"value": .272,
					"unit": "mg"
				},
				"manganese": {
					"value": .058,
					"unit": "mg"
				},
				"selenium": {
					"value": 3.27,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 1.6,
					"unit": "µg"
				},
				"thiamin": {
					"value": .01,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .269,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.76,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .071,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003602/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003602,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-1999627",
		"name": "Mushroom, oyster",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 33.3,
			"proteinG": 2.9,
			"carbohydrateG": 6.94,
			"fatG": .188,
			"fiberG": 2.85,
			"micronutrients": {
				"calcium": {
					"value": 0,
					"unit": "mg"
				},
				"iron": {
					"value": .698,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 86.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 282,
					"unit": "mg"
				},
				"sodium": {
					"value": 1.13,
					"unit": "mg"
				},
				"zinc": {
					"value": .684,
					"unit": "mg"
				},
				"copper": {
					"value": .106,
					"unit": "mg"
				},
				"manganese": {
					"value": .086,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.38,
					"unit": "µg"
				},
				"vitaminD": {
					"value": .041,
					"unit": "µg"
				},
				"thiamin": {
					"value": .07,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .244,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.75,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .099,
					"unit": "mg"
				},
				"folate": {
					"value": 63.1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999627/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999627,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003604",
		"name": "Mushroom, pioppini",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 31.2,
			"proteinG": 3.5,
			"carbohydrateG": 5.76,
			"fatG": .24,
			"fiberG": 2.75,
			"micronutrients": {
				"calcium": {
					"value": 0,
					"unit": "mg"
				},
				"iron": {
					"value": .486,
					"unit": "mg"
				},
				"magnesium": {
					"value": 16,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 121,
					"unit": "mg"
				},
				"potassium": {
					"value": 392,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .857,
					"unit": "mg"
				},
				"copper": {
					"value": .276,
					"unit": "mg"
				},
				"manganese": {
					"value": .098,
					"unit": "mg"
				},
				"selenium": {
					"value": 4.12,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .012,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .426,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.22,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .102,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003604/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003604,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003598",
		"name": "Mushroom, portabella",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 26,
			"proteinG": 2.75,
			"carbohydrateG": 4.66,
			"fatG": .312,
			"fiberG": 1.88,
			"micronutrients": {
				"calcium": {
					"value": 3.24,
					"unit": "mg"
				},
				"iron": {
					"value": .139,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9.04,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 87.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 349,
					"unit": "mg"
				},
				"sodium": {
					"value": 5.31,
					"unit": "mg"
				},
				"zinc": {
					"value": .389,
					"unit": "mg"
				},
				"copper": {
					"value": .203,
					"unit": "mg"
				},
				"manganese": {
					"value": .049,
					"unit": "mg"
				},
				"selenium": {
					"value": 14.7,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .005,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .465,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.9,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .097,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003598/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003598,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-1999628",
		"name": "Mushrooms, shiitake",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 36.4,
			"proteinG": 2.41,
			"carbohydrateG": 8.17,
			"fatG": .195,
			"fiberG": 4.17,
			"micronutrients": {
				"calcium": {
					"value": .766,
					"unit": "mg"
				},
				"iron": {
					"value": .144,
					"unit": "mg"
				},
				"magnesium": {
					"value": 14.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 75.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 243,
					"unit": "mg"
				},
				"sodium": {
					"value": .936,
					"unit": "mg"
				},
				"zinc": {
					"value": .764,
					"unit": "mg"
				},
				"copper": {
					"value": .05,
					"unit": "mg"
				},
				"manganese": {
					"value": .173,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.24,
					"unit": "µg"
				},
				"vitaminD": {
					"value": .056,
					"unit": "µg"
				},
				"thiamin": {
					"value": .001,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .216,
					"unit": "mg"
				},
				"niacin": {
					"value": 2.74,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .159,
					"unit": "mg"
				},
				"folate": {
					"value": 32.1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999628/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999628,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-1999629",
		"name": "Mushrooms, white button",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 24.9,
			"proteinG": 2.89,
			"carbohydrateG": 4.08,
			"fatG": .371,
			"fiberG": 1.72,
			"micronutrients": {
				"calcium": {
					"value": 5.46,
					"unit": "mg"
				},
				"iron": {
					"value": .227,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 93,
					"unit": "mg"
				},
				"potassium": {
					"value": 373,
					"unit": "mg"
				},
				"sodium": {
					"value": 6.44,
					"unit": "mg"
				},
				"zinc": {
					"value": .511,
					"unit": "mg"
				},
				"copper": {
					"value": .389,
					"unit": "mg"
				},
				"manganese": {
					"value": .054,
					"unit": "mg"
				},
				"selenium": {
					"value": 20,
					"unit": "µg"
				},
				"vitaminD": {
					"value": .022,
					"unit": "µg"
				},
				"thiamin": {
					"value": .065,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .444,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.88,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .077,
					"unit": "mg"
				},
				"folate": {
					"value": 34.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999629/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999629,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-326698",
		"name": "Mustard, prepared, yellow",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 61,
			"proteinG": 4.25,
			"carbohydrateG": 5.3,
			"fatG": 3.38,
			"fiberG": 4.3,
			"micronutrients": {
				"calcium": {
					"value": 63,
					"unit": "mg"
				},
				"iron": {
					"value": 1.59,
					"unit": "mg"
				},
				"magnesium": {
					"value": 47.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 108,
					"unit": "mg"
				},
				"potassium": {
					"value": 150,
					"unit": "mg"
				},
				"sodium": {
					"value": 1100,
					"unit": "mg"
				},
				"zinc": {
					"value": .64,
					"unit": "mg"
				},
				"copper": {
					"value": .074,
					"unit": "mg"
				},
				"manganese": {
					"value": .42,
					"unit": "mg"
				},
				"selenium": {
					"value": 34,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 4,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .35,
					"unit": "mg"
				},
				"vitaminC": {
					"value": .4,
					"unit": "mg"
				},
				"thiamin": {
					"value": .189,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .066,
					"unit": "mg"
				},
				"niacin": {
					"value": .561,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .069,
					"unit": "mg"
				},
				"folate": {
					"value": 7,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 1.5,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/326698/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 326698,
			"release": "4/1/2019"
		},
		"preparationState": "prepared",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 249
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 tsp",
			"weightGrams": 6
		}]
	},
	{
		"id": "usda-fdc-327357",
		"name": "Nectarines, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 39,
			"proteinG": 1.06,
			"carbohydrateG": 9.18,
			"fatG": .28,
			"fiberG": 1.5,
			"micronutrients": {
				"calcium": {
					"value": 2,
					"unit": "mg"
				},
				"iron": {
					"value": .3,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 26,
					"unit": "mg"
				},
				"potassium": {
					"value": 131,
					"unit": "mg"
				},
				"sodium": {
					"value": 13,
					"unit": "mg"
				},
				"zinc": {
					"value": .21,
					"unit": "mg"
				},
				"copper": {
					"value": .082,
					"unit": "mg"
				},
				"manganese": {
					"value": .047,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 21,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .61,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 2.9,
					"unit": "mg"
				},
				"thiamin": {
					"value": .034,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .027,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.12,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .025,
					"unit": "mg"
				},
				"folate": {
					"value": 6,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/327357/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 327357,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 2-1/3\" dia each",
				"weightGrams": 129
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 2-3/4\" dia each",
				"weightGrams": 156
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 2-1/2\" dia each",
				"weightGrams": 142
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 NLEA serving",
				"weightGrams": 140
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 slices cup",
				"weightGrams": 143
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 140
			}
		]
	},
	{
		"id": "usda-fdc-323294",
		"name": "Nuts, almonds, dry roasted, with salt added",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 620,
			"proteinG": 20.4,
			"carbohydrateG": 16.2,
			"fatG": 57.8,
			"fiberG": 11,
			"micronutrients": {
				"calcium": {
					"value": 273,
					"unit": "mg"
				},
				"iron": {
					"value": 3.17,
					"unit": "mg"
				},
				"magnesium": {
					"value": 258,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 456,
					"unit": "mg"
				},
				"potassium": {
					"value": 684,
					"unit": "mg"
				},
				"sodium": {
					"value": 256,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.8,
					"unit": "mg"
				},
				"copper": {
					"value": .87,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.02,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 2,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 19,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .079,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 1.57,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.1,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .075,
					"unit": "mg"
				},
				"folate": {
					"value": 35,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/323294/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 323294,
			"release": "4/1/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 whole cup",
			"weightGrams": 135
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2346393",
		"name": "Nuts, almonds, whole, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 584,
			"proteinG": 21.5,
			"carbohydrateG": 20,
			"fatG": 51.1,
			"fiberG": 10.8,
			"micronutrients": {
				"calcium": {
					"value": 254,
					"unit": "mg"
				},
				"iron": {
					"value": 3.74,
					"unit": "mg"
				},
				"magnesium": {
					"value": 258,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 503,
					"unit": "mg"
				},
				"potassium": {
					"value": 733,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.86,
					"unit": "mg"
				},
				"copper": {
					"value": .91,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.15,
					"unit": "mg"
				},
				"thiamin": {
					"value": .16,
					"unit": "mg"
				},
				"niacin": {
					"value": 3.77,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .101,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346393/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346393,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2515373",
		"name": "Nuts, brazilnuts, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 621,
			"proteinG": 15,
			"carbohydrateG": 21.6,
			"fatG": 57.4,
			"fiberG": 5.98,
			"micronutrients": {
				"calcium": {
					"value": 168,
					"unit": "mg"
				},
				"iron": {
					"value": 2.47,
					"unit": "mg"
				},
				"magnesium": {
					"value": 351,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 707,
					"unit": "mg"
				},
				"potassium": {
					"value": 592,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.82,
					"unit": "mg"
				},
				"copper": {
					"value": 1.74,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.26,
					"unit": "mg"
				},
				"selenium": {
					"value": 280,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515373/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515373,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2515374",
		"name": "Nuts, cashew nuts, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 533,
			"proteinG": 17.4,
			"carbohydrateG": 36.3,
			"fatG": 38.9,
			"fiberG": 4.1,
			"micronutrients": {
				"calcium": {
					"value": 42,
					"unit": "mg"
				},
				"iron": {
					"value": 5.99,
					"unit": "mg"
				},
				"magnesium": {
					"value": 251,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 532,
					"unit": "mg"
				},
				"potassium": {
					"value": 638,
					"unit": "mg"
				},
				"sodium": {
					"value": 4.76,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.07,
					"unit": "mg"
				},
				"copper": {
					"value": 2.22,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.95,
					"unit": "mg"
				},
				"selenium": {
					"value": 20.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515374/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515374,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2515375",
		"name": "Nuts, hazelnuts or filberts, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 602,
			"proteinG": 13.5,
			"carbohydrateG": 26.5,
			"fatG": 53.5,
			"fiberG": 8.41,
			"micronutrients": {
				"calcium": {
					"value": 135,
					"unit": "mg"
				},
				"iron": {
					"value": 3.46,
					"unit": "mg"
				},
				"magnesium": {
					"value": 156,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 321,
					"unit": "mg"
				},
				"potassium": {
					"value": 636,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.33,
					"unit": "mg"
				},
				"copper": {
					"value": 1.41,
					"unit": "mg"
				},
				"manganese": {
					"value": 6.06,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515375/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515375,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2515378",
		"name": "Nuts, macadamia nuts, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 669,
			"proteinG": 7.79,
			"carbohydrateG": 24.1,
			"fatG": 64.9,
			"fiberG": 7.56,
			"micronutrients": {
				"calcium": {
					"value": 52.7,
					"unit": "mg"
				},
				"iron": {
					"value": 1.88,
					"unit": "mg"
				},
				"magnesium": {
					"value": 107,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 208,
					"unit": "mg"
				},
				"potassium": {
					"value": 373,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.2,
					"unit": "mg"
				},
				"copper": {
					"value": .446,
					"unit": "mg"
				},
				"manganese": {
					"value": 11.3,
					"unit": "mg"
				},
				"selenium": {
					"value": 32.6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515378/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515378,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2346395",
		"name": "Nuts, pecans, halves, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 700,
			"proteinG": 9.96,
			"carbohydrateG": 12.7,
			"fatG": 73.3,
			"fiberG": 5.79,
			"micronutrients": {
				"calcium": {
					"value": 54.8,
					"unit": "mg"
				},
				"iron": {
					"value": 2.37,
					"unit": "mg"
				},
				"magnesium": {
					"value": 103,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 253,
					"unit": "mg"
				},
				"potassium": {
					"value": 360,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.93,
					"unit": "mg"
				},
				"copper": {
					"value": .906,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.28,
					"unit": "mg"
				},
				"thiamin": {
					"value": .548,
					"unit": "mg"
				},
				"niacin": {
					"value": .946,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .171,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 4.1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346395/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346395,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2346392",
		"name": "Nuts, pine nuts, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 643,
			"proteinG": 15.7,
			"carbohydrateG": 18.6,
			"fatG": 61.3,
			"fiberG": 3.94,
			"micronutrients": {
				"calcium": {
					"value": 8.74,
					"unit": "mg"
				},
				"iron": {
					"value": 5.36,
					"unit": "mg"
				},
				"magnesium": {
					"value": 206,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 540,
					"unit": "mg"
				},
				"potassium": {
					"value": 655,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.71,
					"unit": "mg"
				},
				"copper": {
					"value": 1.12,
					"unit": "mg"
				},
				"manganese": {
					"value": 10.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": .625,
					"unit": "mg"
				},
				"niacin": {
					"value": 4.47,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .255,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 3.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346392/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346392,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2515379",
		"name": "Nuts, pistachio nuts, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 561,
			"proteinG": 20.5,
			"carbohydrateG": 27.7,
			"fatG": 45,
			"fiberG": 6.97,
			"micronutrients": {
				"calcium": {
					"value": 117,
					"unit": "mg"
				},
				"iron": {
					"value": 3.46,
					"unit": "mg"
				},
				"magnesium": {
					"value": 110,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 500,
					"unit": "mg"
				},
				"potassium": {
					"value": 947,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.18,
					"unit": "mg"
				},
				"copper": {
					"value": 1.05,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.05,
					"unit": "mg"
				},
				"selenium": {
					"value": 23.1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515379/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515379,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2346394",
		"name": "Nuts, walnuts, English, halves, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 679,
			"proteinG": 14.6,
			"carbohydrateG": 10.9,
			"fatG": 69.7,
			"fiberG": 5.21,
			"micronutrients": {
				"calcium": {
					"value": 88.3,
					"unit": "mg"
				},
				"iron": {
					"value": 2.24,
					"unit": "mg"
				},
				"magnesium": {
					"value": 142,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 365,
					"unit": "mg"
				},
				"potassium": {
					"value": 424,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.76,
					"unit": "mg"
				},
				"copper": {
					"value": 1.21,
					"unit": "mg"
				},
				"manganese": {
					"value": 3,
					"unit": "mg"
				},
				"thiamin": {
					"value": .23,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.22,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .66,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 1.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346394/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346394,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2257046",
		"name": "Oat milk, unsweetened, plain, refrigerated",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 48.3,
			"proteinG": .797,
			"carbohydrateG": 5.1,
			"fatG": 2.75,
			"fiberG": 0,
			"micronutrients": {
				"calcium": {
					"value": 148,
					"unit": "mg"
				},
				"iron": {
					"value": .261,
					"unit": "mg"
				},
				"magnesium": {
					"value": 5.91,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 89.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 148,
					"unit": "mg"
				},
				"sodium": {
					"value": 42,
					"unit": "mg"
				},
				"zinc": {
					"value": .091,
					"unit": "mg"
				},
				"copper": {
					"value": .027,
					"unit": "mg"
				},
				"manganese": {
					"value": .126,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 1.7,
					"unit": "µg"
				},
				"thiamin": {
					"value": .04,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .281,
					"unit": "mg"
				},
				"niacin": {
					"value": .096,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .006,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .506,
					"unit": "µg"
				},
				"vitaminK": {
					"value": .4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2257046/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2257046,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2346396",
		"name": "Oats, whole grain, rolled, old fashioned",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 379,
			"proteinG": 13.5,
			"carbohydrateG": 68.7,
			"fatG": 5.89,
			"fiberG": 10.4,
			"micronutrients": {
				"calcium": {
					"value": 45.5,
					"unit": "mg"
				},
				"iron": {
					"value": 4.34,
					"unit": "mg"
				},
				"magnesium": {
					"value": 126,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 387,
					"unit": "mg"
				},
				"potassium": {
					"value": 350,
					"unit": "mg"
				},
				"sodium": {
					"value": .668,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.74,
					"unit": "mg"
				},
				"copper": {
					"value": .428,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.23,
					"unit": "mg"
				},
				"selenium": {
					"value": 25.4,
					"unit": "µg"
				},
				"thiamin": {
					"value": .406,
					"unit": "mg"
				},
				"niacin": {
					"value": .993,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .135,
					"unit": "mg"
				},
				"folate": {
					"value": 32,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346396/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346396,
			"release": "10/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 40
		}]
	},
	{
		"id": "usda-fdc-2346397",
		"name": "Oats, whole grain, steel cut",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 379,
			"proteinG": 12.5,
			"carbohydrateG": 69.8,
			"fatG": 5.8,
			"fiberG": 12,
			"micronutrients": {
				"calcium": {
					"value": 51.3,
					"unit": "mg"
				},
				"iron": {
					"value": 3.8,
					"unit": "mg"
				},
				"magnesium": {
					"value": 129,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 417,
					"unit": "mg"
				},
				"potassium": {
					"value": 376,
					"unit": "mg"
				},
				"sodium": {
					"value": .311,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.84,
					"unit": "mg"
				},
				"copper": {
					"value": .411,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.41,
					"unit": "mg"
				},
				"selenium": {
					"value": 29,
					"unit": "µg"
				},
				"thiamin": {
					"value": .334,
					"unit": "mg"
				},
				"niacin": {
					"value": .926,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .119,
					"unit": "mg"
				},
				"folate": {
					"value": 30,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346397/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346397,
			"release": "10/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 40
		}]
	},
	{
		"id": "usda-fdc-748278",
		"name": "Oil, canola",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": { "vitaminE": {
				"value": 17.3,
				"unit": "mg"
			} }
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/748278/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 748278,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 100,
			"unit": "serving",
			"description": "100 ml",
			"weightGrams": 90.9
		}]
	},
	{
		"id": "usda-fdc-330458",
		"name": "Oil, coconut",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 833,
			"proteinG": 0,
			"carbohydrateG": .84,
			"fatG": 99.1,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 1,
					"unit": "mg"
				},
				"iron": {
					"value": .05,
					"unit": "mg"
				},
				"magnesium": {
					"value": 0,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 0,
					"unit": "mg"
				},
				"potassium": {
					"value": 0,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .02,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminE": {
					"value": .11,
					"unit": "mg"
				},
				"vitaminK": {
					"value": .6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/330458/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 330458,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 liquid oil tbsp",
			"weightGrams": 11.6
		}]
	},
	{
		"id": "usda-fdc-748323",
		"name": "Oil, corn",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": { "vitaminE": {
				"value": 22.6,
				"unit": "mg"
			} }
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/748323/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 748323,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 100,
			"unit": "serving",
			"description": "100 ml",
			"weightGrams": 91.3
		}]
	},
	{
		"id": "usda-fdc-1750351",
		"name": "Oil, olive, extra light",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"vitaminE": {
					"value": 20.9,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 26,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750351/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750351,
			"release": "4/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-1750348",
		"name": "Oil, peanut",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"vitaminE": {
					"value": 15.2,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 4.26,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750348/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750348,
			"release": "4/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-1750350",
		"name": "Oil, safflower",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"vitaminE": {
					"value": 46,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 5.34,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750350/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750350,
			"release": "4/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-748366",
		"name": "Oil, soybean",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": { "vitaminE": {
				"value": 12.2,
				"unit": "mg"
			} }
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/748366/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 748366,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 100,
			"unit": "serving",
			"description": "100 ml",
			"weightGrams": 91.3
		}]
	},
	{
		"id": "usda-fdc-1750349",
		"name": "Oil, sunflower",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"vitaminE": {
					"value": 68.5,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 6.92,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1750349/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1750349,
			"release": "4/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-332791",
		"name": "Olives, green, Manzanilla, stuffed with pimiento",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 130,
			"proteinG": 1.15,
			"carbohydrateG": 4.96,
			"fatG": 12.9,
			"fiberG": 4,
			"micronutrients": {
				"calcium": {
					"value": 121,
					"unit": "mg"
				},
				"iron": {
					"value": .31,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 7,
					"unit": "mg"
				},
				"potassium": {
					"value": 43,
					"unit": "mg"
				},
				"sodium": {
					"value": 1620,
					"unit": "mg"
				},
				"zinc": {
					"value": .09,
					"unit": "mg"
				},
				"copper": {
					"value": .107,
					"unit": "mg"
				},
				"manganese": {
					"value": .047,
					"unit": "mg"
				},
				"vitaminA": {
					"value": 25,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 3.78,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .041,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": .103,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": 0,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 16.6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/332791/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 332791,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 olive",
			"weightGrams": 3.2
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 40
		}]
	},
	{
		"id": "usda-fdc-324317",
		"name": "Onion rings, breaded, par fried, frozen, prepared, heated in oven",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 288,
			"proteinG": 4.52,
			"carbohydrateG": 36.3,
			"fatG": 14.4,
			"fiberG": 2.4,
			"micronutrients": {
				"calcium": {
					"value": 28,
					"unit": "mg"
				},
				"iron": {
					"value": 1.14,
					"unit": "mg"
				},
				"magnesium": {
					"value": 20.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 75,
					"unit": "mg"
				},
				"potassium": {
					"value": 135,
					"unit": "mg"
				},
				"sodium": {
					"value": 374,
					"unit": "mg"
				},
				"zinc": {
					"value": .59,
					"unit": "mg"
				},
				"copper": {
					"value": .081,
					"unit": "mg"
				},
				"manganese": {
					"value": .435,
					"unit": "mg"
				},
				"selenium": {
					"value": 5.6,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .57,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 1.6,
					"unit": "mg"
				},
				"thiamin": {
					"value": .196,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .116,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.57,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .127,
					"unit": "mg"
				},
				"folate": {
					"value": 31,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/324317/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 324317,
			"release": "4/1/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 piece",
			"weightGrams": 20.2
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-790577",
		"name": "Onions, red, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 44,
			"proteinG": .94,
			"carbohydrateG": 9.93,
			"fatG": .1,
			"fiberG": 2.2,
			"micronutrients": {
				"calcium": {
					"value": 17,
					"unit": "mg"
				},
				"iron": {
					"value": .24,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 41,
					"unit": "mg"
				},
				"potassium": {
					"value": 197,
					"unit": "mg"
				},
				"sodium": {
					"value": 1,
					"unit": "mg"
				},
				"zinc": {
					"value": .17,
					"unit": "mg"
				},
				"copper": {
					"value": .058,
					"unit": "mg"
				},
				"manganese": {
					"value": .119,
					"unit": "mg"
				},
				"selenium": {
					"value": .5,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 8.1,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/790577/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 790577,
			"release": "4/1/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 Edible Onion",
			"weightGrams": 197
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-1104962",
		"name": "Onions, white, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 35,
			"proteinG": .89,
			"carbohydrateG": 7.68,
			"fatG": .13,
			"fiberG": 1.2,
			"micronutrients": {
				"calcium": {
					"value": 21,
					"unit": "mg"
				},
				"iron": {
					"value": .15,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 29,
					"unit": "mg"
				},
				"potassium": {
					"value": 141,
					"unit": "mg"
				},
				"sodium": {
					"value": 2,
					"unit": "mg"
				},
				"zinc": {
					"value": .12,
					"unit": "mg"
				},
				"copper": {
					"value": .047,
					"unit": "mg"
				},
				"manganese": {
					"value": .099,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1104962/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1104962,
			"release": "10/30/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-790646",
		"name": "Onions, yellow, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 38,
			"proteinG": .83,
			"carbohydrateG": 8.61,
			"fatG": .05,
			"fiberG": 1.9,
			"micronutrients": {
				"calcium": {
					"value": 15,
					"unit": "mg"
				},
				"iron": {
					"value": .28,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 34,
					"unit": "mg"
				},
				"potassium": {
					"value": 182,
					"unit": "mg"
				},
				"sodium": {
					"value": 1,
					"unit": "mg"
				},
				"zinc": {
					"value": .2,
					"unit": "mg"
				},
				"copper": {
					"value": .035,
					"unit": "mg"
				},
				"manganese": {
					"value": .144,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 8.2,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/790646/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 790646,
			"release": "4/1/2020"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 Edible Onion",
			"weightGrams": 143
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003591",
		"name": "Orange juice, no pulp, not fortified, from concentrate, refrigerated",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 45.7,
			"proteinG": .734,
			"carbohydrateG": 10.3,
			"fatG": .325,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 12.8,
					"unit": "mg"
				},
				"iron": {
					"value": .065,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 18.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 180,
					"unit": "mg"
				},
				"sodium": {
					"value": 5.23,
					"unit": "mg"
				},
				"zinc": {
					"value": .032,
					"unit": "mg"
				},
				"copper": {
					"value": .032,
					"unit": "mg"
				},
				"manganese": {
					"value": .03,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 26.9,
					"unit": "mg"
				},
				"thiamin": {
					"value": .07,
					"unit": "mg"
				},
				"niacin": {
					"value": .04,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .043,
					"unit": "mg"
				},
				"folate": {
					"value": 29.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003591/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003591,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2003597",
		"name": "Orange juice, no pulp, not fortified, not from concentrate, refrigerated",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 45,
			"proteinG": .812,
			"carbohydrateG": 10,
			"fatG": .356,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 9.29,
					"unit": "mg"
				},
				"iron": {
					"value": .071,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 19,
					"unit": "mg"
				},
				"potassium": {
					"value": 183,
					"unit": "mg"
				},
				"sodium": {
					"value": .075,
					"unit": "mg"
				},
				"zinc": {
					"value": .032,
					"unit": "mg"
				},
				"copper": {
					"value": .035,
					"unit": "mg"
				},
				"manganese": {
					"value": .028,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 30.5,
					"unit": "mg"
				},
				"thiamin": {
					"value": .075,
					"unit": "mg"
				},
				"niacin": {
					"value": .029,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .041,
					"unit": "mg"
				},
				"folate": {
					"value": 29,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003597/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003597,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-746771",
		"name": "Oranges, raw, navels",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 47,
			"proteinG": .91,
			"carbohydrateG": 11.8,
			"fatG": .15,
			"fiberG": 2,
			"micronutrients": {
				"calcium": {
					"value": 43,
					"unit": "mg"
				},
				"iron": {
					"value": .33,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 23,
					"unit": "mg"
				},
				"potassium": {
					"value": 166,
					"unit": "mg"
				},
				"sodium": {
					"value": 9,
					"unit": "mg"
				},
				"zinc": {
					"value": .11,
					"unit": "mg"
				},
				"copper": {
					"value": .064,
					"unit": "mg"
				},
				"manganese": {
					"value": .029,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 59.1,
					"unit": "mg"
				},
				"thiamin": {
					"value": .068,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .051,
					"unit": "mg"
				},
				"niacin": {
					"value": .425,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .079,
					"unit": "mg"
				},
				"folate": {
					"value": 25,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746771/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746771,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 sections no membranes cup",
				"weightGrams": 165
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 2-7/8\" dia each",
				"weightGrams": 140
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 140
			}
		]
	},
	{
		"id": "usda-fdc-2747659",
		"name": "Parsnips, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 87.1,
			"proteinG": 1.27,
			"carbohydrateG": 19.3,
			"fatG": .538,
			"fiberG": 5.35,
			"micronutrients": {
				"calcium": {
					"value": 44.2,
					"unit": "mg"
				},
				"iron": {
					"value": .505,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 62.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 493,
					"unit": "mg"
				},
				"sodium": {
					"value": .491,
					"unit": "mg"
				},
				"zinc": {
					"value": .328,
					"unit": "mg"
				},
				"copper": {
					"value": .116,
					"unit": "mg"
				},
				"manganese": {
					"value": .239,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 11.8,
					"unit": "mg"
				},
				"folate": {
					"value": 83.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747659/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747659,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2727577",
		"name": "Pawpaw, peeled, seeded, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 1.15,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 3.3,
			"micronutrients": {
				"calcium": {
					"value": 9.91,
					"unit": "mg"
				},
				"iron": {
					"value": .075,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 23.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 221,
					"unit": "mg"
				},
				"sodium": {
					"value": .351,
					"unit": "mg"
				},
				"zinc": {
					"value": .085,
					"unit": "mg"
				},
				"copper": {
					"value": .105,
					"unit": "mg"
				},
				"manganese": {
					"value": .05,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 27.6,
					"unit": "mg"
				},
				"folate": {
					"value": 116,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727577/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727577,
			"release": "4/24/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-325430",
		"name": "Peaches, yellow, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 42,
			"proteinG": .91,
			"carbohydrateG": 10.1,
			"fatG": .27,
			"fiberG": 1.5,
			"micronutrients": {
				"calcium": {
					"value": 4,
					"unit": "mg"
				},
				"iron": {
					"value": .34,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 22,
					"unit": "mg"
				},
				"potassium": {
					"value": 122,
					"unit": "mg"
				},
				"sodium": {
					"value": 13,
					"unit": "mg"
				},
				"zinc": {
					"value": .23,
					"unit": "mg"
				},
				"copper": {
					"value": .078,
					"unit": "mg"
				},
				"manganese": {
					"value": .026,
					"unit": "mg"
				},
				"selenium": {
					"value": 2.1,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 24,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 4.1,
					"unit": "mg"
				},
				"thiamin": {
					"value": .024,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .031,
					"unit": "mg"
				},
				"niacin": {
					"value": .806,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .025,
					"unit": "mg"
				},
				"folate": {
					"value": 6,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 3,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/325430/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 325430,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 small (2-1/2\" dia) fruit",
				"weightGrams": 147
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 slices with skin cup",
				"weightGrams": 154
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 large (2-3/4\" dia) fruit",
				"weightGrams": 173
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 extra large (3\" dia) fruit",
				"weightGrams": 225
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 medium (2-2/3\" dia) fruit",
				"weightGrams": 161
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 NLEA serving",
				"weightGrams": 147
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 140
			}
		]
	},
	{
		"id": "usda-fdc-2262072",
		"name": "Peanut butter, creamy",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 589,
			"proteinG": 24,
			"carbohydrateG": 22.7,
			"fatG": 49.4,
			"fiberG": 6.32,
			"micronutrients": {
				"calcium": {
					"value": 49.8,
					"unit": "mg"
				},
				"iron": {
					"value": 1.85,
					"unit": "mg"
				},
				"magnesium": {
					"value": 193,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 393,
					"unit": "mg"
				},
				"potassium": {
					"value": 654,
					"unit": "mg"
				},
				"sodium": {
					"value": 221,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.06,
					"unit": "mg"
				},
				"copper": {
					"value": .54,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.68,
					"unit": "mg"
				},
				"selenium": {
					"value": 20.2,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 5.41,
					"unit": "mg"
				},
				"thiamin": {
					"value": .121,
					"unit": "mg"
				},
				"niacin": {
					"value": 17.2,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .38,
					"unit": "mg"
				},
				"folate": {
					"value": 97.3,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2262072/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2262072,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2515376",
		"name": "Peanuts, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 551,
			"proteinG": 23.2,
			"carbohydrateG": 26.5,
			"fatG": 43.3,
			"fiberG": 8.01,
			"micronutrients": {
				"calcium": {
					"value": 49.1,
					"unit": "mg"
				},
				"iron": {
					"value": 1.55,
					"unit": "mg"
				},
				"magnesium": {
					"value": 180,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 380,
					"unit": "mg"
				},
				"potassium": {
					"value": 636,
					"unit": "mg"
				},
				"sodium": {
					"value": 1.49,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.78,
					"unit": "mg"
				},
				"copper": {
					"value": .46,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.68,
					"unit": "mg"
				},
				"selenium": {
					"value": 17.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515376/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515376,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2710836",
		"name": "Pear, Anjou, green, with skin, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 57.3,
			"proteinG": .312,
			"carbohydrateG": 14.8,
			"fatG": .371,
			"fiberG": 2.64,
			"micronutrients": {
				"calcium": {
					"value": 9.99,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 6.49,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 12.3,
					"unit": "mg"
				},
				"potassium": {
					"value": 122,
					"unit": "mg"
				},
				"sodium": {
					"value": .398,
					"unit": "mg"
				},
				"zinc": {
					"value": .107,
					"unit": "mg"
				},
				"copper": {
					"value": .081,
					"unit": "mg"
				},
				"manganese": {
					"value": .054,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 5.51,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710836/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710836,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-746773",
		"name": "Pears, raw, bartlett",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 57,
			"proteinG": .38,
			"carbohydrateG": 15.1,
			"fatG": .16,
			"fiberG": 3.1,
			"micronutrients": {
				"calcium": {
					"value": 8,
					"unit": "mg"
				},
				"iron": {
					"value": .17,
					"unit": "mg"
				},
				"magnesium": {
					"value": 5.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 10,
					"unit": "mg"
				},
				"potassium": {
					"value": 87,
					"unit": "mg"
				},
				"sodium": {
					"value": 7,
					"unit": "mg"
				},
				"zinc": {
					"value": .07,
					"unit": "mg"
				},
				"copper": {
					"value": .07,
					"unit": "mg"
				},
				"manganese": {
					"value": .032,
					"unit": "mg"
				},
				"selenium": {
					"value": .2,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 1,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 4.4,
					"unit": "mg"
				},
				"thiamin": {
					"value": .012,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .026,
					"unit": "mg"
				},
				"niacin": {
					"value": .164,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .026,
					"unit": "mg"
				},
				"folate": {
					"value": 6,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 3.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746773/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746773,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 slices cup",
				"weightGrams": 140
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 medium each",
				"weightGrams": 178
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 large each",
				"weightGrams": 230
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 small each",
				"weightGrams": 148
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 140
			}
		]
	},
	{
		"id": "usda-fdc-2644291",
		"name": "Peas, green, sweet, canned, sodium added, sugar added, drained and rinsed",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 77.8,
			"proteinG": 4.73,
			"carbohydrateG": 12.7,
			"fatG": 1.15,
			"fiberG": 5.95,
			"micronutrients": {
				"calcium": {
					"value": 28.2,
					"unit": "mg"
				},
				"iron": {
					"value": 1.14,
					"unit": "mg"
				},
				"magnesium": {
					"value": 21.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 77.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 109,
					"unit": "mg"
				},
				"sodium": {
					"value": 207,
					"unit": "mg"
				},
				"zinc": {
					"value": .712,
					"unit": "mg"
				},
				"copper": {
					"value": .123,
					"unit": "mg"
				},
				"manganese": {
					"value": .285,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2644291/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2644291,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2747660",
		"name": "Peppers, banana or Hungarian wax, seeded, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 23.9,
			"proteinG": .723,
			"carbohydrateG": 4.97,
			"fatG": .131,
			"fiberG": 1.79,
			"micronutrients": {
				"calcium": {
					"value": 9.82,
					"unit": "mg"
				},
				"iron": {
					"value": .162,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 21.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 177,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .13,
					"unit": "mg"
				},
				"copper": {
					"value": .061,
					"unit": "mg"
				},
				"manganese": {
					"value": .113,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 112,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .287,
					"unit": "mg"
				},
				"folate": {
					"value": 31.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747660/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747660,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2258588",
		"name": "Peppers, bell, green, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 19.7,
			"proteinG": .715,
			"carbohydrateG": 4.78,
			"fatG": .106,
			"fiberG": .942,
			"micronutrients": {
				"calcium": {
					"value": 7.5,
					"unit": "mg"
				},
				"iron": {
					"value": .186,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 16.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 163,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .126,
					"unit": "mg"
				},
				"copper": {
					"value": .058,
					"unit": "mg"
				},
				"manganese": {
					"value": .1,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 99.5,
					"unit": "mg"
				},
				"thiamin": {
					"value": .039,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .089,
					"unit": "mg"
				},
				"niacin": {
					"value": .636,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .247,
					"unit": "mg"
				},
				"folate": {
					"value": 22.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2258588/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2258588,
			"release": "4/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2258591",
		"name": "Peppers, bell, orange, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 27.4,
			"proteinG": .882,
			"carbohydrateG": 6.7,
			"fatG": .156,
			"fiberG": .967,
			"micronutrients": {
				"calcium": {
					"value": 4.9,
					"unit": "mg"
				},
				"iron": {
					"value": .365,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 26.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 201,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .242,
					"unit": "mg"
				},
				"copper": {
					"value": .035,
					"unit": "mg"
				},
				"manganese": {
					"value": .149,
					"unit": "mg"
				},
				"selenium": {
					"value": .3,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 158,
					"unit": "mg"
				},
				"thiamin": {
					"value": .055,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .102,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.08,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .332,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2258591/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2258591,
			"release": "4/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2258590",
		"name": "Peppers, bell, red, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 27,
			"proteinG": .896,
			"carbohydrateG": 6.65,
			"fatG": .126,
			"fiberG": 1.16,
			"micronutrients": {
				"calcium": {
					"value": 6.36,
					"unit": "mg"
				},
				"iron": {
					"value": .353,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 26.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 213,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .202,
					"unit": "mg"
				},
				"copper": {
					"value": .04,
					"unit": "mg"
				},
				"manganese": {
					"value": .133,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 142,
					"unit": "mg"
				},
				"thiamin": {
					"value": .055,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .142,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.02,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .303,
					"unit": "mg"
				},
				"folate": {
					"value": 47.3,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2258590/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2258590,
			"release": "4/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2258589",
		"name": "Peppers, bell, yellow, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 26.6,
			"proteinG": .819,
			"carbohydrateG": 6.6,
			"fatG": .121,
			"fiberG": 1.07,
			"micronutrients": {
				"calcium": {
					"value": 6.69,
					"unit": "mg"
				},
				"iron": {
					"value": .36,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 24.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 197,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .193,
					"unit": "mg"
				},
				"copper": {
					"value": .045,
					"unit": "mg"
				},
				"manganese": {
					"value": .142,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 139,
					"unit": "mg"
				},
				"thiamin": {
					"value": .049,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .098,
					"unit": "mg"
				},
				"niacin": {
					"value": .91,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .292,
					"unit": "mg"
				},
				"folate": {
					"value": 41.6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2258589/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2258589,
			"release": "4/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2747661",
		"name": "Peppers, jalapeno, seeded, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 24.1,
			"proteinG": .621,
			"carbohydrateG": 5.08,
			"fatG": .149,
			"fiberG": 1.72,
			"micronutrients": {
				"calcium": {
					"value": 10.1,
					"unit": "mg"
				},
				"iron": {
					"value": .038,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.95,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 19.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 167,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .094,
					"unit": "mg"
				},
				"copper": {
					"value": .051,
					"unit": "mg"
				},
				"manganese": {
					"value": .077,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 89.9,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .267,
					"unit": "mg"
				},
				"folate": {
					"value": 27.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747661/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747661,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2747662",
		"name": "Peppers, poblano, seeded, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 28,
			"proteinG": 1.43,
			"carbohydrateG": 5.14,
			"fatG": .191,
			"fiberG": 2.07,
			"micronutrients": {
				"calcium": {
					"value": 8.37,
					"unit": "mg"
				},
				"iron": {
					"value": .117,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 22.4,
					"unit": "mg"
				},
				"potassium": {
					"value": 192,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .128,
					"unit": "mg"
				},
				"copper": {
					"value": .064,
					"unit": "mg"
				},
				"manganese": {
					"value": .148,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 128,
					"unit": "mg"
				},
				"niacin": {
					"value": .645,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .309,
					"unit": "mg"
				},
				"folate": {
					"value": 26,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747662/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747662,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2747663",
		"name": "Peppers, serrano, seeded, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 29.2,
			"proteinG": .856,
			"carbohydrateG": 6.14,
			"fatG": .141,
			"fiberG": 2.52,
			"micronutrients": {
				"calcium": {
					"value": 12.9,
					"unit": "mg"
				},
				"iron": {
					"value": .057,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 24.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 224,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .138,
					"unit": "mg"
				},
				"copper": {
					"value": .061,
					"unit": "mg"
				},
				"manganese": {
					"value": .129,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 94.6,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .39,
					"unit": "mg"
				},
				"folate": {
					"value": 28.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747663/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747663,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-324653",
		"name": "Pickles, cucumber, dill or kosher dill",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 12,
			"proteinG": .48,
			"carbohydrateG": 1.99,
			"fatG": .43,
			"fiberG": 1,
			"micronutrients": {
				"calcium": {
					"value": 54,
					"unit": "mg"
				},
				"iron": {
					"value": .23,
					"unit": "mg"
				},
				"magnesium": {
					"value": 7.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 16,
					"unit": "mg"
				},
				"potassium": {
					"value": 112,
					"unit": "mg"
				},
				"sodium": {
					"value": 808,
					"unit": "mg"
				},
				"zinc": {
					"value": .11,
					"unit": "mg"
				},
				"copper": {
					"value": .026,
					"unit": "mg"
				},
				"manganese": {
					"value": .056,
					"unit": "mg"
				},
				"vitaminA": {
					"value": 4,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .12,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 2.1,
					"unit": "mg"
				},
				"thiamin": {
					"value": .047,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .057,
					"unit": "mg"
				},
				"niacin": {
					"value": .109,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .034,
					"unit": "mg"
				},
				"folate": {
					"value": 8,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 16.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/324653/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 324653,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 spear",
			"weightGrams": 40.4
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2346398",
		"name": "Pineapple, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 54,
			"proteinG": .461,
			"carbohydrateG": 14.1,
			"fatG": .211,
			"fiberG": .935,
			"micronutrients": {
				"calcium": {
					"value": 12.5,
					"unit": "mg"
				},
				"iron": {
					"value": .054,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 5.42,
					"unit": "mg"
				},
				"potassium": {
					"value": 137,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .107,
					"unit": "mg"
				},
				"copper": {
					"value": .095,
					"unit": "mg"
				},
				"manganese": {
					"value": .866,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 58.6,
					"unit": "mg"
				},
				"thiamin": {
					"value": .064,
					"unit": "mg"
				},
				"niacin": {
					"value": .228,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .11,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346398/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346398,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710843",
		"name": "Plantains, overripe, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 117,
			"proteinG": 1.17,
			"carbohydrateG": 29.2,
			"fatG": .99,
			"fiberG": 1.79,
			"micronutrients": {
				"calcium": {
					"value": 3.9,
					"unit": "mg"
				},
				"iron": {
					"value": .315,
					"unit": "mg"
				},
				"magnesium": {
					"value": 31.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 28.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 408,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .149,
					"unit": "mg"
				},
				"copper": {
					"value": .103,
					"unit": "mg"
				},
				"manganese": {
					"value": .211,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 19.1,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .102,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .196,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710843/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710843,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710817",
		"name": "Plantains, ripe, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 123,
			"proteinG": 1.16,
			"carbohydrateG": 31,
			"fatG": .893,
			"fiberG": 2.12,
			"micronutrients": {
				"calcium": {
					"value": 3.82,
					"unit": "mg"
				},
				"iron": {
					"value": .319,
					"unit": "mg"
				},
				"magnesium": {
					"value": 33.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 30.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 396,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .147,
					"unit": "mg"
				},
				"copper": {
					"value": .1,
					"unit": "mg"
				},
				"manganese": {
					"value": .205,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 20.1,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .1,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .189,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710817/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710817,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710818",
		"name": "Plantains, underripe, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 145,
			"proteinG": 1.23,
			"carbohydrateG": 33.6,
			"fatG": .685,
			"fiberG": 2.53,
			"micronutrients": {
				"calcium": {
					"value": 4.83,
					"unit": "mg"
				},
				"iron": {
					"value": .334,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 27.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 406,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .185,
					"unit": "mg"
				},
				"copper": {
					"value": .109,
					"unit": "mg"
				},
				"manganese": {
					"value": .153,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 18.5,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .092,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .159,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710818/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710818,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710837",
		"name": "Plum, black, with skin, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 52.7,
			"proteinG": .578,
			"carbohydrateG": 13.5,
			"fatG": .282,
			"fiberG": 1.35,
			"micronutrients": {
				"calcium": {
					"value": 4.03,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 6.62,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 18.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 186,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .045,
					"unit": "mg"
				},
				"copper": {
					"value": .054,
					"unit": "mg"
				},
				"manganese": {
					"value": .04,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 1.82,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710837/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710837,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2727576",
		"name": "Pork, belly, with skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 385,
			"proteinG": 15.2,
			"carbohydrateG": -.705,
			"fatG": 35.8,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.2,
					"unit": "mg"
				},
				"iron": {
					"value": .382,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 114,
					"unit": "mg"
				},
				"potassium": {
					"value": 208,
					"unit": "mg"
				},
				"sodium": {
					"value": 49.7,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.07,
					"unit": "mg"
				},
				"copper": {
					"value": .033,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727576/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727576,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 26
		}]
	},
	{
		"id": "usda-fdc-2727575",
		"name": "Pork, chop, center cut, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 145,
			"proteinG": 22.8,
			"carbohydrateG": -.562,
			"fatG": 5.48,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.12,
					"unit": "mg"
				},
				"iron": {
					"value": .421,
					"unit": "mg"
				},
				"magnesium": {
					"value": 23.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 202,
					"unit": "mg"
				},
				"potassium": {
					"value": 366,
					"unit": "mg"
				},
				"sodium": {
					"value": 39.3,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.32,
					"unit": "mg"
				},
				"copper": {
					"value": .034,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727575/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727575,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-749420",
		"name": "Pork, cured, bacon, cooked, restaurant",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 500,
			"proteinG": 40.9,
			"carbohydrateG": 2.1,
			"fatG": 36.5,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 13,
					"unit": "mg"
				},
				"iron": {
					"value": 1.28,
					"unit": "mg"
				},
				"magnesium": {
					"value": 36.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 415,
					"unit": "mg"
				},
				"potassium": {
					"value": 557,
					"unit": "mg"
				},
				"sodium": {
					"value": 1830,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.56,
					"unit": "mg"
				},
				"copper": {
					"value": .13,
					"unit": "mg"
				},
				"manganese": {
					"value": .02,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/749420/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 749420,
			"release": "12/16/2019"
		},
		"preparationState": "cooked"
	},
	{
		"id": "usda-fdc-2514745",
		"name": "Pork, ground, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 233,
			"proteinG": 17.8,
			"carbohydrateG": 0,
			"fatG": 17.5,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 5.86,
					"unit": "mg"
				},
				"iron": {
					"value": .788,
					"unit": "mg"
				},
				"magnesium": {
					"value": 19,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 173,
					"unit": "mg"
				},
				"potassium": {
					"value": 318,
					"unit": "mg"
				},
				"sodium": {
					"value": 53.6,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.23,
					"unit": "mg"
				},
				"copper": {
					"value": .067,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2514745/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2514745,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-2646168",
		"name": "Pork, loin, boneless, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 174,
			"proteinG": 21.1,
			"carbohydrateG": 0,
			"fatG": 9.47,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.11,
					"unit": "mg"
				},
				"iron": {
					"value": .452,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 197,
					"unit": "mg"
				},
				"potassium": {
					"value": 361,
					"unit": "mg"
				},
				"sodium": {
					"value": 40.2,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.57,
					"unit": "mg"
				},
				"copper": {
					"value": .038,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2646168/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2646168,
			"release": "10/26/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-2646169",
		"name": "Pork, loin, tenderloin, boneless, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 125,
			"proteinG": 21.6,
			"carbohydrateG": 0,
			"fatG": 3.9,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 4.53,
					"unit": "mg"
				},
				"iron": {
					"value": .929,
					"unit": "mg"
				},
				"magnesium": {
					"value": 24.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 217,
					"unit": "mg"
				},
				"potassium": {
					"value": 397,
					"unit": "mg"
				},
				"sodium": {
					"value": 41.4,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.77,
					"unit": "mg"
				},
				"copper": {
					"value": .077,
					"unit": "mg"
				},
				"manganese": {
					"value": .003,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2646169/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2646169,
			"release": "10/26/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-2346403",
		"name": "Potatoes, gold, without skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 71.6,
			"proteinG": 1.81,
			"carbohydrateG": 16,
			"fatG": .264,
			"fiberG": 13.8,
			"micronutrients": {
				"calcium": {
					"value": 5.94,
					"unit": "mg"
				},
				"iron": {
					"value": .373,
					"unit": "mg"
				},
				"magnesium": {
					"value": 22.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 57,
					"unit": "mg"
				},
				"potassium": {
					"value": 446,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.24,
					"unit": "mg"
				},
				"zinc": {
					"value": .374,
					"unit": "mg"
				},
				"copper": {
					"value": .13,
					"unit": "mg"
				},
				"manganese": {
					"value": .16,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 23.3,
					"unit": "mg"
				},
				"thiamin": {
					"value": .051,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.58,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .145,
					"unit": "mg"
				},
				"vitaminK": {
					"value": .8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346403/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346403,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-2346402",
		"name": "Potatoes, red, without skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 73.4,
			"proteinG": 2.06,
			"carbohydrateG": 16.3,
			"fatG": .248,
			"fiberG": 13.8,
			"micronutrients": {
				"calcium": {
					"value": 5.13,
					"unit": "mg"
				},
				"iron": {
					"value": .391,
					"unit": "mg"
				},
				"magnesium": {
					"value": 23.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 55.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 472,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.86,
					"unit": "mg"
				},
				"zinc": {
					"value": .392,
					"unit": "mg"
				},
				"copper": {
					"value": .091,
					"unit": "mg"
				},
				"manganese": {
					"value": .165,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 21.3,
					"unit": "mg"
				},
				"thiamin": {
					"value": .066,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.48,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .144,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 1.1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346402/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346402,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-2346401",
		"name": "Potatoes, russet, without skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 81,
			"proteinG": 2.27,
			"carbohydrateG": 17.8,
			"fatG": .36,
			"fiberG": 14.9,
			"micronutrients": {
				"calcium": {
					"value": 7.8,
					"unit": "mg"
				},
				"iron": {
					"value": .384,
					"unit": "mg"
				},
				"magnesium": {
					"value": 25.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 55.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 450,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.74,
					"unit": "mg"
				},
				"zinc": {
					"value": .378,
					"unit": "mg"
				},
				"copper": {
					"value": .091,
					"unit": "mg"
				},
				"manganese": {
					"value": .152,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 10.9,
					"unit": "mg"
				},
				"thiamin": {
					"value": .074,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.5,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .157,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 1.5,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346401/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346401,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-2747664",
		"name": "Radicchio, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 26.4,
			"proteinG": 1.31,
			"carbohydrateG": 4.96,
			"fatG": .143,
			"fiberG": 2.11,
			"micronutrients": {
				"calcium": {
					"value": 30.9,
					"unit": "mg"
				},
				"iron": {
					"value": .401,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 35.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 335,
					"unit": "mg"
				},
				"sodium": {
					"value": 8.08,
					"unit": "mg"
				},
				"zinc": {
					"value": .2,
					"unit": "mg"
				},
				"copper": {
					"value": .059,
					"unit": "mg"
				},
				"manganese": {
					"value": .301,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 6.18,
					"unit": "mg"
				},
				"folate": {
					"value": 117,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747664/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747664,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2747665",
		"name": "Radishes, red, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 19.6,
			"proteinG": .656,
			"carbohydrateG": 4.06,
			"fatG": .083,
			"fiberG": 1.31,
			"micronutrients": {
				"calcium": {
					"value": 21.5,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.94,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 17.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 198,
					"unit": "mg"
				},
				"sodium": {
					"value": 51.2,
					"unit": "mg"
				},
				"zinc": {
					"value": .104,
					"unit": "mg"
				},
				"copper": {
					"value": .002,
					"unit": "mg"
				},
				"manganese": {
					"value": .07,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 17.8,
					"unit": "mg"
				},
				"folate": {
					"value": 63.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747665/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747665,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2346410",
		"name": "Raspberries, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 51.4,
			"proteinG": 1.01,
			"carbohydrateG": 12.9,
			"fatG": .188,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 16.4,
					"unit": "mg"
				},
				"iron": {
					"value": .45,
					"unit": "mg"
				},
				"magnesium": {
					"value": 19.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 27.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 156,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .221,
					"unit": "mg"
				},
				"copper": {
					"value": .053,
					"unit": "mg"
				},
				"manganese": {
					"value": .494,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 23,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346410/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346410,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-334536",
		"name": "Restaurant, Chinese, fried rice, without meat",
		"cuisine": "Unspecified",
		"category": "dish",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 174,
			"proteinG": 3.84,
			"carbohydrateG": 32.5,
			"fatG": 3.19,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 11,
					"unit": "mg"
				},
				"iron": {
					"value": .46,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 44,
					"unit": "mg"
				},
				"potassium": {
					"value": 69,
					"unit": "mg"
				},
				"sodium": {
					"value": 361,
					"unit": "mg"
				},
				"zinc": {
					"value": .69,
					"unit": "mg"
				},
				"copper": {
					"value": .086,
					"unit": "mg"
				},
				"manganese": {
					"value": .428,
					"unit": "mg"
				},
				"vitaminA": {
					"value": 22,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/334536/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 334536,
			"release": "4/1/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 133
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-746774",
		"name": "Restaurant, Chinese, sweet and sour pork",
		"cuisine": "Unspecified",
		"category": "dish",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 260,
			"proteinG": 8.88,
			"carbohydrateG": 25.5,
			"fatG": 13.6,
			"fiberG": 1,
			"micronutrients": {
				"calcium": {
					"value": 46,
					"unit": "mg"
				},
				"iron": {
					"value": 3.07,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 133,
					"unit": "mg"
				},
				"potassium": {
					"value": 152,
					"unit": "mg"
				},
				"sodium": {
					"value": 304,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.07,
					"unit": "mg"
				},
				"copper": {
					"value": .06,
					"unit": "mg"
				},
				"manganese": {
					"value": .173,
					"unit": "mg"
				},
				"selenium": {
					"value": 9.7,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 29,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .89,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 2.3,
					"unit": "mg"
				},
				"thiamin": {
					"value": .235,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .103,
					"unit": "mg"
				},
				"niacin": {
					"value": 2.11,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .17,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": .19,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 27.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746774/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746774,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 order",
				"weightGrams": 611
			},
			{
				"quantity": 3,
				"unit": "serving",
				"description": "3 pieces",
				"weightGrams": 41.8
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 195
			}
		]
	},
	{
		"id": "usda-fdc-334720",
		"name": "Restaurant, Latino, pupusas con frijoles (pupusas, bean)",
		"cuisine": "Unspecified",
		"category": "dish",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 229,
			"proteinG": 5.59,
			"carbohydrateG": 31.5,
			"fatG": 9.01,
			"fiberG": 5.8,
			"micronutrients": {
				"calcium": {
					"value": 51,
					"unit": "mg"
				},
				"iron": {
					"value": 1.46,
					"unit": "mg"
				},
				"magnesium": {
					"value": 53.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 144,
					"unit": "mg"
				},
				"potassium": {
					"value": 305,
					"unit": "mg"
				},
				"sodium": {
					"value": 305,
					"unit": "mg"
				},
				"zinc": {
					"value": .94,
					"unit": "mg"
				},
				"copper": {
					"value": .141,
					"unit": "mg"
				},
				"manganese": {
					"value": .344,
					"unit": "mg"
				},
				"selenium": {
					"value": 7,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .36,
					"unit": "mg"
				},
				"thiamin": {
					"value": .077,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .03,
					"unit": "mg"
				},
				"niacin": {
					"value": .867,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .172,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 7.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/334720/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 334720,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 piece",
			"weightGrams": 126
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-334628",
		"name": "Restaurant, Latino, tamale, pork",
		"cuisine": "Unspecified",
		"category": "dish",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 174,
			"proteinG": 7.38,
			"carbohydrateG": 15.8,
			"fatG": 9.04,
			"fiberG": 2.4,
			"micronutrients": {
				"calcium": {
					"value": 75,
					"unit": "mg"
				},
				"iron": {
					"value": .87,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 120,
					"unit": "mg"
				},
				"potassium": {
					"value": 152,
					"unit": "mg"
				},
				"sodium": {
					"value": 473,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.2,
					"unit": "mg"
				},
				"copper": {
					"value": .05,
					"unit": "mg"
				},
				"manganese": {
					"value": .186,
					"unit": "mg"
				},
				"selenium": {
					"value": 9.8,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 12,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .53,
					"unit": "mg"
				},
				"thiamin": {
					"value": .04,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .05,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.29,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .132,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": .12,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 5.1,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/334628/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 334628,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 piece",
			"weightGrams": 142
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-2710825",
		"name": "Rice, black, unenriched, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 361,
			"proteinG": 7.57,
			"carbohydrateG": 77.2,
			"fatG": 3.44,
			"fiberG": 4.18,
			"micronutrients": {
				"calcium": {
					"value": 14.4,
					"unit": "mg"
				},
				"iron": {
					"value": 1.12,
					"unit": "mg"
				},
				"magnesium": {
					"value": 113,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 307,
					"unit": "mg"
				},
				"potassium": {
					"value": 256,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.72,
					"unit": "mg"
				},
				"copper": {
					"value": .21,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.91,
					"unit": "mg"
				},
				"thiamin": {
					"value": .319,
					"unit": "mg"
				},
				"niacin": {
					"value": 8.28,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .202,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710825/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710825,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2512380",
		"name": "Rice, brown, long grain, unenriched, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 368,
			"proteinG": 7.25,
			"carbohydrateG": 76.7,
			"fatG": 3.31,
			"fiberG": 3.02,
			"micronutrients": {
				"calcium": {
					"value": 8.06,
					"unit": "mg"
				},
				"iron": {
					"value": 1.24,
					"unit": "mg"
				},
				"magnesium": {
					"value": 115,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 303,
					"unit": "mg"
				},
				"potassium": {
					"value": 250,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.85,
					"unit": "mg"
				},
				"copper": {
					"value": .266,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.7,
					"unit": "mg"
				},
				"selenium": {
					"value": 14.8,
					"unit": "µg"
				},
				"thiamin": {
					"value": .326,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .102,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.27,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .161,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512380/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512380,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2710838",
		"name": "Rice, red, unenriched, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 360,
			"proteinG": 8.56,
			"carbohydrateG": 76.2,
			"fatG": 3.44,
			"fiberG": 4.2,
			"micronutrients": {
				"calcium": {
					"value": 9.22,
					"unit": "mg"
				},
				"iron": {
					"value": 1.2,
					"unit": "mg"
				},
				"magnesium": {
					"value": 126,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 314,
					"unit": "mg"
				},
				"potassium": {
					"value": 245,
					"unit": "mg"
				},
				"sodium": {
					"value": .438,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.56,
					"unit": "mg"
				},
				"copper": {
					"value": .269,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.63,
					"unit": "mg"
				},
				"thiamin": {
					"value": .339,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.68,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .137,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710838/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710838,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2512381",
		"name": "Rice, white, long grain, unenriched, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 370,
			"proteinG": 7.04,
			"carbohydrateG": 80.3,
			"fatG": 1.03,
			"fiberG": .149,
			"micronutrients": {
				"calcium": {
					"value": 4.46,
					"unit": "mg"
				},
				"iron": {
					"value": .14,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 108,
					"unit": "mg"
				},
				"potassium": {
					"value": 82.3,
					"unit": "mg"
				},
				"sodium": {
					"value": .462,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.35,
					"unit": "mg"
				},
				"copper": {
					"value": .214,
					"unit": "mg"
				},
				"manganese": {
					"value": .981,
					"unit": "mg"
				},
				"selenium": {
					"value": 6.6,
					"unit": "µg"
				},
				"thiamin": {
					"value": .065,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .08,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.43,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .058,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2512381/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2512381,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2727580",
		"name": "Rutabaga, peeled, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": .888,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 2.9,
			"micronutrients": {
				"calcium": {
					"value": 42,
					"unit": "mg"
				},
				"iron": {
					"value": .137,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 38.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 267,
					"unit": "mg"
				},
				"sodium": {
					"value": 4.59,
					"unit": "mg"
				},
				"zinc": {
					"value": .211,
					"unit": "mg"
				},
				"copper": {
					"value": .024,
					"unit": "mg"
				},
				"manganese": {
					"value": .078,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .199,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727580/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727580,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-746775",
		"name": "Salt, table, iodized",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": null,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 50,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 0,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 0,
					"unit": "mg"
				},
				"potassium": {
					"value": 2,
					"unit": "mg"
				},
				"sodium": {
					"value": 38700,
					"unit": "mg"
				},
				"zinc": {
					"value": 0,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .032,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746775/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746775,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 tsp",
			"weightGrams": 6.1
		}]
	},
	{
		"id": "usda-fdc-332282",
		"name": "Sauce, pasta, spaghetti/marinara, ready-to-serve",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 45,
			"proteinG": 1.41,
			"carbohydrateG": 8.05,
			"fatG": 1.48,
			"fiberG": 1.8,
			"micronutrients": {
				"calcium": {
					"value": 27,
					"unit": "mg"
				},
				"iron": {
					"value": .78,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 34,
					"unit": "mg"
				},
				"potassium": {
					"value": 319,
					"unit": "mg"
				},
				"sodium": {
					"value": 419,
					"unit": "mg"
				},
				"zinc": {
					"value": .2,
					"unit": "mg"
				},
				"copper": {
					"value": .081,
					"unit": "mg"
				},
				"manganese": {
					"value": .137,
					"unit": "mg"
				},
				"vitaminA": {
					"value": 32,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/332282/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 332282,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-746777",
		"name": "Sauce, salsa, ready-to-serve",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 29,
			"proteinG": 1.44,
			"carbohydrateG": 6.74,
			"fatG": .19,
			"fiberG": 1.8,
			"micronutrients": {
				"calcium": {
					"value": 28,
					"unit": "mg"
				},
				"iron": {
					"value": .42,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 32,
					"unit": "mg"
				},
				"potassium": {
					"value": 258,
					"unit": "mg"
				},
				"sodium": {
					"value": 656,
					"unit": "mg"
				},
				"zinc": {
					"value": .2,
					"unit": "mg"
				},
				"copper": {
					"value": .065,
					"unit": "mg"
				},
				"manganese": {
					"value": .11,
					"unit": "mg"
				},
				"vitaminA": {
					"value": 24,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 1.22,
					"unit": "mg"
				},
				"thiamin": {
					"value": .035,
					"unit": "mg"
				},
				"niacin": {
					"value": 1.12,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .176,
					"unit": "mg"
				},
				"vitaminK": {
					"value": 4.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746777/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746777,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 2,
			"unit": "serving",
			"description": "2 tbsp",
			"weightGrams": 35.7
		}]
	},
	{
		"id": "usda-fdc-746779",
		"name": "Sausage, breakfast sausage, beef, pre-cooked, unprepared",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 328,
			"proteinG": 13.3,
			"carbohydrateG": 3.37,
			"fatG": 28.7,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 35,
					"unit": "mg"
				},
				"iron": {
					"value": 1.55,
					"unit": "mg"
				},
				"magnesium": {
					"value": 19.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 124,
					"unit": "mg"
				},
				"potassium": {
					"value": 263,
					"unit": "mg"
				},
				"sodium": {
					"value": 866,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.14,
					"unit": "mg"
				},
				"copper": {
					"value": .075,
					"unit": "mg"
				},
				"manganese": {
					"value": .174,
					"unit": "mg"
				},
				"selenium": {
					"value": 11.6,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 18,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .33,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 19.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": .054,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .132,
					"unit": "mg"
				},
				"niacin": {
					"value": 2.43,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .15,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.13,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746779/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746779,
			"release": "12/16/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 link",
			"weightGrams": 18.6
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-746780",
		"name": "Sausage, Italian, pork, mild, cooked, pan-fried",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 322,
			"proteinG": 18.2,
			"carbohydrateG": 2.15,
			"fatG": 26.2,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 12,
					"unit": "mg"
				},
				"iron": {
					"value": 1.29,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 145,
					"unit": "mg"
				},
				"potassium": {
					"value": 310,
					"unit": "mg"
				},
				"sodium": {
					"value": 766,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.41,
					"unit": "mg"
				},
				"copper": {
					"value": .074,
					"unit": "mg"
				},
				"manganese": {
					"value": .033,
					"unit": "mg"
				},
				"selenium": {
					"value": 20.2,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 22,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .8,
					"unit": "mg"
				},
				"thiamin": {
					"value": .31,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .242,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.73,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .343,
					"unit": "mg"
				},
				"folate": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.06,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746780/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746780,
			"release": "12/16/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 medium link",
			"weightGrams": 86.6
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-746781",
		"name": "Sausage, pork, chorizo, link or ground, cooked, pan-fried",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 346,
			"proteinG": 19.3,
			"carbohydrateG": 2.63,
			"fatG": 28.1,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 37,
					"unit": "mg"
				},
				"iron": {
					"value": 2.34,
					"unit": "mg"
				},
				"magnesium": {
					"value": 30.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 207,
					"unit": "mg"
				},
				"potassium": {
					"value": 435,
					"unit": "mg"
				},
				"sodium": {
					"value": 983,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.19,
					"unit": "mg"
				},
				"copper": {
					"value": .13,
					"unit": "mg"
				},
				"manganese": {
					"value": .188,
					"unit": "mg"
				},
				"selenium": {
					"value": 25.9,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 1.5,
					"unit": "mg"
				},
				"thiamin": {
					"value": .365,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .42,
					"unit": "mg"
				},
				"niacin": {
					"value": 7.06,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .554,
					"unit": "mg"
				},
				"folate": {
					"value": 10,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.21,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 6,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746781/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746781,
			"release": "12/16/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 long link",
				"weightGrams": 186
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 ground cup",
				"weightGrams": 185
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 medium link",
				"weightGrams": 80.4
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 85
			}
		]
	},
	{
		"id": "usda-fdc-746783",
		"name": "Sausage, turkey, breakfast links, mild, raw",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 169,
			"proteinG": 16.7,
			"carbohydrateG": .93,
			"fatG": 10.4,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 32,
					"unit": "mg"
				},
				"iron": {
					"value": 1.17,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 178,
					"unit": "mg"
				},
				"potassium": {
					"value": 310,
					"unit": "mg"
				},
				"sodium": {
					"value": 599,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.58,
					"unit": "mg"
				},
				"copper": {
					"value": .07,
					"unit": "mg"
				},
				"manganese": {
					"value": .035,
					"unit": "mg"
				},
				"selenium": {
					"value": 12.5,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .24,
					"unit": "mg"
				},
				"thiamin": {
					"value": .047,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .296,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.02,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .335,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.2,
					"unit": "µg"
				},
				"vitaminK": {
					"value": .4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746783/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746783,
			"release": "12/16/2019"
		},
		"preparationState": "raw",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 package",
				"weightGrams": 450
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 link",
				"weightGrams": 27.9
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 110
			}
		]
	},
	{
		"id": "usda-fdc-2747666",
		"name": "Scallops, bay, Patagonian, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 78.5,
			"proteinG": 16.4,
			"carbohydrateG": 2.28,
			"fatG": .419,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 14,
					"unit": "mg"
				},
				"iron": {
					"value": .172,
					"unit": "mg"
				},
				"magnesium": {
					"value": 46.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 229,
					"unit": "mg"
				},
				"potassium": {
					"value": 292,
					"unit": "mg"
				},
				"sodium": {
					"value": 252,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.02,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": .003,
					"unit": "mg"
				},
				"selenium": {
					"value": 28.4,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .67,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747666/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747666,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2747667",
		"name": "Scallops, sea, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 66.4,
			"proteinG": 13.5,
			"carbohydrateG": 1.97,
			"fatG": .493,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 10.5,
					"unit": "mg"
				},
				"iron": {
					"value": .213,
					"unit": "mg"
				},
				"magnesium": {
					"value": 30.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 214,
					"unit": "mg"
				},
				"potassium": {
					"value": 245,
					"unit": "mg"
				},
				"sodium": {
					"value": 313,
					"unit": "mg"
				},
				"zinc": {
					"value": 1,
					"unit": "mg"
				},
				"copper": {
					"value": .004,
					"unit": "mg"
				},
				"manganese": {
					"value": .006,
					"unit": "mg"
				},
				"selenium": {
					"value": 15.7,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.28,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747667/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747667,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2747668",
		"name": "Sea bass, Chilean, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 209,
			"proteinG": 14.9,
			"carbohydrateG": .139,
			"fatG": 16.6,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 6.82,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 16.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 152,
					"unit": "mg"
				},
				"potassium": {
					"value": 236,
					"unit": "mg"
				},
				"sodium": {
					"value": 109,
					"unit": "mg"
				},
				"zinc": {
					"value": .295,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 69.4,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .588,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747668/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747668,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2515380",
		"name": "Seeds, pumpkin seeds (pepitas), raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 515,
			"proteinG": 29.9,
			"carbohydrateG": 18.7,
			"fatG": 40,
			"fiberG": 5.08,
			"micronutrients": {
				"calcium": {
					"value": 37.4,
					"unit": "mg"
				},
				"iron": {
					"value": 8.36,
					"unit": "mg"
				},
				"magnesium": {
					"value": 500,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 1150,
					"unit": "mg"
				},
				"potassium": {
					"value": 691,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 6.34,
					"unit": "mg"
				},
				"copper": {
					"value": 1.22,
					"unit": "mg"
				},
				"manganese": {
					"value": 4.12,
					"unit": "mg"
				},
				"selenium": {
					"value": 20.5,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515380/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515380,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-325524",
		"name": "Seeds, sunflower seed kernels, dry roasted, with salt added",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 612,
			"proteinG": 21,
			"carbohydrateG": 17.1,
			"fatG": 56.1,
			"fiberG": 10.3,
			"micronutrients": {
				"calcium": {
					"value": 78,
					"unit": "mg"
				},
				"iron": {
					"value": 5.21,
					"unit": "mg"
				},
				"magnesium": {
					"value": 358,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 750,
					"unit": "mg"
				},
				"potassium": {
					"value": 689,
					"unit": "mg"
				},
				"sodium": {
					"value": 532,
					"unit": "mg"
				},
				"zinc": {
					"value": 6,
					"unit": "mg"
				},
				"copper": {
					"value": 1.83,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.89,
					"unit": "mg"
				},
				"selenium": {
					"value": 80.4,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 1,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 19.6,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .473,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .507,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.96,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .76,
					"unit": "mg"
				},
				"folate": {
					"value": 169,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 1.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/325524/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 325524,
			"release": "4/1/2019"
		},
		"preparationState": "cooked",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 127
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2515381",
		"name": "Seeds, sunflower seed, kernel, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 571,
			"proteinG": 18.9,
			"carbohydrateG": 24.5,
			"fatG": 48.4,
			"fiberG": 7.22,
			"micronutrients": {
				"calcium": {
					"value": 116,
					"unit": "mg"
				},
				"iron": {
					"value": 4.37,
					"unit": "mg"
				},
				"magnesium": {
					"value": 302,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 732,
					"unit": "mg"
				},
				"potassium": {
					"value": 657,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.58,
					"unit": "mg"
				},
				"copper": {
					"value": 1.88,
					"unit": "mg"
				},
				"manganese": {
					"value": 2.63,
					"unit": "mg"
				},
				"selenium": {
					"value": 17.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2515381/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2515381,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2262073",
		"name": "Sesame butter, creamy",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 648,
			"proteinG": 19.7,
			"carbohydrateG": 14.2,
			"fatG": 62.4,
			"fiberG": 8.37,
			"micronutrients": {
				"calcium": {
					"value": 116,
					"unit": "mg"
				},
				"iron": {
					"value": 7,
					"unit": "mg"
				},
				"magnesium": {
					"value": 357,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 719,
					"unit": "mg"
				},
				"potassium": {
					"value": 408,
					"unit": "mg"
				},
				"sodium": {
					"value": 63.6,
					"unit": "mg"
				},
				"zinc": {
					"value": 6.04,
					"unit": "mg"
				},
				"copper": {
					"value": 1.65,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.61,
					"unit": "mg"
				},
				"selenium": {
					"value": 46.5,
					"unit": "µg"
				},
				"vitaminE": {
					"value": 0,
					"unit": "mg"
				},
				"thiamin": {
					"value": .993,
					"unit": "mg"
				},
				"niacin": {
					"value": 5.81,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .595,
					"unit": "mg"
				},
				"folate": {
					"value": 108,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 1.71,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2262073/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2262073,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2727586",
		"name": "Shallots, bulb, peeled, root removed, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 1.38,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 2.2,
			"micronutrients": {
				"calcium": {
					"value": 26.1,
					"unit": "mg"
				},
				"iron": {
					"value": .332,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 54.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 252,
					"unit": "mg"
				},
				"sodium": {
					"value": 3.64,
					"unit": "mg"
				},
				"zinc": {
					"value": .282,
					"unit": "mg"
				},
				"copper": {
					"value": .08,
					"unit": "mg"
				},
				"manganese": {
					"value": .146,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .177,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727586/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727586,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2747669",
		"name": "Snapper, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 89.5,
			"proteinG": 20.7,
			"carbohydrateG": .441,
			"fatG": .569,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 13.9,
					"unit": "mg"
				},
				"iron": {
					"value": .201,
					"unit": "mg"
				},
				"magnesium": {
					"value": 27.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 199,
					"unit": "mg"
				},
				"potassium": {
					"value": 349,
					"unit": "mg"
				},
				"sodium": {
					"value": 93.1,
					"unit": "mg"
				},
				"zinc": {
					"value": .364,
					"unit": "mg"
				},
				"copper": {
					"value": .019,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 71.4,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.57,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747669/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747669,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2747670",
		"name": "Snow crab, legs only, frozen",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 69.2,
			"proteinG": 15.5,
			"carbohydrateG": 1.11,
			"fatG": .294,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 97.8,
					"unit": "mg"
				},
				"iron": {
					"value": .276,
					"unit": "mg"
				},
				"magnesium": {
					"value": 58.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 162,
					"unit": "mg"
				},
				"potassium": {
					"value": 193,
					"unit": "mg"
				},
				"sodium": {
					"value": 728,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.37,
					"unit": "mg"
				},
				"copper": {
					"value": .609,
					"unit": "mg"
				},
				"manganese": {
					"value": .021,
					"unit": "mg"
				},
				"selenium": {
					"value": 60,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 2.22,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747670/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747670,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2710839",
		"name": "Sorghum bran, white, unenriched, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 365,
			"proteinG": 11.2,
			"carbohydrateG": 68.7,
			"fatG": 9.26,
			"fiberG": 35,
			"micronutrients": {
				"calcium": {
					"value": 61.7,
					"unit": "mg"
				},
				"iron": {
					"value": 14.2,
					"unit": "mg"
				},
				"magnesium": {
					"value": 274,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 517,
					"unit": "mg"
				},
				"potassium": {
					"value": 852,
					"unit": "mg"
				},
				"sodium": {
					"value": 2.92,
					"unit": "mg"
				},
				"zinc": {
					"value": 4.4,
					"unit": "mg"
				},
				"copper": {
					"value": .841,
					"unit": "mg"
				},
				"manganese": {
					"value": 3.81,
					"unit": "mg"
				},
				"thiamin": {
					"value": .556,
					"unit": "mg"
				},
				"niacin": {
					"value": 24.6,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .408,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710839/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710839,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2710840",
		"name": "Sorghum flour, white, pearled, unenriched, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 350,
			"proteinG": 10.2,
			"carbohydrateG": 73.5,
			"fatG": 3.24,
			"fiberG": 3.3,
			"micronutrients": {
				"calcium": {
					"value": 7.89,
					"unit": "mg"
				},
				"iron": {
					"value": 2.22,
					"unit": "mg"
				},
				"magnesium": {
					"value": 107,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 246,
					"unit": "mg"
				},
				"potassium": {
					"value": 274,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.32,
					"unit": "mg"
				},
				"copper": {
					"value": .214,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.18,
					"unit": "mg"
				},
				"thiamin": {
					"value": .394,
					"unit": "mg"
				},
				"niacin": {
					"value": 2.85,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .133,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710840/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710840,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2710841",
		"name": "Sorghum grain, white, pearled, unenriched, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 338,
			"proteinG": 10.2,
			"carbohydrateG": 74.9,
			"fatG": 3.26,
			"fiberG": 3.92,
			"micronutrients": {
				"calcium": {
					"value": 7.45,
					"unit": "mg"
				},
				"iron": {
					"value": 2.04,
					"unit": "mg"
				},
				"magnesium": {
					"value": 109,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 243,
					"unit": "mg"
				},
				"potassium": {
					"value": 274,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.28,
					"unit": "mg"
				},
				"copper": {
					"value": .208,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.18,
					"unit": "mg"
				},
				"thiamin": {
					"value": .416,
					"unit": "mg"
				},
				"niacin": {
					"value": 2.65,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .144,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710841/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710841,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2710842",
		"name": "Sorghum, whole grain, white, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 341,
			"proteinG": 10.1,
			"carbohydrateG": 73.6,
			"fatG": 4.22,
			"fiberG": 8.27,
			"micronutrients": {
				"calcium": {
					"value": 14.9,
					"unit": "mg"
				},
				"iron": {
					"value": 3.9,
					"unit": "mg"
				},
				"magnesium": {
					"value": 136,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 294,
					"unit": "mg"
				},
				"potassium": {
					"value": 367,
					"unit": "mg"
				},
				"sodium": {
					"value": .329,
					"unit": "mg"
				},
				"zinc": {
					"value": 1.77,
					"unit": "mg"
				},
				"copper": {
					"value": .3,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.54,
					"unit": "mg"
				},
				"thiamin": {
					"value": .45,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.1,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .191,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710842/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710842,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-2257044",
		"name": "Soy milk, sweetened, plain, refrigerated",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 40.7,
			"proteinG": 2.78,
			"carbohydrateG": 3,
			"fatG": 1.96,
			"fiberG": 0,
			"micronutrients": {
				"calcium": {
					"value": 155,
					"unit": "mg"
				},
				"iron": {
					"value": .367,
					"unit": "mg"
				},
				"magnesium": {
					"value": 17.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 46,
					"unit": "mg"
				},
				"potassium": {
					"value": 118,
					"unit": "mg"
				},
				"sodium": {
					"value": 39.4,
					"unit": "mg"
				},
				"zinc": {
					"value": .264,
					"unit": "mg"
				},
				"copper": {
					"value": .096,
					"unit": "mg"
				},
				"manganese": {
					"value": .16,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 4.63,
					"unit": "µg"
				},
				"thiamin": {
					"value": .044,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .331,
					"unit": "mg"
				},
				"niacin": {
					"value": .133,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .036,
					"unit": "mg"
				},
				"folate": {
					"value": 15.8,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.33,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 2.8,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2257044/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2257044,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-1999630",
		"name": "Soy milk, unsweetened, plain, shelf stable",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 38.5,
			"proteinG": 3.55,
			"carbohydrateG": 1.29,
			"fatG": 2.12,
			"fiberG": 0,
			"micronutrients": {
				"calcium": {
					"value": 101,
					"unit": "mg"
				},
				"iron": {
					"value": .542,
					"unit": "mg"
				},
				"magnesium": {
					"value": 21.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 68.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 158,
					"unit": "mg"
				},
				"sodium": {
					"value": 34.3,
					"unit": "mg"
				},
				"zinc": {
					"value": .312,
					"unit": "mg"
				},
				"copper": {
					"value": .108,
					"unit": "mg"
				},
				"manganese": {
					"value": .208,
					"unit": "mg"
				},
				"selenium": {
					"value": 1.94,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 58.2,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .156,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .681,
					"unit": "µg"
				},
				"thiamin": {
					"value": .063,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .084,
					"unit": "mg"
				},
				"niacin": {
					"value": .236,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .055,
					"unit": "mg"
				},
				"folate": {
					"value": 19.7,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .393,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999630/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999630,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-1999632",
		"name": "Spinach, baby",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 20.7,
			"proteinG": 2.85,
			"carbohydrateG": 2.41,
			"fatG": .619,
			"fiberG": 1.56,
			"micronutrients": {
				"calcium": {
					"value": 68.4,
					"unit": "mg"
				},
				"iron": {
					"value": 1.26,
					"unit": "mg"
				},
				"magnesium": {
					"value": 92.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 39,
					"unit": "mg"
				},
				"potassium": {
					"value": 582,
					"unit": "mg"
				},
				"sodium": {
					"value": 111,
					"unit": "mg"
				},
				"zinc": {
					"value": .447,
					"unit": "mg"
				},
				"copper": {
					"value": .082,
					"unit": "mg"
				},
				"manganese": {
					"value": .488,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 283,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 26.5,
					"unit": "mg"
				},
				"thiamin": {
					"value": .077,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .194,
					"unit": "mg"
				},
				"niacin": {
					"value": .551,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .195,
					"unit": "mg"
				},
				"folate": {
					"value": 116,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999632/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999632,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-1999633",
		"name": "Spinach, mature",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 21.6,
			"proteinG": 2.91,
			"carbohydrateG": 2.64,
			"fatG": .604,
			"fiberG": 1.59,
			"micronutrients": {
				"calcium": {
					"value": 66.6,
					"unit": "mg"
				},
				"iron": {
					"value": 1.05,
					"unit": "mg"
				},
				"magnesium": {
					"value": 93,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 40.6,
					"unit": "mg"
				},
				"potassium": {
					"value": 460,
					"unit": "mg"
				},
				"sodium": {
					"value": 107,
					"unit": "mg"
				},
				"zinc": {
					"value": .423,
					"unit": "mg"
				},
				"copper": {
					"value": .079,
					"unit": "mg"
				},
				"manganese": {
					"value": .426,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 306,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 30.3,
					"unit": "mg"
				},
				"thiamin": {
					"value": .076,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .192,
					"unit": "mg"
				},
				"niacin": {
					"value": .51,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .214,
					"unit": "mg"
				},
				"folate": {
					"value": 113,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999633/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999633,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2727578",
		"name": "Squash, pie pumpkin, peeled, seeded, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": .854,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 2.3,
			"micronutrients": {
				"calcium": {
					"value": 16.4,
					"unit": "mg"
				},
				"iron": {
					"value": .063,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 22.3,
					"unit": "mg"
				},
				"potassium": {
					"value": 472,
					"unit": "mg"
				},
				"sodium": {
					"value": .312,
					"unit": "mg"
				},
				"zinc": {
					"value": .139,
					"unit": "mg"
				},
				"copper": {
					"value": .062,
					"unit": "mg"
				},
				"manganese": {
					"value": .049,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 10.1,
					"unit": "mg"
				},
				"folate": {
					"value": 31,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727578/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727578,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2727579",
		"name": "Squash, spaghetti, peeled, seeded, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": .792,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 1.4,
			"micronutrients": {
				"calcium": {
					"value": 16.6,
					"unit": "mg"
				},
				"iron": {
					"value": .031,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 17,
					"unit": "mg"
				},
				"potassium": {
					"value": 267,
					"unit": "mg"
				},
				"sodium": {
					"value": .312,
					"unit": "mg"
				},
				"zinc": {
					"value": .105,
					"unit": "mg"
				},
				"copper": {
					"value": .058,
					"unit": "mg"
				},
				"manganese": {
					"value": .091,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 5.55,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .104,
					"unit": "mg"
				},
				"folate": {
					"value": 12.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727579/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727579,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2685568",
		"name": "Squash, summer, green, zucchini, includes skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 16,
			"proteinG": .984,
			"carbohydrateG": 3.27,
			"fatG": .205,
			"fiberG": .752,
			"micronutrients": {
				"calcium": {
					"value": 20.8,
					"unit": "mg"
				},
				"iron": {
					"value": .194,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 32.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 226,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .26,
					"unit": "mg"
				},
				"copper": {
					"value": .064,
					"unit": "mg"
				},
				"manganese": {
					"value": .149,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 15,
					"unit": "mg"
				},
				"folate": {
					"value": 71,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685568/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685568,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2685569",
		"name": "Squash, summer, yellow, includes skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 19,
			"proteinG": .891,
			"carbohydrateG": 4.39,
			"fatG": .135,
			"fiberG": .956,
			"micronutrients": {
				"calcium": {
					"value": 22.7,
					"unit": "mg"
				},
				"iron": {
					"value": .137,
					"unit": "mg"
				},
				"magnesium": {
					"value": 16.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 30.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 220,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .203,
					"unit": "mg"
				},
				"copper": {
					"value": .061,
					"unit": "mg"
				},
				"manganese": {
					"value": .24,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 17,
					"unit": "mg"
				},
				"folate": {
					"value": 36,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685569/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685569,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2685571",
		"name": "Squash, winter, acorn, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 42,
			"proteinG": 1.25,
			"carbohydrateG": 10.5,
			"fatG": .182,
			"fiberG": 2.64,
			"micronutrients": {
				"calcium": {
					"value": 24.8,
					"unit": "mg"
				},
				"iron": {
					"value": .308,
					"unit": "mg"
				},
				"magnesium": {
					"value": 23.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 42,
					"unit": "mg"
				},
				"potassium": {
					"value": 332,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .294,
					"unit": "mg"
				},
				"copper": {
					"value": .087,
					"unit": "mg"
				},
				"manganese": {
					"value": .187,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 7,
					"unit": "mg"
				},
				"folate": {
					"value": 50,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685571/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685571,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2685570",
		"name": "Squash, winter, butternut, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 41.7,
			"proteinG": 1.15,
			"carbohydrateG": 10.5,
			"fatG": .168,
			"fiberG": 1.96,
			"micronutrients": {
				"calcium": {
					"value": 21.7,
					"unit": "mg"
				},
				"iron": {
					"value": .213,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 26.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 329,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .193,
					"unit": "mg"
				},
				"copper": {
					"value": .073,
					"unit": "mg"
				},
				"manganese": {
					"value": .075,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 7.6,
					"unit": "mg"
				},
				"folate": {
					"value": 55,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685570/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685570,
			"release": "4/18/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2747671",
		"name": "Squid (calamari), frozen, tubes only",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 43.9,
			"proteinG": 8.81,
			"carbohydrateG": .932,
			"fatG": .551,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 10.6,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 63.8,
					"unit": "mg"
				},
				"potassium": {
					"value": 9.48,
					"unit": "mg"
				},
				"sodium": {
					"value": 272,
					"unit": "mg"
				},
				"zinc": {
					"value": .527,
					"unit": "mg"
				},
				"copper": {
					"value": .077,
					"unit": "mg"
				},
				"manganese": {
					"value": .005,
					"unit": "mg"
				},
				"selenium": {
					"value": 20.9,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.12,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747671/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747671,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2346409",
		"name": "Strawberries, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 32.7,
			"proteinG": .641,
			"carbohydrateG": 7.96,
			"fatG": .22,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 16.9,
					"unit": "mg"
				},
				"iron": {
					"value": .255,
					"unit": "mg"
				},
				"magnesium": {
					"value": 12.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 23,
					"unit": "mg"
				},
				"potassium": {
					"value": 161,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .114,
					"unit": "mg"
				},
				"copper": {
					"value": .035,
					"unit": "mg"
				},
				"manganese": {
					"value": .368,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 59.6,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346409/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346409,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 140
		}]
	},
	{
		"id": "usda-fdc-746784",
		"name": "Sugars, granulated",
		"cuisine": "Unspecified",
		"category": "other",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 385,
			"proteinG": 0,
			"carbohydrateG": 99.6,
			"fatG": .32,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 1,
					"unit": "mg"
				},
				"iron": {
					"value": .05,
					"unit": "mg"
				},
				"magnesium": {
					"value": .3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 0,
					"unit": "mg"
				},
				"potassium": {
					"value": 2,
					"unit": "mg"
				},
				"sodium": {
					"value": 1,
					"unit": "mg"
				},
				"zinc": {
					"value": .01,
					"unit": "mg"
				},
				"copper": {
					"value": .007,
					"unit": "mg"
				},
				"manganese": {
					"value": .004,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746784/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746784,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 tsp",
				"weightGrams": 4
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 cup",
				"weightGrams": 188
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 8
			}
		]
	},
	{
		"id": "usda-fdc-2346404",
		"name": "Sweet potatoes, orange flesh, without skin, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 77.4,
			"proteinG": 1.58,
			"carbohydrateG": 17.3,
			"fatG": .375,
			"fiberG": 4.44,
			"micronutrients": {
				"calcium": {
					"value": 22.3,
					"unit": "mg"
				},
				"iron": {
					"value": .398,
					"unit": "mg"
				},
				"magnesium": {
					"value": 19.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 36.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 486,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .337,
					"unit": "mg"
				},
				"copper": {
					"value": .187,
					"unit": "mg"
				},
				"manganese": {
					"value": .417,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 14.8,
					"unit": "mg"
				},
				"thiamin": {
					"value": .045,
					"unit": "mg"
				},
				"niacin": {
					"value": .432,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .124,
					"unit": "mg"
				},
				"vitaminK": {
					"value": .2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2346404/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2346404,
			"release": "10/28/2022"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 110
		}]
	},
	{
		"id": "usda-fdc-2747672",
		"name": "Swordfish, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 152,
			"proteinG": 19.2,
			"carbohydrateG": .45,
			"fatG": 8.12,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 3.62,
					"unit": "mg"
				},
				"iron": {
					"value": .096,
					"unit": "mg"
				},
				"magnesium": {
					"value": 26.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 235,
					"unit": "mg"
				},
				"potassium": {
					"value": 414,
					"unit": "mg"
				},
				"sodium": {
					"value": 56.9,
					"unit": "mg"
				},
				"zinc": {
					"value": .541,
					"unit": "mg"
				},
				"copper": {
					"value": .02,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 60.7,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .87,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747672/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747672,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2727582",
		"name": "Tomatillos, dehusked, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": 1.06,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": 1.7,
			"micronutrients": {
				"calcium": {
					"value": 7.14,
					"unit": "mg"
				},
				"iron": {
					"value": .245,
					"unit": "mg"
				},
				"magnesium": {
					"value": 13.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 24.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 239,
					"unit": "mg"
				},
				"sodium": {
					"value": .311,
					"unit": "mg"
				},
				"zinc": {
					"value": .159,
					"unit": "mg"
				},
				"copper": {
					"value": .052,
					"unit": "mg"
				},
				"manganese": {
					"value": .12,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 2.18,
					"unit": "mg"
				},
				"folate": {
					"value": 16.4,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2727582/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2727582,
			"release": "4/24/2025"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2003596",
		"name": "Tomato juice, with added ingredients, from concentrate, shelf stable",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 19.9,
			"proteinG": .859,
			"carbohydrateG": 4.32,
			"fatG": .288,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 9.74,
					"unit": "mg"
				},
				"iron": {
					"value": .299,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 18.5,
					"unit": "mg"
				},
				"potassium": {
					"value": 198,
					"unit": "mg"
				},
				"sodium": {
					"value": 236,
					"unit": "mg"
				},
				"zinc": {
					"value": .104,
					"unit": "mg"
				},
				"copper": {
					"value": .057,
					"unit": "mg"
				},
				"manganese": {
					"value": .058,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 49.8,
					"unit": "mg"
				},
				"thiamin": {
					"value": .042,
					"unit": "mg"
				},
				"niacin": {
					"value": .086,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .076,
					"unit": "mg"
				},
				"folate": {
					"value": 18.9,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2003596/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2003596,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-2685580",
		"name": "Tomato, paste, canned, without salt added",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 88.5,
			"proteinG": 4.23,
			"carbohydrateG": 20.2,
			"fatG": .732,
			"fiberG": 4.7,
			"micronutrients": {
				"calcium": {
					"value": 36.8,
					"unit": "mg"
				},
				"iron": {
					"value": 3.18,
					"unit": "mg"
				},
				"magnesium": {
					"value": 49.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 91.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 972,
					"unit": "mg"
				},
				"sodium": {
					"value": 61.2,
					"unit": "mg"
				},
				"zinc": {
					"value": .511,
					"unit": "mg"
				},
				"copper": {
					"value": .295,
					"unit": "mg"
				},
				"manganese": {
					"value": .332,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 18.4,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685580/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685580,
			"release": "4/18/2024"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 30
		}]
	},
	{
		"id": "usda-fdc-2685582",
		"name": "Tomato, puree, canned",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 34.8,
			"proteinG": 1.58,
			"carbohydrateG": 8.04,
			"fatG": .265,
			"fiberG": 1.97,
			"micronutrients": {
				"calcium": {
					"value": 17.6,
					"unit": "mg"
				},
				"iron": {
					"value": 1.24,
					"unit": "mg"
				},
				"magnesium": {
					"value": 19.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 34.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 416,
					"unit": "mg"
				},
				"sodium": {
					"value": 29.4,
					"unit": "mg"
				},
				"zinc": {
					"value": .208,
					"unit": "mg"
				},
				"copper": {
					"value": .123,
					"unit": "mg"
				},
				"manganese": {
					"value": .14,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 10.4,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685582/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685582,
			"release": "4/18/2024"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-1999634",
		"name": "Tomato, roma",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 19,
			"proteinG": .696,
			"carbohydrateG": 3.84,
			"fatG": .425,
			"fiberG": .971,
			"micronutrients": {
				"calcium": {
					"value": 9.96,
					"unit": "mg"
				},
				"iron": {
					"value": .103,
					"unit": "mg"
				},
				"magnesium": {
					"value": 8.09,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 19.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 193,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .082,
					"unit": "mg"
				},
				"copper": {
					"value": .032,
					"unit": "mg"
				},
				"manganese": {
					"value": .087,
					"unit": "mg"
				},
				"selenium": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 23.9,
					"unit": "µg"
				},
				"vitaminC": {
					"value": 17.8,
					"unit": "mg"
				},
				"thiamin": {
					"value": .056,
					"unit": "mg"
				},
				"riboflavin": {
					"value": 0,
					"unit": "mg"
				},
				"niacin": {
					"value": .533,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .079,
					"unit": "mg"
				},
				"folate": {
					"value": 9.99,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/1999634/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 1999634,
			"release": "10/28/2021"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 85
		}]
	},
	{
		"id": "usda-fdc-2685579",
		"name": "Tomato, sauce, canned, with salt added",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 29.1,
			"proteinG": 1.35,
			"carbohydrateG": 6.33,
			"fatG": .382,
			"fiberG": 1.64,
			"micronutrients": {
				"calcium": {
					"value": 17.1,
					"unit": "mg"
				},
				"iron": {
					"value": 1.11,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 29.2,
					"unit": "mg"
				},
				"potassium": {
					"value": 356,
					"unit": "mg"
				},
				"sodium": {
					"value": 417,
					"unit": "mg"
				},
				"zinc": {
					"value": .183,
					"unit": "mg"
				},
				"copper": {
					"value": .089,
					"unit": "mg"
				},
				"manganese": {
					"value": .131,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 9.2,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685579/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685579,
			"release": "4/18/2024"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-333281",
		"name": "Tomatoes, canned, red, ripe, diced",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 18,
			"proteinG": .84,
			"carbohydrateG": 3.32,
			"fatG": .5,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 30,
					"unit": "mg"
				},
				"iron": {
					"value": .57,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 18,
					"unit": "mg"
				},
				"potassium": {
					"value": 198,
					"unit": "mg"
				},
				"sodium": {
					"value": 125,
					"unit": "mg"
				},
				"zinc": {
					"value": .12,
					"unit": "mg"
				},
				"copper": {
					"value": .052,
					"unit": "mg"
				},
				"manganese": {
					"value": .068,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/333281/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 333281,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 cup",
			"weightGrams": 245
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2685581",
		"name": "Tomatoes, crushed, canned",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 32.3,
			"proteinG": 1.44,
			"carbohydrateG": 7.14,
			"fatG": .398,
			"fiberG": 1.94,
			"micronutrients": {
				"calcium": {
					"value": 19.2,
					"unit": "mg"
				},
				"iron": {
					"value": 2.27,
					"unit": "mg"
				},
				"magnesium": {
					"value": 18.6,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 32.9,
					"unit": "mg"
				},
				"potassium": {
					"value": 346,
					"unit": "mg"
				},
				"sodium": {
					"value": 140,
					"unit": "mg"
				},
				"zinc": {
					"value": .201,
					"unit": "mg"
				},
				"copper": {
					"value": .104,
					"unit": "mg"
				},
				"manganese": {
					"value": .153,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 9.1,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685581/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685581,
			"release": "4/18/2024"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-321360",
		"name": "Tomatoes, grape, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 27,
			"proteinG": .83,
			"carbohydrateG": 5.51,
			"fatG": .63,
			"fiberG": 2.1,
			"micronutrients": {
				"calcium": {
					"value": 11,
					"unit": "mg"
				},
				"iron": {
					"value": .33,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.9,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 28,
					"unit": "mg"
				},
				"potassium": {
					"value": 260,
					"unit": "mg"
				},
				"sodium": {
					"value": 6,
					"unit": "mg"
				},
				"zinc": {
					"value": .2,
					"unit": "mg"
				},
				"copper": {
					"value": .058,
					"unit": "mg"
				},
				"manganese": {
					"value": .121,
					"unit": "mg"
				},
				"vitaminE": {
					"value": .98,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 27.2,
					"unit": "mg"
				},
				"thiamin": {
					"value": .075,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .065,
					"unit": "mg"
				},
				"niacin": {
					"value": .805,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .06,
					"unit": "mg"
				},
				"folate": {
					"value": 10,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 4.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/321360/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 321360,
			"release": "4/1/2019"
		},
		"preparationState": "raw",
		"servingOptions": [
			{
				"quantity": 5,
				"unit": "serving",
				"description": "5 tomatoes",
				"weightGrams": 49.7
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 cup",
				"weightGrams": 152
			},
			{
				"quantity": 1,
				"unit": "serving",
				"description": "1 RACC",
				"weightGrams": 85
			}
		]
	},
	{
		"id": "usda-fdc-2685578",
		"name": "Tomatoes, whole, canned, solids and liquids, with salt added",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 19.1,
			"proteinG": .868,
			"carbohydrateG": 4.29,
			"fatG": .206,
			"fiberG": .872,
			"micronutrients": {
				"calcium": {
					"value": 19.8,
					"unit": "mg"
				},
				"iron": {
					"value": .929,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.8,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 17.3,
					"unit": "mg"
				},
				"potassium": {
					"value": 203,
					"unit": "mg"
				},
				"sodium": {
					"value": 112,
					"unit": "mg"
				},
				"zinc": {
					"value": .12,
					"unit": "mg"
				},
				"copper": {
					"value": .059,
					"unit": "mg"
				},
				"manganese": {
					"value": .075,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 7.7,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2685578/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2685578,
			"release": "4/18/2024"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 130
		}]
	},
	{
		"id": "usda-fdc-2747673",
		"name": "Tuna, ahi or yellowfin, frozen, wild caught",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 102,
			"proteinG": 24.7,
			"carbohydrateG": -.104,
			"fatG": .388,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 3.19,
					"unit": "mg"
				},
				"iron": {
					"value": .591,
					"unit": "mg"
				},
				"magnesium": {
					"value": 35.5,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 271,
					"unit": "mg"
				},
				"potassium": {
					"value": 420,
					"unit": "mg"
				},
				"sodium": {
					"value": 94.4,
					"unit": "mg"
				},
				"zinc": {
					"value": .352,
					"unit": "mg"
				},
				"copper": {
					"value": .03,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"selenium": {
					"value": 76.5,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": 1.37,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747673/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747673,
			"release": "12/18/2025"
		},
		"preparationState": "not-specified"
	},
	{
		"id": "usda-fdc-746785",
		"name": "Turkey, ground, 93% lean, 7% fat, pan-broiled crumbles",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 220,
			"proteinG": 27.1,
			"carbohydrateG": 0,
			"fatG": 11.6,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 31,
					"unit": "mg"
				},
				"iron": {
					"value": 1.56,
					"unit": "mg"
				},
				"magnesium": {
					"value": 29.1,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 259,
					"unit": "mg"
				},
				"potassium": {
					"value": 304,
					"unit": "mg"
				},
				"sodium": {
					"value": 90,
					"unit": "mg"
				},
				"zinc": {
					"value": 3.77,
					"unit": "mg"
				},
				"copper": {
					"value": .166,
					"unit": "mg"
				},
				"manganese": {
					"value": .01,
					"unit": "mg"
				},
				"selenium": {
					"value": 28.4,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 30,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .18,
					"unit": "mg"
				},
				"thiamin": {
					"value": .088,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .262,
					"unit": "mg"
				},
				"niacin": {
					"value": 8.09,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .497,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": 1.9,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/746785/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 746785,
			"release": "12/16/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 crumbles ckd pr g",
			"weightGrams": 155
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2514747",
		"name": "Turkey, ground, 93% lean/ 7% fat, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 158,
			"proteinG": 17.3,
			"carbohydrateG": 0,
			"fatG": 9.59,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 23.6,
					"unit": "mg"
				},
				"iron": {
					"value": 1.09,
					"unit": "mg"
				},
				"magnesium": {
					"value": 17.3,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 162,
					"unit": "mg"
				},
				"potassium": {
					"value": 246,
					"unit": "mg"
				},
				"sodium": {
					"value": 80.2,
					"unit": "mg"
				},
				"zinc": {
					"value": 2.95,
					"unit": "mg"
				},
				"copper": {
					"value": .076,
					"unit": "mg"
				},
				"manganese": {
					"value": .016,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2514747/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2514747,
			"release": "4/20/2023"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 114
		}]
	},
	{
		"id": "usda-fdc-2747674",
		"name": "Turnips, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 34,
			"proteinG": .953,
			"carbohydrateG": 7.27,
			"fatG": .119,
			"fiberG": 1.92,
			"micronutrients": {
				"calcium": {
					"value": 32.7,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 31.3,
					"unit": "mg"
				},
				"potassium": {
					"value": 262,
					"unit": "mg"
				},
				"sodium": {
					"value": 12.8,
					"unit": "mg"
				},
				"zinc": {
					"value": .156,
					"unit": "mg"
				},
				"copper": {
					"value": .022,
					"unit": "mg"
				},
				"manganese": {
					"value": .068,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 26.8,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .118,
					"unit": "mg"
				},
				"folate": {
					"value": 60.2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747674/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747674,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2747675",
		"name": "Watermelon, seedless, flesh only, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": null,
			"proteinG": .871,
			"carbohydrateG": null,
			"fatG": null,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 7.86,
					"unit": "mg"
				},
				"iron": {
					"value": .021,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 17.1,
					"unit": "mg"
				},
				"potassium": {
					"value": 117,
					"unit": "mg"
				},
				"sodium": {
					"value": 0,
					"unit": "mg"
				},
				"zinc": {
					"value": .102,
					"unit": "mg"
				},
				"copper": {
					"value": .046,
					"unit": "mg"
				},
				"manganese": {
					"value": .068,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 6.46,
					"unit": "mg"
				},
				"folate": {
					"value": 11.9,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747675/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747675,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2747676",
		"name": "Watermelon, seedless, rind only, raw",
		"cuisine": "Unspecified",
		"category": "beverage",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 19.4,
			"proteinG": .531,
			"carbohydrateG": 4.17,
			"fatG": .07,
			"fiberG": 1.54,
			"micronutrients": {
				"calcium": {
					"value": 16.9,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 9.67,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 20.7,
					"unit": "mg"
				},
				"potassium": {
					"value": 272,
					"unit": "mg"
				},
				"sodium": {
					"value": 3.76,
					"unit": "mg"
				},
				"zinc": {
					"value": .121,
					"unit": "mg"
				},
				"copper": {
					"value": .007,
					"unit": "mg"
				},
				"manganese": {
					"value": .07,
					"unit": "mg"
				},
				"vitaminC": {
					"value": 7.09,
					"unit": "mg"
				},
				"thiamin": {
					"value": .033,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .072,
					"unit": "mg"
				},
				"niacin": {
					"value": .169,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .029,
					"unit": "mg"
				},
				"folate": {
					"value": 29.7,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2747676/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2747676,
			"release": "12/18/2025"
		},
		"preparationState": "raw"
	},
	{
		"id": "usda-fdc-2710821",
		"name": "Wild rice, dry, raw",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 359,
			"proteinG": 12.8,
			"carbohydrateG": 75.7,
			"fatG": 1.7,
			"fiberG": 4.26,
			"micronutrients": {
				"calcium": {
					"value": 7.97,
					"unit": "mg"
				},
				"iron": {
					"value": 1.53,
					"unit": "mg"
				},
				"magnesium": {
					"value": 108,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 355,
					"unit": "mg"
				},
				"potassium": {
					"value": 299,
					"unit": "mg"
				},
				"sodium": {
					"value": 1.01,
					"unit": "mg"
				},
				"zinc": {
					"value": 5.84,
					"unit": "mg"
				},
				"copper": {
					"value": .487,
					"unit": "mg"
				},
				"manganese": {
					"value": 1.32,
					"unit": "mg"
				},
				"thiamin": {
					"value": .339,
					"unit": "mg"
				},
				"niacin": {
					"value": 6.91,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .393,
					"unit": "mg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2710821/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2710821,
			"release": "10/31/2024"
		},
		"preparationState": "raw",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 45
		}]
	},
	{
		"id": "usda-fdc-330137",
		"name": "Yogurt, Greek, plain, nonfat",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 61,
			"proteinG": 10.3,
			"carbohydrateG": 3.64,
			"fatG": .37,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 111,
					"unit": "mg"
				},
				"iron": {
					"value": .07,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 136,
					"unit": "mg"
				},
				"potassium": {
					"value": 141,
					"unit": "mg"
				},
				"sodium": {
					"value": 36,
					"unit": "mg"
				},
				"zinc": {
					"value": .53,
					"unit": "mg"
				},
				"copper": {
					"value": .017,
					"unit": "mg"
				},
				"manganese": {
					"value": .009,
					"unit": "mg"
				},
				"selenium": {
					"value": 9.9,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 1,
					"unit": "µg"
				},
				"vitaminE": {
					"value": .01,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .022,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .281,
					"unit": "mg"
				},
				"niacin": {
					"value": .211,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .064,
					"unit": "mg"
				},
				"vitaminB12": {
					"value": .7,
					"unit": "µg"
				},
				"vitaminK": {
					"value": 0,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/330137/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 330137,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 container",
			"weightGrams": 156
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 170
		}]
	},
	{
		"id": "usda-fdc-2259794",
		"name": "Yogurt, Greek, plain, whole milk",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 94.5,
			"proteinG": 8.78,
			"carbohydrateG": 4.75,
			"fatG": 4.39,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 111,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.7,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 126,
					"unit": "mg"
				},
				"potassium": {
					"value": 147,
					"unit": "mg"
				},
				"sodium": {
					"value": 33.8,
					"unit": "mg"
				},
				"zinc": {
					"value": .473,
					"unit": "mg"
				},
				"copper": {
					"value": .01,
					"unit": "mg"
				},
				"manganese": {
					"value": .006,
					"unit": "mg"
				},
				"vitaminD": {
					"value": 0,
					"unit": "µg"
				},
				"thiamin": {
					"value": .055,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .244,
					"unit": "mg"
				},
				"niacin": {
					"value": .227,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .044,
					"unit": "mg"
				},
				"vitaminK": {
					"value": .2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2259794/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2259794,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 170
		}]
	},
	{
		"id": "usda-fdc-330415",
		"name": "Yogurt, Greek, strawberry, nonfat",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 83,
			"proteinG": 8.06,
			"carbohydrateG": 12.2,
			"fatG": .15,
			"fiberG": .6,
			"micronutrients": {
				"calcium": {
					"value": 97,
					"unit": "mg"
				},
				"iron": {
					"value": .09,
					"unit": "mg"
				},
				"magnesium": {
					"value": 10.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 113,
					"unit": "mg"
				},
				"potassium": {
					"value": 133,
					"unit": "mg"
				},
				"sodium": {
					"value": 32,
					"unit": "mg"
				},
				"zinc": {
					"value": .46,
					"unit": "mg"
				},
				"copper": {
					"value": .02,
					"unit": "mg"
				},
				"manganese": {
					"value": .034,
					"unit": "mg"
				},
				"selenium": {
					"value": 9.8,
					"unit": "µg"
				},
				"vitaminA": {
					"value": 0,
					"unit": "µg"
				},
				"vitaminD": {
					"value": 1,
					"unit": "µg"
				},
				"vitaminC": {
					"value": .2,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .25,
					"unit": "mg"
				},
				"niacin": {
					"value": .208,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .05,
					"unit": "mg"
				},
				"folate": {
					"value": 20,
					"unit": "µg"
				},
				"vitaminB12": {
					"value": .45,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/330415/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical, Summed."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 330415,
			"release": "4/1/2019"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 5.3 oz container",
			"weightGrams": 150
		}, {
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 170
		}]
	},
	{
		"id": "usda-fdc-2647437",
		"name": "Yogurt, plain, nonfat",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 50.1,
			"proteinG": 4.23,
			"carbohydrateG": 8.08,
			"fatG": .087,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 167,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 15.2,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 127,
					"unit": "mg"
				},
				"potassium": {
					"value": 210,
					"unit": "mg"
				},
				"sodium": {
					"value": 51.5,
					"unit": "mg"
				},
				"zinc": {
					"value": .599,
					"unit": "mg"
				},
				"copper": {
					"value": 0,
					"unit": "mg"
				},
				"manganese": {
					"value": 0,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .217,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2647437/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2647437,
			"release": "10/26/2023"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 170
		}]
	},
	{
		"id": "usda-fdc-2259793",
		"name": "Yogurt, plain, whole milk",
		"cuisine": "Unspecified",
		"category": "ingredient",
		"meal": null,
		"diet": "Unspecified",
		"dietaryLabels": [],
		"allergens": null,
		"allergenDataStatus": "unknown",
		"source": "usda-fooddata-central",
		"nutrition": {
			"servingSize": {
				"quantity": 100,
				"unit": "g",
				"description": "100 g edible portion"
			},
			"basis": "per-100g",
			"caloriesKcal": 77.3,
			"proteinG": 3.82,
			"carbohydrateG": 5.57,
			"fatG": 4.48,
			"fiberG": null,
			"micronutrients": {
				"calcium": {
					"value": 127,
					"unit": "mg"
				},
				"iron": {
					"value": 0,
					"unit": "mg"
				},
				"magnesium": {
					"value": 11.4,
					"unit": "mg"
				},
				"phosphorus": {
					"value": 101,
					"unit": "mg"
				},
				"potassium": {
					"value": 164,
					"unit": "mg"
				},
				"sodium": {
					"value": 41.8,
					"unit": "mg"
				},
				"zinc": {
					"value": .428,
					"unit": "mg"
				},
				"copper": {
					"value": .003,
					"unit": "mg"
				},
				"manganese": {
					"value": .002,
					"unit": "mg"
				},
				"vitaminD": {
					"value": .778,
					"unit": "µg"
				},
				"thiamin": {
					"value": .055,
					"unit": "mg"
				},
				"riboflavin": {
					"value": .243,
					"unit": "mg"
				},
				"niacin": {
					"value": .135,
					"unit": "mg"
				},
				"vitaminB6": {
					"value": .045,
					"unit": "mg"
				},
				"vitaminK": {
					"value": .2,
					"unit": "µg"
				}
			}
		},
		"nutritionDataQuality": "estimated",
		"nutritionProvenance": {
			"sourceName": "USDA FoodData Central Foundation Foods",
			"sourceType": "database",
			"reference": "https://fdc.nal.usda.gov/food-details/2259793/nutrients",
			"note": "Foundation Foods release 2026-04-30; source values are per 100 g edible portion. Sample-based measurements vary; missing or below-quantification values remain unknown. Selected nutrient derivations: Calculated, Analytical."
		},
		"externalDataId": {
			"source": "usda-fooddata-central",
			"id": 2259793,
			"release": "4/28/2022"
		},
		"preparationState": "not-specified",
		"servingOptions": [{
			"quantity": 1,
			"unit": "serving",
			"description": "1 RACC",
			"weightGrams": 170
		}]
	}
];
var BASE_NUTRIENTS = [
	"caloriesKcal",
	"proteinG",
	"carbohydrateG",
	"fatG",
	"fiberG"
];
function gramsFor(size) {
	if (size.unit === "g") return size.quantity;
	return size.weightGrams ?? null;
}
function scaleFactor(reference, basis, selected) {
	if (!Number.isFinite(selected.quantity) || selected.quantity <= 0) return null;
	if (basis === "per-100g") {
		const grams = gramsFor(selected);
		return grams === null || !Number.isFinite(grams) || grams <= 0 ? null : grams / 100;
	}
	if (reference.unit === selected.unit) return Number.isFinite(reference.quantity) && reference.quantity > 0 ? selected.quantity / reference.quantity : null;
	const referenceGrams = gramsFor(reference);
	const selectedGrams = gramsFor(selected);
	if (referenceGrams === null || selectedGrams === null || !Number.isFinite(referenceGrams) || !Number.isFinite(selectedGrams) || referenceGrams <= 0 || selectedGrams <= 0) return null;
	return selectedGrams / referenceGrams;
}
/**
* Scales a known per-serving or per-100 g reference to a selected portion.
* Mass/volume and item conversions are never assumed: cross-unit scaling needs explicit gram weights.
*/
function calculatePortionNutrition(reference, selected) {
	const factor = scaleFactor(reference.servingSize, reference.basis, selected);
	const missingNutrients = [];
	const nutrition = {
		servingSize: selected,
		basis: "per-serving",
		caloriesKcal: null,
		proteinG: null,
		carbohydrateG: null,
		fatG: null,
		fiberG: null
	};
	for (const key of BASE_NUTRIENTS) {
		const amount = reference[key];
		if (factor === null || amount === null || !Number.isFinite(amount)) {
			missingNutrients.push(key);
			continue;
		}
		nutrition[key] = amount * factor;
	}
	if (reference.micronutrients) {
		nutrition.micronutrients = {};
		for (const [key, amount] of Object.entries(reference.micronutrients)) if (factor === null || amount.value === null || !Number.isFinite(amount.value)) {
			nutrition.micronutrients[key] = {
				value: null,
				unit: amount.unit
			};
			missingNutrients.push(`micronutrients.${key}`);
		} else nutrition.micronutrients[key] = {
			value: amount.value * factor,
			unit: amount.unit
		};
	}
	return {
		nutrition,
		completeness: BASE_NUTRIENTS.length + Object.keys(reference.micronutrients ?? {}).length - missingNutrients.length === 0 ? "unavailable" : missingNutrients.length ? "partial" : "complete",
		missingNutrients,
		...factor === null ? { note: "This portion cannot be calculated without a compatible unit or known gram weight." } : {}
	};
}
function formatNutrient(value, unit) {
	return value === null || !Number.isFinite(value) ? "Unknown" : `${Number(value.toFixed(1))}${unit}`;
}
var catalogueFoods = [...demoFoods, ...usdaFoundationFoods];
/** Explorer numeric filters/sorts compare a common 100 g basis across catalogue records. */
function getFoodNutritionPer100g(food) {
	if (food.nutrition.basis === "per-100g") return food.nutrition;
	return calculatePortionNutrition(food.nutrition, {
		quantity: 100,
		unit: "g"
	}).nutrition;
}
function isFoodAllowedForRestrictions(food, restrictions) {
	if (restrictions.dietaryLabels?.some((label) => !food.dietaryLabels.includes(label))) return false;
	const allergens = restrictions.allergens?.map((allergen) => allergen.trim().toLocaleLowerCase()).filter(Boolean) ?? [];
	if (allergens.length) {
		if (food.allergenDataStatus !== "complete" || food.allergens === null) return false;
		const knownAllergens = food.allergens.map((allergen) => allergen.toLocaleLowerCase());
		if (allergens.some((allergen) => knownAllergens.some((known) => known.includes(allergen) || allergen.includes(known)))) return false;
	}
	return true;
}
function filterFoods(foods, filters) {
	const query = filters.query?.trim().toLocaleLowerCase() ?? "";
	return foods.filter((food) => {
		const textMatches = !query || [food.name, ...food.alternativeNames ?? []].some((term) => term.toLocaleLowerCase().includes(query));
		const per100g = getFoodNutritionPer100g(food);
		const matchesNutrition = (filters.maxCalories === void 0 || per100g.caloriesKcal !== null && per100g.caloriesKcal <= filters.maxCalories) && (filters.minProtein === void 0 || per100g.proteinG !== null && per100g.proteinG >= filters.minProtein);
		return textMatches && (!filters.cuisine || filters.cuisine === "all" || food.cuisine === filters.cuisine || food.regionalOrigin === filters.cuisine) && (!filters.category || filters.category === "all" || food.category === filters.category) && (!filters.diet || filters.diet === "all" || food.dietaryLabels.includes(filters.diet)) && (!filters.meal || filters.meal === "all" || food.meal === filters.meal) && matchesNutrition && isFoodAllowedForRestrictions(food, filters.allergensToAvoid ? { allergens: filters.allergensToAvoid } : {});
	});
}
/** Frontend data boundary; replace this adapter with the FastAPI client later. */
var foodDataService = {
	getAll() {
		return catalogueFoods;
	},
	getById(id) {
		return catalogueFoods.find((food) => food.id === id);
	},
	getCuisines() {
		return [...new Set(catalogueFoods.flatMap((food) => [...food.cuisine !== "Unspecified" ? [food.cuisine] : [], ...food.regionalOrigin ? [food.regionalOrigin] : []]))].sort();
	},
	getCategories() {
		return [...new Set(catalogueFoods.map((food) => food.category))].sort();
	}
};
//#endregion
export { getFoodNutritionPer100g as a, formatNutrient as i, filterFoods as n, foodDataService as r, calculatePortionNutrition as t };
