import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as SavedFoodsProvider } from "./use-saved-foods-CT0vTAMy.mjs";
import { t as Route$15 } from "../_workspace.foods._foodId-BjUBfa0b.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-C9VlVbsA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
var styles_default = "/assets/styles-seB3FkUe.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message: describeThrown(error),
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var MAX_SERIALIZED_LENGTH = 2e3;
function describeThrown(error) {
	if (error instanceof Response) return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	const { message } = error ?? {};
	if (typeof message === "string" && message.length > 0) return message;
	try {
		return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
	} catch {
		return String(error);
	}
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$14 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "NUTRIFY — Personalized nutrition, meal planning, and daily progress" },
			{
				name: "description",
				content: "NUTRIFY helps people discover foods, plan meals, and track daily nutrition habits in a simpler, more personalized way."
			},
			{
				name: "author",
				content: "NUTRIFY"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Inter:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$14.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SavedFoodsProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, { position: "bottom-right" })] })
	});
}
var $$splitComponentImporter$13 = () => import("./routes-B9_X8uFH.mjs");
var Route$13 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "NUTRIFY — Smarter nutrition for everyday life." },
		{
			name: "description",
			content: "Personalized nutrition plans, food discovery, meal planning, and daily progress tracking for everyday wellness."
		},
		{
			property: "og:title",
			content: "NUTRIFY — Smarter nutrition for everyday life."
		},
		{
			property: "og:description",
			content: "Personalized nutrition plans, food discovery, meal planning, and daily progress tracking for everyday wellness."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("../_workspace-BFDCxN_m.mjs");
var Route$12 = createFileRoute("/_workspace")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./forgot-password-BabZRffs.mjs");
var Route$11 = createFileRoute("/forgot-password")({
	head: () => ({ meta: [
		{ title: "Reset password — NUTRIFY" },
		{
			name: "description",
			content: "Request a password reset link for your NUTRIFY account."
		},
		{
			property: "og:title",
			content: "Reset password — NUTRIFY"
		},
		{
			property: "og:description",
			content: "Request a password reset link for your NUTRIFY account."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./login-D8ZCKyzA.mjs");
var Route$10 = createFileRoute("/login")({
	head: () => ({ meta: [
		{ title: "Log in — NUTRIFY" },
		{
			name: "description",
			content: "Log in to NUTRIFY to continue your nutrition plan, meal tracking, and food discovery."
		},
		{
			property: "og:title",
			content: "Log in — NUTRIFY"
		},
		{
			property: "og:description",
			content: "Log in to NUTRIFY to continue your nutrition plan, meal tracking, and food discovery."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./register-DRhafG0P.mjs");
var Route$9 = createFileRoute("/register")({
	head: () => ({ meta: [
		{ title: "Create account — NUTRIFY" },
		{
			name: "description",
			content: "Create a NUTRIFY account to build your nutrition goals and personalized meal plan."
		},
		{
			property: "og:title",
			content: "Create account — NUTRIFY"
		},
		{
			property: "og:description",
			content: "Create a NUTRIFY account to build your nutrition goals and personalized meal plan."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var pageMeta = (title, description) => ({ meta: [
	{ title: `${title} — NUTRIFY` },
	{
		name: "description",
		content: description
	},
	{
		property: "og:title",
		content: `${title} — NUTRIFY`
	},
	{
		property: "og:description",
		content: description
	}
] });
var $$splitComponentImporter$8 = () => import("../_workspace.assessment-C-B7S-3X.mjs");
var Route$8 = createFileRoute("/_workspace/assessment")({
	head: () => pageMeta("Personal Assessment", "Share your preferences and goals to prepare a personalized nutrition plan."),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("../_workspace.dashboard-028QJkUj.mjs");
var Route$7 = createFileRoute("/_workspace/dashboard")({
	head: () => pageMeta("Daily Progress", "Your nutrition overview, goals, and progress across meals, habits, and food choices."),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("../_workspace.diary-DamSdvyF.mjs");
var Route$6 = createFileRoute("/_workspace/diary")({
	head: () => pageMeta("Food Diary", "Log foods by meal and review daily nutrition totals."),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("../_workspace.explorer-_zL0h_8Z.mjs");
var Route$5 = createFileRoute("/_workspace/explorer")({
	head: () => pageMeta("Food Explorer", "Search and filter foods by cuisine, diet, meal type, calories and protein."),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("../_workspace.history-CAs55tb4.mjs");
var Route$4 = createFileRoute("/_workspace/history")({
	head: () => pageMeta("Recommendation History", "Review your previous recommendation sessions."),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_workspace.insights-CuEKQUUV.mjs");
var Route$3 = createFileRoute("/_workspace/insights")({
	head: () => pageMeta("Nutrition Insights", "A simple overview of nutrition trends, food balance, and the progress signals behind your plan."),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("../_workspace.profile-DqbRiwow.mjs");
var Route$2 = createFileRoute("/_workspace/profile")({
	head: () => pageMeta("Your Goals", "Set goals, dietary preferences, constraints, and nutrition targets that shape your plan."),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("../_workspace.recommendations-25n_1w1W.mjs");
var Route$1 = createFileRoute("/_workspace/recommendations")({
	head: () => pageMeta("Meal Planner", "Personalized meal ideas shaped around your goals, diet, and food preferences."),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_workspace.saved-CoiNaaVy.mjs");
var Route = createFileRoute("/_workspace/saved")({
	head: () => pageMeta("Saved Meals", "Your saved meals and foods on NUTRIFY."),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$14
});
var WorkspaceRoute = Route$12.update({
	id: "/_workspace",
	getParentRoute: () => Route$14
});
var ForgotPasswordRoute = Route$11.update({
	id: "/forgot-password",
	path: "/forgot-password",
	getParentRoute: () => Route$14
});
var LoginRoute = Route$10.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$14
});
var RegisterRoute = Route$9.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => Route$14
});
var WorkspaceRouteChildren = {
	WorkspaceAssessmentRoute: Route$8.update({
		id: "/assessment",
		path: "/assessment",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceDashboardRoute: Route$7.update({
		id: "/dashboard",
		path: "/dashboard",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceDiaryRoute: Route$6.update({
		id: "/diary",
		path: "/diary",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceExplorerRoute: Route$5.update({
		id: "/explorer",
		path: "/explorer",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceHistoryRoute: Route$4.update({
		id: "/history",
		path: "/history",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceInsightsRoute: Route$3.update({
		id: "/insights",
		path: "/insights",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceProfileRoute: Route$2.update({
		id: "/profile",
		path: "/profile",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceRecommendationsRoute: Route$1.update({
		id: "/recommendations",
		path: "/recommendations",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceSavedRoute: Route.update({
		id: "/saved",
		path: "/saved",
		getParentRoute: () => WorkspaceRoute
	}),
	WorkspaceFoodsFoodIdRoute: Route$15.update({
		id: "/foods/$foodId",
		path: "/foods/$foodId",
		getParentRoute: () => WorkspaceRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	WorkspaceRoute: WorkspaceRoute._addFileChildren(WorkspaceRouteChildren),
	ForgotPasswordRoute,
	LoginRoute,
	RegisterRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
