//#region node_modules/.nitro/vite/services/ssr/assets/hero-meal-BzPMHyun.js
var hero_meal_default = "/assets/hero-meal-BcPlfdwN.jpg";
//#endregion
export { hero_meal_default as t };
