import { t as cn } from "./utils-C_uf36nf.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { x as Leaf } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Logo-WnIea4Ko.js
var import_jsx_runtime = require_jsx_runtime();
function Logo({ className, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: cn("group inline-flex items-center gap-2", className),
		"aria-label": "NUTRIFY home",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-8 place-items-center rounded-full bg-forest text-lime transition-transform duration-500 group-hover:rotate-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "size-4" })
		}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-xl text-forest",
			children: "NUTRIFY"
		})]
	});
}
//#endregion
export { Logo as t };
