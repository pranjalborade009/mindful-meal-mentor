import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { A as EyeOff, k as Eye } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-BuPsPhsM.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as Field, t as AuthLayout } from "./AuthLayout-4bq3yTtf.mjs";
import { t as Checkbox } from "./checkbox-kt6FvQcE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-D8ZCKyzA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const [show, setShow] = (0, import_react.useState)(false);
	const [email, setEmail] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)();
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthLayout, {
		title: "Welcome back",
		subtitle: "Log in to continue to your nutrition workspace.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-5",
			onSubmit: (e) => {
				e.preventDefault();
				if (!email.includes("@")) return setErr("Enter a valid email address.");
				setErr(void 0);
				toast("Demo login", { description: "No credentials were checked or stored." });
				navigate({ to: "/dashboard" });
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "email",
					label: "Email",
					error: err,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "email",
						type: "email",
						placeholder: "you@example.com",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						className: "h-11 bg-card"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "password",
					label: "Password",
					hint: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/forgot-password",
						className: "text-xs text-primary hover:underline",
						children: "Forgot password?"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "password",
							type: show ? "text" : "password",
							placeholder: "••••••••",
							className: "h-11 bg-card pr-10"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setShow(!show),
							"aria-label": show ? "Hide password" : "Show password",
							className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-forest",
							children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {}), " Remember me"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "forest",
					size: "lg",
					className: "w-full",
					children: "Log in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-center text-sm text-muted-foreground",
					children: ["New to NUTRIFY? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/register",
						className: "font-medium text-primary hover:underline",
						children: "Create an account"
					})]
				})
			]
		})
	});
}
//#endregion
export { LoginPage as component };
