import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { J as ArrowLeft, U as Bookmark, W as BookmarkCheck, x as Leaf } from "./_libs/lucide-react.mjs";
import { i as formatNutrient, t as calculatePortionNutrition } from "./_ssr/food-data-service-ig-qFVcp.mjs";
import { n as DemoBadge } from "./_ssr/common-DdTCn9RE.mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
import { t as Input } from "./_ssr/input-B8Q2ztVi.mjs";
import { n as useSavedFoods } from "./_ssr/use-saved-foods-CT0vTAMy.mjs";
import { n as FoodImage, r as recommendationService } from "./_ssr/FoodCard-DBah2pwS.mjs";
import { c as ResponsiveContainer, o as Pie, s as Cell, t as PieChart } from "./_libs/recharts+[...].mjs";
import { t as Route } from "./_workspace.foods._foodId-BjUBfa0b.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.foods._foodId-Rt1kA5jy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FoodDetails() {
	const { food } = Route.useLoaderData();
	const { isSaved, toggle } = useSavedFoods();
	const portionOptions = [food.nutrition.servingSize, ...food.servingOptions ?? []];
	const [portionQuantity, setPortionQuantity] = (0, import_react.useState)(String(food.nutrition.servingSize.quantity));
	const [portionOptionIndex, setPortionOptionIndex] = (0, import_react.useState)("0");
	(0, import_react.useEffect)(() => {
		setPortionOptionIndex("0");
		setPortionQuantity(String(food.nutrition.servingSize.quantity));
	}, [food.id, food.nutrition.servingSize.quantity]);
	const saved = isSaved(food.id);
	const recommendation = recommendationService.getForFood(food.id);
	const nutrition = food.nutrition;
	const selectedServing = portionOptions[Number(portionOptionIndex)] ?? nutrition.servingSize;
	const selectedQuantity = Number(portionQuantity);
	const selectedNutrition = calculatePortionNutrition(nutrition, {
		...selectedServing,
		quantity: selectedQuantity,
		...selectedServing.weightGrams !== void 0 && Number.isFinite(selectedQuantity) && selectedServing.quantity > 0 ? { weightGrams: selectedServing.weightGrams * selectedQuantity / selectedServing.quantity } : {}
	});
	const displayedNutrition = selectedNutrition.nutrition;
	const chartMacros = [
		{
			name: "Protein",
			value: displayedNutrition.proteinG === null ? null : displayedNutrition.proteinG * 4,
			color: "var(--color-chart-1)"
		},
		{
			name: "Carbs",
			value: displayedNutrition.carbohydrateG === null ? null : displayedNutrition.carbohydrateG * 4,
			color: "var(--color-chart-2)"
		},
		{
			name: "Fat",
			value: displayedNutrition.fatG === null ? null : displayedNutrition.fatG * 9,
			color: "var(--color-chart-3)"
		}
	].filter((macro) => macro.value !== null);
	const nutritionRows = [
		[
			"Calories",
			displayedNutrition.caloriesKcal,
			" kcal"
		],
		[
			"Protein",
			displayedNutrition.proteinG,
			" g"
		],
		[
			"Carbohydrates",
			displayedNutrition.carbohydrateG,
			" g"
		],
		[
			"Fat",
			displayedNutrition.fatG,
			" g"
		],
		[
			"Fibre",
			displayedNutrition.fiberG,
			" g"
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/explorer",
		className: "inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-forest",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Back to Food Explorer"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 grid gap-10 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded-[2rem] border bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodImage, {
				food,
				className: "aspect-[5/4]"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					food.cuisine !== "Unspecified" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-sage px-3 py-1 text-xs text-forest",
						children: food.cuisine
					}),
					food.regionalOrigin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-sage px-3 py-1 text-xs text-forest",
						children: food.regionalOrigin
					}),
					food.meal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-sage px-3 py-1 text-xs text-forest",
						children: food.meal
					}),
					food.dietaryLabels.map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-full bg-lime px-3 py-1 text-xs text-lime-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "size-3" }), label]
					}, label))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-5xl leading-tight",
				children: food.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: [
					food.regionalOrigin ? `${food.regionalOrigin} · ` : "",
					food.category,
					food.preparationState && food.preparationState !== "not-specified" ? ` · ${food.preparationState}` : "",
					food.priceInr ? ` · ₹${food.priceInr}` : ""
				]
			}),
			recommendation?.source === "demo" && recommendation.score != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center gap-4 rounded-xl border border-dashed p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-4xl text-primary",
					children: [recommendation.score, "%"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-forest",
					children: "Sample match score"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Illustrative prototype value — not produced by a trained model."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 border-y py-5",
				"aria-labelledby": "nutrition-heading",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "nutrition-heading",
								className: "text-base font-semibold text-forest",
								children: "Nutrition per portion"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: ["Reference: ", nutrition.basis === "per-100g" ? "per 100 g" : "per serving"]
							})] }),
							portionOptions.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1 text-xs text-muted-foreground",
								children: ["Standard portion", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: portionOptionIndex,
									onChange: (event) => {
										const nextIndex = Number(event.target.value);
										const option = portionOptions[nextIndex];
										if (option) {
											setPortionOptionIndex(event.target.value);
											setPortionQuantity(String(option.quantity));
										}
									},
									className: "h-9 rounded-md border border-input bg-card px-2 text-sm text-foreground",
									children: portionOptions.map((option, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: index,
										children: option.description ?? `${option.quantity} ${option.unit}`
									}, `${option.description ?? option.unit}-${index}`))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm text-muted-foreground",
								children: [
									"Portion",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: "0.1",
										step: "0.1",
										value: portionQuantity,
										onChange: (event) => setPortionQuantity(event.target.value),
										"aria-label": `Selected portion in ${selectedServing.unit}`,
										className: "h-9 w-24 bg-card"
									}),
									selectedServing.unit
								]
							})
						]
					}),
					selectedNutrition.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: selectedNutrition.note
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-[140px_1fr] items-center gap-6",
						children: [chartMacros.length === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-36",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
								data: chartMacros,
								dataKey: "value",
								innerRadius: 42,
								outerRadius: 64,
								paddingAngle: 2,
								stroke: "none",
								children: chartMacros.map((macro) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: macro.color }, macro.name))
							}) }) })
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-xs text-muted-foreground",
							children: "Macro chart unavailable"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-2 gap-3 text-sm",
							children: [nutritionRows.map(([label, value, unit]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b pb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-semibold text-forest",
									children: formatNutrient(value, unit)
								})]
							}, label)), Object.entries(displayedNutrition.micronutrients ?? {}).map(([name, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b pb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs capitalize text-muted-foreground",
									children: name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-semibold text-forest",
									children: formatNutrient(value.value, ` ${value.unit}`)
								})]
							}, name))]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-3 text-sm sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Reference serving"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium text-forest",
						children: [
							nutrition.servingSize.description ?? `${nutrition.servingSize.quantity} ${nutrition.servingSize.unit}`,
							" (",
							nutrition.servingSize.quantity,
							" ",
							nutrition.servingSize.unit,
							")"
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Nutrition data quality"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium capitalize text-forest",
						children: food.nutritionDataQuality
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Nutrition source"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-forest",
							children: food.nutritionProvenance.sourceName
						}),
						food.nutritionProvenance.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: food.nutritionProvenance.note
						}),
						food.nutritionProvenance.reference && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "text-xs text-primary underline",
							href: food.nutritionProvenance.reference,
							target: "_blank",
							rel: "noreferrer",
							children: "View source"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Allergen information"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-forest",
						children: food.allergenDataStatus === "complete" ? food.allergens?.length ? food.allergens.join(", ") : "No listed allergens" : food.allergens?.length ? `Known: ${food.allergens.join(", ")}; data incomplete` : "Unknown; allergen-free status cannot be confirmed"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Dietary labels"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-forest",
							children: food.dietaryLabels.length ? food.dietaryLabels.join(", ") : "No verified labels"
						})]
					})
				]
			}),
			food.ingredients && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-forest",
					children: "Ingredients"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: food.ingredients.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border bg-card px-3 py-1 text-xs",
						children: i
					}, i))
				})]
			}),
			food.preparationMethod && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-forest",
					children: "Preparation"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted-foreground",
					children: food.preparationMethod
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: saved ? "lime" : "forest",
					size: "lg",
					onClick: () => toggle(food.id),
					children: [
						saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {}),
						" ",
						saved ? "Saved" : "Save Food"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoBadge, {})]
			})
		] })]
	})] });
}
//#endregion
export { FoodDetails as component };
