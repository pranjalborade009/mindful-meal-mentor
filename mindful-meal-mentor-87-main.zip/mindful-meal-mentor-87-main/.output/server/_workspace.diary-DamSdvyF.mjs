import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { G as BookOpen, L as Check, c as Search, f as Plus, i as Trash2, l as SearchX, p as Pencil, t as X, z as CalendarDays } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { i as formatNutrient, n as filterFoods, r as foodDataService, t as calculatePortionNutrition } from "./_ssr/food-data-service-ig-qFVcp.mjs";
import { i as PageHeader, r as EmptyState } from "./_ssr/common-DdTCn9RE.mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
import { t as Input } from "./_ssr/input-B8Q2ztVi.mjs";
import { n as FoodImage } from "./_ssr/FoodCard-DBah2pwS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.diary-DamSdvyF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NUTRIENTS$1 = [
	"caloriesKcal",
	"proteinG",
	"carbohydrateG",
	"fatG",
	"fiberG"
];
function calculateLoggedFoodPortion(food, log) {
	const portion = calculatePortionNutrition(food.nutrition, log.portion);
	return {
		...log,
		foodId: food.id,
		foodName: food.name,
		nutrition: portion.nutrition,
		completeness: portion.completeness,
		missingNutrients: portion.missingNutrients,
		dataQuality: food.nutritionDataQuality,
		provenance: food.nutritionProvenance
	};
}
function sumKnownAmounts(values) {
	if (values.length === 0) return null;
	let total = 0;
	for (const value of values) {
		if (value === null || value === void 0 || !Number.isFinite(value)) return null;
		total += value;
	}
	return total;
}
function combinedDataQuality(entries) {
	const firstEntry = entries[0];
	if (!firstEntry) return "estimated";
	return new Set(entries.map((entry) => entry.dataQuality)).size === 1 ? firstEntry.dataQuality : "mixed";
}
/** A nutrient total is known only when every logged portion has that nutrient value. */
function aggregateIntakeNutrition(entries) {
	const nutrition = {
		servingSize: {
			quantity: entries.length,
			unit: "serving",
			description: `${entries.length} logged portions`
		},
		basis: "per-serving",
		caloriesKcal: null,
		proteinG: null,
		carbohydrateG: null,
		fatG: null,
		fiberG: null
	};
	const missingNutrients = [];
	for (const key of NUTRIENTS$1) {
		const total = sumKnownAmounts(entries.map((entry) => entry.nutrition[key]));
		nutrition[key] = total;
		if (total === null) missingNutrients.push(key);
	}
	const micronutrientNames = [...new Set(entries.flatMap((entry) => Object.keys(entry.nutrition.micronutrients ?? {})))];
	if (micronutrientNames.length) {
		nutrition.micronutrients = {};
		for (const name of micronutrientNames) {
			const amounts = entries.map((entry) => entry.nutrition.micronutrients?.[name]);
			const units = new Set(amounts.flatMap((amount) => amount ? [amount.unit] : []));
			const unit = units.size === 1 ? [...units][0] : "incompatible units";
			const total = units.size === 1 ? sumKnownAmounts(amounts.map((amount) => amount?.value)) : null;
			const aggregate = {
				value: total,
				unit
			};
			nutrition.micronutrients[name] = aggregate;
			if (total === null) missingNutrients.push(`micronutrients.${name}`);
		}
	}
	const knownCount = [...NUTRIENTS$1.map((key) => nutrition[key]), ...Object.values(nutrition.micronutrients ?? {}).map((amount) => amount.value)].filter((value) => value !== null).length;
	return {
		nutrition,
		completeness: entries.length === 0 || knownCount === 0 ? "unavailable" : missingNutrients.length > 0 ? "partial" : "complete",
		dataQuality: entries.length ? combinedDataQuality(entries) : "estimated",
		entryCount: entries.length,
		missingNutrients,
		provenance: [...new Set(entries.map((entry) => entry.provenance.sourceName))]
	};
}
function aggregateIntakeByMeal(entries) {
	const grouped = /* @__PURE__ */ new Map();
	for (const entry of entries) grouped.set(entry.meal, [...grouped.get(entry.meal) ?? [], entry]);
	return Object.fromEntries([...grouped].map(([meal, meals]) => [meal, aggregateIntakeNutrition(meals)]));
}
function compareNutrient(nutrient, intake, targets) {
	const target = targets[nutrient];
	const consumed = intake.nutrition[nutrient];
	if (target === void 0 || target === null || !Number.isFinite(target) || target <= 0) return {
		status: "unavailable",
		consumed,
		target: null,
		difference: null,
		progressPercent: null,
		reason: "No valid target is available for this nutrient."
	};
	if (consumed === null || !Number.isFinite(consumed)) return {
		status: "unavailable",
		consumed: null,
		target,
		difference: null,
		progressPercent: null,
		reason: "Logged intake does not contain complete data for this nutrient."
	};
	return {
		status: "available",
		consumed,
		target,
		difference: target - consumed,
		progressPercent: Math.round(consumed / target * 100),
		dataQuality: intake.dataQuality,
		note: intake.dataQuality === "verified" ? "Based on logged portions and verified source data." : "An estimate based on logged portions and the available food data; not an exact measurement."
	};
}
/** Compares each nutrient independently and leaves unavailable intake/targets uncomputed. */
function compareDailyIntakeToTargets(intake, targets) {
	return {
		caloriesKcal: compareNutrient("caloriesKcal", intake, targets),
		proteinG: compareNutrient("proteinG", intake, targets),
		carbohydrateG: compareNutrient("carbohydrateG", intake, targets),
		fatG: compareNutrient("fatG", intake, targets),
		fiberG: compareNutrient("fiberG", intake, targets)
	};
}
var STORAGE_KEY = "nutrify-food-diary-v1";
var VERSION = 1;
var MEALS$1 = [
	"Breakfast",
	"Lunch",
	"Dinner",
	"Snack"
];
var SERVING_UNITS = [
	"g",
	"ml",
	"piece",
	"serving"
];
var BrowserDiaryStorage = class {
	getItem(key) {
		if (typeof window === "undefined") throw new Error("Browser storage is unavailable.");
		return window.localStorage.getItem(key);
	}
	setItem(key, value) {
		if (typeof window === "undefined") throw new Error("Browser storage is unavailable.");
		window.localStorage.setItem(key, value);
	}
};
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isDateOnly(value) {
	if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
	const parsed = /* @__PURE__ */ new Date(`${value}T00:00:00.000Z`);
	return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}
function isMeal(value) {
	return typeof value === "string" && MEALS$1.some((meal) => meal === value);
}
function isServingSize(value) {
	if (!isRecord(value)) return false;
	if (typeof value["quantity"] !== "number" || !Number.isFinite(value["quantity"]) || value["quantity"] <= 0 || value["quantity"] > 1e5) return false;
	if (typeof value["unit"] !== "string" || !SERVING_UNITS.some((unit) => unit === value["unit"])) return false;
	if (value["weightGrams"] !== void 0 && (typeof value["weightGrams"] !== "number" || !Number.isFinite(value["weightGrams"]) || value["weightGrams"] <= 0)) return false;
	if (value["description"] !== void 0 && typeof value["description"] !== "string") return false;
	return true;
}
function parseEntry(value, isKnownFood) {
	if (!isRecord(value)) return null;
	const { id, foodId, date, meal, portion } = value;
	if (typeof id !== "string" || !id.trim() || id.length > 120) return null;
	if (typeof foodId !== "string" || !foodId.trim() || !isKnownFood(foodId)) return null;
	if (!isDateOnly(date) || !isMeal(meal) || !isServingSize(portion)) return null;
	return {
		id,
		foodId,
		date,
		meal,
		portion: {
			quantity: portion.quantity,
			unit: portion.unit,
			...portion.description !== void 0 ? { description: portion.description } : {},
			...portion.weightGrams !== void 0 ? { weightGrams: portion.weightGrams } : {}
		}
	};
}
var FoodDiaryService = class {
	storage;
	isKnownFood;
	constructor(storage, isKnownFood) {
		this.storage = storage;
		this.isKnownFood = isKnownFood;
	}
	getEntries() {
		const stored = this.storage.getItem(STORAGE_KEY);
		if (!stored) return [];
		let parsed;
		try {
			parsed = JSON.parse(stored);
		} catch {
			return [];
		}
		if (!isRecord(parsed) || parsed["version"] !== VERSION || !Array.isArray(parsed["entries"])) return [];
		const entries = parsed["entries"].map((value) => parseEntry(value, this.isKnownFood)).filter((entry) => entry !== null);
		const ids = /* @__PURE__ */ new Set();
		return entries.filter((entry) => {
			if (ids.has(entry.id)) return false;
			ids.add(entry.id);
			return true;
		});
	}
	getEntriesForDate(date) {
		if (!isDateOnly(date)) throw new RangeError("Diary date must be a valid YYYY-MM-DD date.");
		return this.getEntries().filter((entry) => entry.date === date);
	}
	addEntry(entry) {
		const validEntry = parseEntry(entry, this.isKnownFood);
		if (!validEntry) throw new TypeError("Diary entry is invalid or references an unavailable food.");
		const entries = this.getEntries();
		if (entries.some((existing) => existing.id === validEntry.id)) throw new Error("Diary entry id already exists.");
		return this.writeEntries([...entries, validEntry]);
	}
	updateEntry(id, changes) {
		const entries = this.getEntries();
		const index = entries.findIndex((entry) => entry.id === id);
		if (index < 0) throw new Error("Diary entry was not found.");
		const updated = parseEntry({
			...entries[index],
			...changes
		}, this.isKnownFood);
		if (!updated) throw new TypeError("Updated diary entry is invalid.");
		const next = [...entries];
		next[index] = updated;
		return this.writeEntries(next);
	}
	removeEntry(id) {
		const entries = this.getEntries();
		const next = entries.filter((entry) => entry.id !== id);
		if (next.length === entries.length) return entries;
		return this.writeEntries(next);
	}
	writeEntries(entries) {
		this.storage.setItem(STORAGE_KEY, JSON.stringify({
			version: VERSION,
			entries
		}));
		return entries;
	}
};
var MEALS = [
	{
		value: "Breakfast",
		label: "Breakfast"
	},
	{
		value: "Lunch",
		label: "Lunch"
	},
	{
		value: "Dinner",
		label: "Dinner"
	},
	{
		value: "Snack",
		label: "Snacks"
	}
];
var NUTRIENTS = [
	{
		key: "caloriesKcal",
		label: "Calories",
		unit: " kcal"
	},
	{
		key: "proteinG",
		label: "Protein",
		unit: " g"
	},
	{
		key: "carbohydrateG",
		label: "Carbohydrates",
		unit: " g"
	},
	{
		key: "fatG",
		label: "Fat",
		unit: " g"
	},
	{
		key: "fiberG",
		label: "Fibre",
		unit: " g"
	}
];
var diaryService = new FoodDiaryService(new BrowserDiaryStorage(), (foodId) => foodDataService.getById(foodId) !== void 0);
function localToday() {
	const today = /* @__PURE__ */ new Date();
	const month = String(today.getMonth() + 1).padStart(2, "0");
	const day = String(today.getDate()).padStart(2, "0");
	return `${today.getFullYear()}-${month}-${day}`;
}
function createEntryId() {
	return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
function portionWithQuantity(reference, quantity) {
	return {
		...reference,
		quantity,
		...reference.weightGrams !== void 0 ? { weightGrams: reference.weightGrams * (quantity / reference.quantity) } : {}
	};
}
function errorMessage(error) {
	return error instanceof Error ? error.message : "The diary could not be saved in this browser.";
}
function NutritionMetrics({ totals, comparison }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3 sm:grid-cols-5",
		children: NUTRIENTS.map(({ key, label, unit }) => {
			const progress = comparison?.[key];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 border-l-2 border-sage pl-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate text-sm font-semibold text-forest",
						children: formatNutrient(totals.nutrition[key], unit)
					}),
					comparison && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: progress?.status === "available" ? `${progress.progressPercent}% of target` : "Target unavailable"
					})
				]
			}, key);
		})
	});
}
function FoodDiaryPage() {
	const [selectedDate, setSelectedDate] = (0, import_react.useState)("");
	const [entries, setEntries] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [storageError, setStorageError] = (0, import_react.useState)(null);
	const [reloadKey, setReloadKey] = (0, import_react.useState)(0);
	const [search, setSearch] = (0, import_react.useState)("");
	const [selectedFoodId, setSelectedFoodId] = (0, import_react.useState)("");
	const [selectedMeal, setSelectedMeal] = (0, import_react.useState)("Breakfast");
	const [selectedServingIndex, setSelectedServingIndex] = (0, import_react.useState)("0");
	const [portionQuantity, setPortionQuantity] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [editingQuantity, setEditingQuantity] = (0, import_react.useState)("");
	const [editingMeal, setEditingMeal] = (0, import_react.useState)("Breakfast");
	(0, import_react.useEffect)(() => setSelectedDate(localToday()), []);
	(0, import_react.useEffect)(() => {
		if (!selectedDate) return;
		setLoading(true);
		setStorageError(null);
		try {
			setEntries(diaryService.getEntriesForDate(selectedDate));
		} catch (error) {
			setStorageError(errorMessage(error));
			setEntries([]);
		} finally {
			setLoading(false);
		}
	}, [selectedDate, reloadKey]);
	const foods = foodDataService.getAll();
	const searchResults = filterFoods(foods, { query: search });
	const selectedFood = selectedFoodId ? foodDataService.getById(selectedFoodId) : void 0;
	const selectedPortionOptions = selectedFood ? [selectedFood.nutrition.servingSize, ...selectedFood.servingOptions ?? []] : [];
	const selectedServing = selectedPortionOptions[Number(selectedServingIndex)] ?? selectedFood?.nutrition.servingSize;
	const calculatedEntries = entries.flatMap((entry) => {
		const food = foodDataService.getById(entry.foodId);
		return food ? [calculateLoggedFoodPortion(food, {
			id: entry.id,
			loggedAt: `${entry.date}T12:00:00.000Z`,
			meal: entry.meal,
			portion: entry.portion
		})] : [];
	});
	const dailyTotals = aggregateIntakeNutrition(calculatedEntries);
	const mealTotals = aggregateIntakeByMeal(calculatedEntries);
	const comparison = compareDailyIntakeToTargets(dailyTotals, {});
	const refreshEntries = () => setEntries(diaryService.getEntriesForDate(selectedDate));
	const addFood = () => {
		if (!selectedFood || !selectedDate) return;
		const quantity = Number(portionQuantity);
		if (!Number.isFinite(quantity) || quantity <= 0) {
			setStorageError("Enter a portion quantity greater than zero.");
			return;
		}
		try {
			diaryService.addEntry({
				id: createEntryId(),
				foodId: selectedFood.id,
				date: selectedDate,
				meal: selectedMeal,
				portion: portionWithQuantity(selectedServing ?? selectedFood.nutrition.servingSize, quantity)
			});
			refreshEntries();
			setSelectedFoodId("");
			setSelectedServingIndex("0");
			setPortionQuantity("");
			setStorageError(null);
			toast.success(`${selectedFood.name} added to ${selectedMeal.toLowerCase()}.`);
		} catch (error) {
			setStorageError(errorMessage(error));
			toast.error("Food could not be added to the diary.");
		}
	};
	const startEditing = (entry) => {
		setEditingId(entry.id);
		setEditingQuantity(String(entry.portion.quantity));
		setEditingMeal(entry.meal);
	};
	const saveEdit = (entry) => {
		const quantity = Number(editingQuantity);
		if (!Number.isFinite(quantity) || quantity <= 0) {
			setStorageError("Enter a portion quantity greater than zero.");
			return;
		}
		try {
			diaryService.updateEntry(entry.id, {
				meal: editingMeal,
				portion: portionWithQuantity(entry.portion, quantity)
			});
			refreshEntries();
			setEditingId(null);
			setStorageError(null);
			toast.success("Diary entry updated.");
		} catch (error) {
			setStorageError(errorMessage(error));
			toast.error("Diary entry could not be updated.");
		}
	};
	const removeEntry = (entry) => {
		try {
			diaryService.removeEntry(entry.id);
			refreshEntries();
			setStorageError(null);
			toast.success("Food removed from the diary.");
		} catch (error) {
			setStorageError(errorMessage(error));
			toast.error("Food could not be removed from the diary.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Daily nutrition",
				title: "Food Diary",
				description: "Log foods by meal and review the nutrition available for your selected day."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg border border-dashed bg-sage/40 px-4 py-3 text-sm leading-relaxed text-muted-foreground",
				children: "Diary entries are stored in this browser only. Local storage is not secure, synchronized, or suitable for production health-data storage."
			}),
			storageError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "alert",
				className: "flex flex-wrap items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/5 px-4 py-3 text-sm text-destructive",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: storageError }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					onClick: () => setReloadKey((key) => key + 1),
					children: "Retry"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-end gap-4 border-b pb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1.5 text-sm font-medium text-forest",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4" }), " Diary date"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: selectedDate,
									onChange: (event) => setSelectedDate(event.target.value),
									className: "w-52 bg-card"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "pb-2 text-xs text-muted-foreground",
								children: "Choose a date to view or add that day’s entries."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: search,
								onChange: (event) => setSearch(event.target.value),
								placeholder: "Search foods to add",
								"aria-label": "Search foods to add to diary",
								className: "h-10 rounded-full bg-card pl-9"
							})]
						}),
						searchResults.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y rounded-lg border bg-card",
							children: searchResults.map((food) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 px-4 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodImage, {
										food,
										className: "size-12 shrink-0 rounded-md"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-sm font-medium text-forest",
												children: food.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-muted-foreground",
												children: [
													[food.cuisine !== "Unspecified" ? food.cuisine : void 0, food.preparationState !== "not-specified" ? food.preparationState : void 0].filter(Boolean).join(" · ") || food.category,
													" · ",
													food.nutrition.basis === "per-100g" ? "per 100 g" : food.nutrition.servingSize.description ?? `${food.nutrition.servingSize.quantity} ${food.nutrition.servingSize.unit}`
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs capitalize text-muted-foreground",
												children: ["Nutrition: ", food.nutritionDataQuality]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: selectedFoodId === food.id ? "outline" : "forest",
										onClick: () => {
											setSelectedFoodId(food.id);
											setSelectedServingIndex("0");
											setPortionQuantity(String(food.nutrition.servingSize.quantity));
											setStorageError(null);
										},
										children: selectedFoodId === food.id ? "Selected" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add"] })
									})
								]
							}, food.id))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							icon: SearchX,
							title: "No foods found",
							description: "Try another food name or alternative name."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "surface h-fit space-y-4 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold text-forest",
						children: "Add to your diary"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Entries use the food’s reference serving unit."
					})] }), selectedFood && selectedServing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-forest",
							children: selectedFood.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1.5 text-sm font-medium text-forest",
							htmlFor: "diary-meal",
							children: ["Meal", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "diary-meal",
								value: selectedMeal,
								onChange: (event) => {
									const option = MEALS.find((meal) => meal.value === event.target.value);
									if (option) setSelectedMeal(option.value);
								},
								className: "h-10 w-full rounded-md border border-input bg-card px-3 text-sm",
								children: MEALS.map((meal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: meal.value,
									children: meal.label
								}, meal.value))
							})]
						}),
						selectedPortionOptions.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1.5 text-sm font-medium text-forest",
							htmlFor: "diary-standard-portion",
							children: ["Standard portion", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "diary-standard-portion",
								value: selectedServingIndex,
								onChange: (event) => {
									const index = Number(event.target.value);
									const option = selectedPortionOptions[index];
									if (option) {
										setSelectedServingIndex(event.target.value);
										setPortionQuantity(String(option.quantity));
									}
								},
								className: "h-10 w-full rounded-md border border-input bg-card px-3 text-sm",
								children: selectedPortionOptions.map((option, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: index,
									children: option.description ?? `${option.quantity} ${option.unit}`
								}, `${option.description ?? option.unit}-${index}`))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1.5 text-sm font-medium text-forest",
							htmlFor: "diary-portion",
							children: ["Portion quantity", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "diary-portion",
									type: "number",
									min: "0.1",
									step: "0.1",
									value: portionQuantity,
									onChange: (event) => setPortionQuantity(event.target.value),
									className: "bg-card"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-xs text-muted-foreground",
									children: selectedServing.unit
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Reference: ",
								selectedServing.quantity,
								" ",
								selectedServing.unit,
								selectedServing.description ? ` · ${selectedServing.description}` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "forest",
							className: "w-full",
							onClick: addFood,
							disabled: !selectedDate,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add food"]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-md border border-dashed px-3 py-5 text-center text-sm text-muted-foreground",
						children: "Search the catalogue and select a food to choose its meal and portion."
					})]
				})]
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "status",
				className: "rounded-lg border bg-card px-5 py-8 text-center text-sm text-muted-foreground",
				children: "Loading diary entries…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4 border-t pt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl text-forest",
								children: "Daily nutrition"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [
									entries.length,
									" logged ",
									entries.length === 1 ? "food" : "foods",
									" · ",
									dailyTotals.completeness,
									" totals · ",
									entries.length ? dailyTotals.dataQuality : "no data",
									" data"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Unknown nutrient values remain unavailable."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NutritionMetrics, {
							totals: dailyTotals,
							comparison
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-muted-foreground",
							children: comparison.caloriesKcal.status === "unavailable" ? "No valid daily targets are available for this diary yet. Demo profile targets are not used." : "Progress is an estimate based on logged portions and available nutrition data."
						})
					]
				}),
				entries.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: BookOpen,
					title: "No foods logged for this date",
					description: "Search the catalogue above to add your first meal."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y border-t",
					children: MEALS.map((meal) => {
						const mealEntries = entries.filter((entry) => entry.meal === meal.value);
						const totals = mealTotals[meal.value] ?? aggregateIntakeNutrition([]);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "py-6",
							"aria-labelledby": `meal-${meal.value}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center justify-between gap-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										id: `meal-${meal.value}`,
										className: "font-display text-xl text-forest",
										children: meal.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [
											mealEntries.length,
											" ",
											mealEntries.length === 1 ? "entry" : "entries",
											" · ",
											totals.completeness,
											" nutrition"
										]
									})] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NutritionMetrics, { totals })
								}),
								mealEntries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 text-sm text-muted-foreground",
									children: [
										"Nothing logged for ",
										meal.label.toLowerCase(),
										"."
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 divide-y rounded-lg border bg-card",
									children: mealEntries.map((entry) => {
										const food = foodDataService.getById(entry.foodId);
										if (!food) return null;
										const editing = editingId === entry.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex flex-wrap items-center gap-3 px-4 py-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodImage, {
													food,
													className: "size-12 shrink-0 rounded-md"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0 flex-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "truncate text-sm font-medium text-forest",
														children: food.name
													}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "mt-2 flex flex-wrap items-center gap-2",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
																type: "number",
																min: "0.1",
																step: "0.1",
																value: editingQuantity,
																onChange: (event) => setEditingQuantity(event.target.value),
																"aria-label": `Quantity for ${food.name}`,
																className: "h-8 w-28 bg-background"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs text-muted-foreground",
																children: entry.portion.unit
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
																"aria-label": `Meal for ${food.name}`,
																value: editingMeal,
																onChange: (event) => {
																	const option = MEALS.find((candidate) => candidate.value === event.target.value);
																	if (option) setEditingMeal(option.value);
																},
																className: "h-8 rounded-md border border-input bg-background px-2 text-xs",
																children: MEALS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: option.value,
																	children: option.label
																}, option.value))
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																type: "button",
																size: "icon",
																variant: "forest",
																"aria-label": `Save changes for ${food.name}`,
																onClick: () => saveEdit(entry),
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {})
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																type: "button",
																size: "icon",
																variant: "ghost",
																"aria-label": "Cancel edit",
																onClick: () => setEditingId(null),
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
															})
														]
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "mt-1 text-xs text-muted-foreground",
														children: [
															entry.portion.quantity,
															" ",
															entry.portion.unit,
															" · Nutrition ",
															food.nutritionDataQuality
														]
													})]
												}),
												!editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "button",
													size: "icon",
													variant: "ghost",
													"aria-label": `Edit ${food.name}`,
													onClick: () => startEditing(entry),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "button",
													size: "icon",
													variant: "ghost",
													"aria-label": `Remove ${food.name}`,
													onClick: () => removeEntry(entry),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
												})] })
											]
										}, entry.id);
									})
								})
							]
						}, meal.value);
					})
				})
			] })
		]
	});
}
//#endregion
export { FoodDiaryPage as component };
