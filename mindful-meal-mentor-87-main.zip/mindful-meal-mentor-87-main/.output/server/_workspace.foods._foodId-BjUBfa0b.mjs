import { Y as notFound, _ as createFileRoute, g as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as formatNutrient, r as foodDataService } from "./_ssr/food-data-service-ig-qFVcp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.foods._foodId-BjUBfa0b.js
var $$splitComponentImporter = () => import("./_workspace.foods._foodId-Rt1kA5jy.mjs");
var $$splitNotFoundComponentImporter = () => import("./_workspace.foods._foodId-nDocOWzN.mjs");
var Route = createFileRoute("/_workspace/foods/$foodId")({
	loader: ({ params }) => {
		const food = foodDataService.getById(params.foodId);
		if (!food) throw notFound();
		return { food };
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Food not found — NUTRIFY" }, {
			name: "robots",
			content: "noindex"
		}] };
		const d = `${loaderData.food.name}: ${formatNutrient(loaderData.food.nutrition.caloriesKcal, " kcal")}, ${formatNutrient(loaderData.food.nutrition.proteinG, " g protein")}. Nutrition details on NUTRIFY.`;
		return { meta: [
			{ title: `${loaderData.food.name} — NUTRIFY` },
			{
				name: "description",
				content: d
			},
			{
				property: "og:title",
				content: `${loaderData.food.name} — NUTRIFY`
			},
			{
				property: "og:description",
				content: d
			}
		] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
