import { y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { U as Bookmark } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as foodDataService } from "./_ssr/food-data-service-ig-qFVcp.mjs";
import { i as PageHeader, n as DemoBadge, r as EmptyState } from "./_ssr/common-DdTCn9RE.mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
import { n as useSavedFoods } from "./_ssr/use-saved-foods-CT0vTAMy.mjs";
import { t as FoodCard } from "./_ssr/FoodCard-DBah2pwS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.saved-CoiNaaVy.js
var import_jsx_runtime = require_jsx_runtime();
function SavedPage() {
	const { saved, remove } = useSavedFoods();
	const foods = saved.map((id) => foodDataService.getById(id)).filter((f) => f !== void 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Collection",
			title: "Saved Meals",
			description: `${foods.length} saved ${foods.length === 1 ? "meal" : "meals"}`,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoBadge, { label: "Local demo state" })
		}), foods.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			icon: Bookmark,
			title: "Nothing saved yet",
			description: "Save foods from the explorer or your recommendations to build a collection.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "forest",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/explorer",
					children: "Open Food Explorer"
				})
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
			children: foods.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodCard, {
				food: f,
				onRemove: () => {
					remove(f.id);
					toast(`${f.name} removed`);
				}
			}, f.id))
		})]
	});
}
//#endregion
export { SavedPage as component };
