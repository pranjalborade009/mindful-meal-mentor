import { i as __toESM } from "./_runtime.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { C as Layers, E as GitBranch, H as Boxes, O as FileQuestionMark, g as Network, j as Database, n as WandSparkles, q as ArrowRight, s as ShieldCheck, u as Scale } from "./_libs/lucide-react.mjs";
import { a as SectionCard, i as PageHeader, r as EmptyState, t as ChartPlaceholder } from "./_ssr/common-DdTCn9RE.mjs";
import { i as TabsTrigger$1, n as TabsContent$1, r as TabsList$1, t as Tabs$1 } from "./_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.insights-CuEKQUUV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Tabs$1;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList$1, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = TabsList$1.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger$1, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = TabsTrigger$1.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent$1, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = TabsContent$1.displayName;
var Table = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "relative w-full overflow-auto",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
		ref,
		className: cn("w-full caption-bottom text-sm", className),
		...props
	})
}));
Table.displayName = "Table";
var TableHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
	ref,
	className: cn("[&_tr]:border-b", className),
	...props
}));
TableHeader.displayName = "TableHeader";
var TableBody = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
	ref,
	className: cn("[&_tr:last-child]:border-0", className),
	...props
}));
TableBody.displayName = "TableBody";
var TableFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
	ref,
	className: cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
	...props
}));
TableFooter.displayName = "TableFooter";
var TableRow = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
	ref,
	className: cn("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className),
	...props
}));
TableRow.displayName = "TableRow";
var TableHead = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
	ref,
	className: cn("h-10 px-2 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableHead.displayName = "TableHead";
var TableCell = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
	ref,
	className: cn("p-2 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableCell.displayName = "TableCell";
var TableCaption = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
	ref,
	className: cn("mt-4 text-sm text-muted-foreground", className),
	...props
}));
TableCaption.displayName = "TableCaption";
/**
* Candidate algorithms only. All metric values are null until the Python ML
* pipeline supplies real results. Never hard-code fabricated numbers here.
*/
var candidateModels = [
	"K-Nearest Neighbors",
	"Decision Tree",
	"Support Vector Machine",
	"Naive Bayes",
	"Random Forest"
].map((algorithm) => ({
	algorithm,
	family: "Supervised",
	accuracy: null,
	precision: null,
	recall: null,
	f1: null,
	status: "Pending"
}));
var ensembleApproaches = [
	"Voting",
	"Bagging",
	"Boosting",
	"Stacking"
].map((algorithm) => ({
	algorithm,
	family: "Ensemble",
	accuracy: null,
	precision: null,
	recall: null,
	f1: null,
	status: "Pending"
}));
/** Empty until suitable transaction-style data exists. */
var associationRules = [];
var plannedFeatures = [
	{
		name: "Calorie density",
		note: "kcal per 100 g"
	},
	{
		name: "Protein density",
		note: "g protein per 100 kcal"
	},
	{
		name: "Macronutrient ratios",
		note: "P : C : F split"
	},
	{
		name: "Fiber ratio",
		note: "g fiber per serving"
	},
	{
		name: "User requirement features",
		note: "targets vs. food vector"
	}
];
var pipelineSteps = [
	"User Profile",
	"Feature Engineering",
	"Dietary Constraint Filtering",
	"Feature Similarity",
	"Personalized Ranking",
	"Recommended Foods"
];
var Pending = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
	className: "font-mono text-xs text-muted-foreground",
	children: "—"
});
function MetricTable({ rows }) {
	const cell = (v) => v == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pending, {}) : v.toFixed(3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-lg border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, {
			className: "bg-muted/60",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: [
				"Algorithm",
				"Accuracy",
				"Precision",
				"Recall",
				"F1-score",
				"Status"
			].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				className: "text-xs uppercase tracking-wider",
				children: h
			}, h)) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "font-medium text-forest",
				children: r.algorithm
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: cell(r.accuracy) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: cell(r.precision) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: cell(r.recall) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: cell(r.f1) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground",
				children: r.status
			}) })
		] }, r.algorithm)) })] })
	});
}
var stages = [
	{
		icon: Database,
		label: "Dataset"
	},
	{
		icon: WandSparkles,
		label: "Preprocessing"
	},
	{
		icon: Layers,
		label: "Features"
	},
	{
		icon: GitBranch,
		label: "Classification"
	},
	{
		icon: Boxes,
		label: "Clustering"
	},
	{
		icon: Network,
		label: "Ranking"
	}
];
function InsightsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Progress overview",
				title: "Nutrition Insights",
				description: "A place to review food balance, nutrition patterns, and plan health signals without exposing technical model details."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden rounded-[1.75rem] bg-forest p-6 text-forest-foreground md:p-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 dot-grid opacity-20",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow text-lime",
							children: "End-to-end methodology"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 max-w-2xl font-display text-3xl text-forest-foreground md:text-4xl",
							children: "From raw nutritional data to explainable, personalized recommendations."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid grid-cols-3 gap-3 md:grid-cols-6",
							children: stages.map(({ icon: Icon, label }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group relative rounded-xl border border-forest-foreground/15 p-4 transition-colors hover:bg-forest-foreground/5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-[0.65rem] opacity-50",
										children: ["0", i + 1]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "mt-3 size-5 text-lime" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm",
										children: label
									})
								]
							}, label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 inline-flex items-center gap-2 rounded-full bg-forest-foreground/10 px-3 py-1.5 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-lime" }), " No fabricated results — values appear only after experiments run."]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "data",
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
						className: "h-auto flex-wrap justify-start gap-1 rounded-full bg-sage/60 p-1",
						children: [
							["data", "Dataset & EDA"],
							["prep", "Preprocessing"],
							["supervised", "Supervised"],
							["ensemble", "Ensemble"],
							["clustering", "Clustering"],
							["rules", "Association rules"],
							["engine", "Recommendation engine"]
						].map(([v = "", l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: v,
							className: "rounded-full px-4 data-[state=active]:bg-forest data-[state=active]:text-forest-foreground",
							children: l
						}, v))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "data",
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
							children: [
								"Food records",
								"Features",
								"Missing values",
								"Target classes"
							].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "surface p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs uppercase tracking-wider text-muted-foreground",
										children: k
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-3xl text-muted-foreground/60",
										children: "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: "From dataset loader"
									})
								]
							}, k))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 lg:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
								title: "Nutrient distributions",
								subtitle: "Histogram per feature",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, { label: "Distributions" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
								title: "Correlation heatmap",
								subtitle: "Pearson correlation between nutrients",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, { label: "Correlation matrix" })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "prep",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 lg:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
								title: "Preprocessing steps",
								subtitle: "Planned pipeline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "space-y-3 text-sm",
									children: [
										"Handle missing values",
										"Remove duplicates & outliers",
										"Encode categorical attributes",
										"Scale numerical features (standardization)",
										"Train / test split with stratification"
									].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-6 place-items-center rounded-full bg-sage font-mono text-xs text-forest",
											children: i + 1
										}), s]
									}, s))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
								title: "Feature engineering",
								subtitle: "Planned feature examples — not yet computed",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "divide-y text-sm",
									children: plannedFeatures.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex justify-between py-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-forest",
											children: f.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: f.note
										})]
									}, f.name))
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "supervised",
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
							title: "Model comparison",
							subtitle: "Candidate algorithms — metrics pending experiments",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTable, { rows: candidateModels })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 lg:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
								title: "Confusion matrix",
								subtitle: "Best model on held-out test set",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, {
									label: "Confusion matrix",
									height: 220
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
								title: "Feature importance",
								subtitle: "When supported by the model",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, {
									label: "Feature importance",
									height: 220
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "ensemble",
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
							title: "Individual vs ensemble",
							subtitle: "No claim of improvement without experimental evidence",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTable, { rows: ensembleApproaches })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
							title: "Comparison chart",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, {
								label: "Ensemble comparison",
								height: 220
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "clustering",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 lg:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
									title: "Elbow method",
									subtitle: "Inertia vs. number of clusters (k)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, { label: "Elbow curve" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
									title: "Silhouette scores",
									subtitle: "Compare k values",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, { label: "Silhouette comparison" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
									title: "2-D cluster visualization",
									subtitle: "PCA projection of K-Means clusters",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, {
										label: "Cluster scatter",
										height: 220
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
									title: "Cluster distribution",
									subtitle: "Labels come from actual data",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, {
										label: "Cluster sizes",
										height: 220
									})
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "rules",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
							title: "Apriori association rules",
							subtitle: "Support · Confidence · Lift",
							children: associationRules.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
								icon: FileQuestionMark,
								title: "Data not available",
								description: "Association rule mining requires ingredient-combination or transaction-style data. Rules will appear here only if suitable data exists."
							}) : null
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "engine",
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
							title: "Personalized recommendation flow",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: pipelineSteps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: i === 2 ? "rounded-full bg-lime px-4 py-2 text-sm font-medium text-lime-foreground" : i === pipelineSteps.length - 1 ? "rounded-full bg-forest px-4 py-2 text-sm text-forest-foreground" : "rounded-full border bg-card px-4 py-2 text-sm text-forest",
										children: s
									}), i < pipelineSteps.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted-foreground" })]
								}, s))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid gap-4 md:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-muted/70 p-4 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 font-semibold text-forest",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), " Stage 1 — Hard constraints"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-muted-foreground",
										children: "Diet type, allergies and intolerances remove ineligible foods entirely. Nothing excluded here can be ranked."
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-muted/70 p-4 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 font-semibold text-forest",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "size-4" }), " Stage 2 — Ranking"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-muted-foreground",
										children: "Remaining foods are scored by similarity (e.g. cosine) between the user requirement vector and each food's feature vector."
									})]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
							title: "Experiment notes",
							subtitle: "Record observations for the viva",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPlaceholder, {
								label: "Experiment log",
								height: 120
							})
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { InsightsPage as component };
