import { i as __toESM } from "./_runtime.mjs";
import { t as cva } from "./_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { J as ArrowLeft, N as ClipboardCheck, P as CircleCheck, q as ArrowRight } from "./_libs/lucide-react.mjs";
import { r as foodDataService } from "./_ssr/food-data-service-ig-qFVcp.mjs";
import { i as PageHeader } from "./_ssr/common-DdTCn9RE.mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
import { t as Input } from "./_ssr/input-B8Q2ztVi.mjs";
import { t as Textarea } from "./_ssr/textarea-kko37XEX.mjs";
import { t as Label$1 } from "./_libs/radix-ui__react-label.mjs";
import { n as ProgressIndicator, t as Progress$1 } from "./_libs/radix-ui__react-progress.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.assessment-C-B7S-3X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Label$1.displayName;
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress$1, {
	ref,
	className: cn("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressIndicator, {
		className: "h-full w-full flex-1 bg-primary transition-all",
		style: { transform: `translateX(-${100 - (value || 0)}%)` }
	})
}));
Progress.displayName = Progress$1.displayName;
var ASSESSMENT_STEPS = [
	"About you",
	"Goals and routine",
	"Food preferences",
	"Everyday needs",
	"Review"
];
function createEmptyAssessmentForm() {
	return {
		age: "",
		heightCm: "",
		weightKg: "",
		goal: "",
		activityLevel: "",
		dietaryPattern: "",
		preferredCuisines: [],
		favoriteFoods: "",
		dislikedFoods: "",
		allergies: "",
		intolerances: "",
		mealTimingPreferences: [],
		budget: "",
		cookingPreference: "",
		healthConsiderations: ""
	};
}
function validateAssessmentStep(step, form) {
	const errors = {};
	if (step === 0) {
		const age = Number(form.age);
		const height = Number(form.heightCm);
		const weight = Number(form.weightKg);
		if (!form.age.trim()) errors["age"] = "Enter your age.";
		else if (!Number.isInteger(age) || age < 1 || age > 120) errors["age"] = "Enter an age from 1 to 120.";
		if (!form.heightCm.trim()) errors["heightCm"] = "Enter your height.";
		else if (!Number.isFinite(height) || height < 80 || height > 250) errors["heightCm"] = "Enter a height from 80 to 250 cm.";
		if (!form.weightKg.trim()) errors["weightKg"] = "Enter your current weight.";
		else if (!Number.isFinite(weight) || weight < 20 || weight > 500) errors["weightKg"] = "Enter a weight from 20 to 500 kg.";
	}
	if (step === 1) {
		if (!form.goal) errors["goal"] = "Choose a goal to continue.";
		if (!form.activityLevel) errors["activityLevel"] = "Choose an activity level to continue.";
		if (!form.dietaryPattern) errors["dietaryPattern"] = "Choose a dietary pattern to continue.";
	}
	return errors;
}
function getNextAssessmentStep(step) {
	return Math.min(step + 1, ASSESSMENT_STEPS.length - 1);
}
function getPreviousAssessmentStep(step) {
	return Math.max(step - 1, 0);
}
var STORAGE_KEY = "nutrify-assessment-draft-v1";
var goals = [
	"weight-loss",
	"weight-gain",
	"maintenance"
];
var activityLevels = [
	"sedentary",
	"light",
	"moderate",
	"high"
];
var dietaryPatterns = [
	"omnivore",
	"vegetarian",
	"eggetarian",
	"pescatarian",
	"vegan",
	"other"
];
var cookingPreferences = [
	"home-cooking",
	"quick-meals",
	"minimal-cooking",
	"mix"
];
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isOneOf(values, candidate) {
	return typeof candidate === "string" && values.some((value) => value === candidate);
}
function loadAssessmentDraft() {
	if (typeof window === "undefined") return null;
	try {
		const stored = window.localStorage.getItem(STORAGE_KEY);
		if (!stored) return null;
		const parsed = JSON.parse(stored);
		if (!isRecord(parsed) || parsed["version"] !== 1 || !isRecord(parsed["form"])) return null;
		const values = parsed["form"];
		const form = createEmptyAssessmentForm();
		if (typeof values["age"] === "string") form.age = values["age"];
		if (typeof values["heightCm"] === "string") form.heightCm = values["heightCm"];
		if (typeof values["weightKg"] === "string") form.weightKg = values["weightKg"];
		if (isOneOf(goals, values["goal"])) form.goal = values["goal"];
		if (isOneOf(activityLevels, values["activityLevel"])) form.activityLevel = values["activityLevel"];
		if (isOneOf(dietaryPatterns, values["dietaryPattern"])) form.dietaryPattern = values["dietaryPattern"];
		if (typeof values["favoriteFoods"] === "string") form.favoriteFoods = values["favoriteFoods"];
		if (typeof values["dislikedFoods"] === "string") form.dislikedFoods = values["dislikedFoods"];
		if (typeof values["budget"] === "string") form.budget = values["budget"];
		if (isOneOf(cookingPreferences, values["cookingPreference"])) form.cookingPreference = values["cookingPreference"];
		if (Array.isArray(values["preferredCuisines"])) form.preferredCuisines = values["preferredCuisines"].filter((value) => typeof value === "string");
		if (Array.isArray(values["mealTimingPreferences"])) form.mealTimingPreferences = values["mealTimingPreferences"].filter((value) => typeof value === "string");
		const draftStep = parsed["step"];
		return {
			form,
			step: typeof draftStep === "number" && Number.isInteger(draftStep) && draftStep >= 0 && draftStep < ASSESSMENT_STEPS.length ? draftStep : 0
		};
	} catch {
		return null;
	}
}
function saveAssessmentDraft(form, step) {
	if (typeof window === "undefined") return;
	const { allergies: _allergies, intolerances: _intolerances, healthConsiderations: _healthConsiderations, ...nonSensitiveForm } = form;
	const draft = {
		version: 1,
		step,
		form: nonSensitiveForm
	};
	try {
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
	} catch {}
}
function clearAssessmentDraft() {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.removeItem(STORAGE_KEY);
	} catch {}
}
var GOALS = [
	{
		value: "weight-loss",
		label: "Weight loss"
	},
	{
		value: "maintenance",
		label: "Weight maintenance"
	},
	{
		value: "weight-gain",
		label: "Weight gain"
	}
];
var ACTIVITY_LEVELS = [
	{
		value: "sedentary",
		label: "Mostly sitting"
	},
	{
		value: "light",
		label: "Light activity"
	},
	{
		value: "moderate",
		label: "Moderate activity"
	},
	{
		value: "high",
		label: "High activity"
	}
];
var DIETARY_PATTERNS = [
	{
		value: "omnivore",
		label: "Omnivore"
	},
	{
		value: "vegetarian",
		label: "Vegetarian"
	},
	{
		value: "eggetarian",
		label: "Eggetarian"
	},
	{
		value: "pescatarian",
		label: "Pescatarian"
	},
	{
		value: "vegan",
		label: "Vegan"
	},
	{
		value: "other",
		label: "Other"
	}
];
var MEAL_TIMES = [
	"Early breakfast",
	"Later breakfast",
	"Lunch",
	"Afternoon snack",
	"Early dinner",
	"Later dinner"
];
function isOptionValue(options, value) {
	return options.some((option) => option.value === value);
}
function FieldLabel({ htmlFor, children, required }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
		htmlFor,
		className: "flex items-center justify-between gap-3 text-sm font-medium text-forest",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("text-xs font-normal", required ? "text-primary" : "text-muted-foreground"),
			children: required ? "Required" : "Optional"
		})]
	});
}
function FieldError({ id, children }) {
	return children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		id: `${id}-error`,
		role: "alert",
		className: "text-xs text-destructive",
		children
	}) : null;
}
function ChoiceButtons({ label, value, options, onChange, error }) {
	const id = label.toLowerCase().replaceAll(" ", "-");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		"aria-describedby": error ? `${id}-error` : void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", {
				className: "mb-2 flex w-full items-center justify-between text-sm font-medium text-forest",
				children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-normal text-primary",
					children: "Required"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-3",
				children: options.map((option) => {
					const selected = value === option.value;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": selected,
						onClick: () => onChange(option.value),
						className: cn("min-h-11 rounded-lg border px-3 py-2 text-left text-sm transition-colors", selected ? "border-forest bg-forest text-forest-foreground" : "bg-card text-muted-foreground hover:border-primary hover:text-forest"),
						children: option.label
					}, option.value);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, {
				id,
				children: error
			})
		]
	});
}
function MultiChoice({ label, options, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", {
		className: "mb-2 flex w-full items-center justify-between text-sm font-medium text-forest",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-normal text-muted-foreground",
			children: "Optional"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-2",
		children: options.map((option) => {
			const selected = value.includes(option);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": selected,
				onClick: () => onChange(selected ? value.filter((item) => item !== option) : [...value, option]),
				className: cn("rounded-full border px-3.5 py-1.5 text-sm transition-colors", selected ? "border-forest bg-forest text-forest-foreground" : "bg-card text-muted-foreground hover:border-primary hover:text-forest"),
				children: option
			}, option);
		})
	})] });
}
function ReviewItem({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b py-3 last:border-b-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 text-sm font-medium text-forest",
			children: value || "Not provided"
		})]
	});
}
function AssessmentPage() {
	const [form, setForm] = (0, import_react.useState)(createEmptyAssessmentForm);
	const [step, setStep] = (0, import_react.useState)(0);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [ready, setReady] = (0, import_react.useState)(false);
	const [completed, setCompleted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const draft = loadAssessmentDraft();
		if (draft) {
			setForm(draft.form);
			setStep(draft.step);
		}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (ready && !completed) saveAssessmentDraft(form, step);
	}, [
		completed,
		form,
		ready,
		step
	]);
	const update = (key, value) => {
		setForm((current) => ({
			...current,
			[key]: value
		}));
		setErrors((current) => ({
			...current,
			[key]: ""
		}));
	};
	const continueStep = () => {
		const nextErrors = validateAssessmentStep(step, form);
		setErrors(nextErrors);
		if (Object.keys(nextErrors).length) return;
		setStep(getNextAssessmentStep(step));
	};
	const skipOptional = () => {
		setErrors({});
		setStep(getNextAssessmentStep(step));
	};
	const goBack = () => {
		setErrors({});
		setStep(getPreviousAssessmentStep(step));
	};
	const completeAssessment = () => {
		const requiredErrors = {
			...validateAssessmentStep(0, form),
			...validateAssessmentStep(1, form)
		};
		if (Object.keys(requiredErrors).length) {
			setErrors(requiredErrors);
			setStep(Object.keys(validateAssessmentStep(0, form)).length ? 0 : 1);
			return;
		}
		clearAssessmentDraft();
		setCompleted(true);
	};
	if (completed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b pb-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-auto grid size-14 place-items-center rounded-full bg-sage text-forest",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-7" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mt-5",
					children: "Personal assessment"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl md:text-4xl",
					children: "Assessment complete"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base",
					children: "Thanks for sharing. Your information will be used to prepare a personalized nutrition plan. No nutrition targets or medical recommendations have been generated here."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 flex justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "forest",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/dashboard",
					children: ["Go to Daily Progress ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
				})
			})
		})]
	});
	const currentStep = ASSESSMENT_STEPS[step];
	const cuisines = foodDataService.getCuisines();
	const stepProgress = (step + 1) / ASSESSMENT_STEPS.length * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Getting started",
				title: "Personal Assessment",
				description: "A few details help us understand your goals, routine, and food preferences. Required questions are marked; everything else is optional."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 rounded-lg border border-dashed bg-sage/40 px-4 py-3 text-sm leading-relaxed text-muted-foreground",
				children: "This development draft is saved in this browser and is not secure storage or authentication. Allergy, intolerance, and health details stay only in this page and are not saved in the draft."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				"aria-label": "Assessment progress",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-forest",
							children: currentStep
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Step ",
								step + 1,
								" of ",
								ASSESSMENT_STEPS.length
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: stepProgress,
						"aria-label": `Step ${step + 1} of ${ASSESSMENT_STEPS.length}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 hidden grid-cols-5 gap-2 sm:grid",
						children: ASSESSMENT_STEPS.map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: cn("text-xs", index <= step ? "font-medium text-forest" : "text-muted-foreground"),
							children: label
						}, label))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-xl border bg-card p-5 md:p-8",
				children: [
					step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						"aria-labelledby": "assessment-step-title",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "assessment-step-title",
								className: "font-display text-2xl",
								children: "About you"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Basic measurements, using metric units for now."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid gap-5 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
												htmlFor: "assessment-age",
												required: true,
												children: "Age"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "assessment-age",
												type: "number",
												inputMode: "numeric",
												min: "1",
												max: "120",
												step: "1",
												required: true,
												value: form.age,
												"aria-invalid": !!errors["age"],
												"aria-describedby": errors["age"] ? "assessment-age-error" : void 0,
												onChange: (event) => update("age", event.target.value)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, {
												id: "assessment-age",
												children: errors["age"]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, {
												htmlFor: "assessment-height",
												required: true,
												children: ["Height ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-normal text-muted-foreground",
													children: "cm"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "assessment-height",
												type: "number",
												inputMode: "decimal",
												min: "80",
												max: "250",
												step: "0.1",
												required: true,
												value: form.heightCm,
												"aria-invalid": !!errors["heightCm"],
												"aria-describedby": errors["heightCm"] ? "assessment-height-error" : void 0,
												onChange: (event) => update("heightCm", event.target.value)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, {
												id: "assessment-height",
												children: errors["heightCm"]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, {
												htmlFor: "assessment-weight",
												required: true,
												children: ["Current weight ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-normal text-muted-foreground",
													children: "kg"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "assessment-weight",
												type: "number",
												inputMode: "decimal",
												min: "20",
												max: "500",
												step: "0.1",
												required: true,
												value: form.weightKg,
												"aria-invalid": !!errors["weightKg"],
												"aria-describedby": errors["weightKg"] ? "assessment-weight-error" : void 0,
												onChange: (event) => update("weightKg", event.target.value)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, {
												id: "assessment-weight",
												children: errors["weightKg"]
											})
										]
									})
								]
							})
						]
					}),
					step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						"aria-labelledby": "assessment-step-title",
						className: "space-y-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "assessment-step-title",
								className: "font-display text-2xl",
								children: "Goals and routine"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "These are preferences, not a prescribed nutrition plan."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceButtons, {
								label: "Your goal",
								value: form.goal,
								options: GOALS,
								onChange: (value) => update("goal", value),
								error: errors["goal"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
											htmlFor: "assessment-activity",
											required: true,
											children: "Activity level"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											id: "assessment-activity",
											required: true,
											value: form.activityLevel,
											"aria-invalid": !!errors["activityLevel"],
											"aria-describedby": errors["activityLevel"] ? "assessment-activity-error" : void 0,
											onChange: (event) => {
												const value = event.currentTarget.value;
												update("activityLevel", isOptionValue(ACTIVITY_LEVELS, value) ? value : "");
											},
											className: "h-10 w-full rounded-md border border-input bg-card px-3 text-sm focus:outline-none focus:ring-1 focus:ring-ring",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Choose an activity level"
											}), ACTIVITY_LEVELS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: option.value,
												children: option.label
											}, option.value))]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, {
											id: "assessment-activity",
											children: errors["activityLevel"]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
											htmlFor: "assessment-diet",
											required: true,
											children: "Dietary pattern"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											id: "assessment-diet",
											required: true,
											value: form.dietaryPattern,
											"aria-invalid": !!errors["dietaryPattern"],
											"aria-describedby": errors["dietaryPattern"] ? "assessment-diet-error" : void 0,
											onChange: (event) => {
												const value = event.currentTarget.value;
												update("dietaryPattern", isOptionValue(DIETARY_PATTERNS, value) ? value : "");
											},
											className: "h-10 w-full rounded-md border border-input bg-card px-3 text-sm focus:outline-none focus:ring-1 focus:ring-ring",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Choose a dietary pattern"
											}), DIETARY_PATTERNS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: option.value,
												children: option.label
											}, option.value))]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, {
											id: "assessment-diet",
											children: errors["dietaryPattern"]
										})
									]
								})]
							})
						]
					}),
					step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						"aria-labelledby": "assessment-step-title",
						className: "space-y-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "assessment-step-title",
								className: "font-display text-2xl",
								children: "Food preferences"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Share what you enjoy. You can skip this step."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiChoice, {
								label: "Preferred cuisines",
								options: cuisines,
								value: form.preferredCuisines,
								onChange: (value) => update("preferredCuisines", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
										htmlFor: "assessment-favorites",
										children: "Favourite foods"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "assessment-favorites",
										value: form.favoriteFoods,
										maxLength: 500,
										placeholder: "Add any foods you enjoy",
										onChange: (event) => update("favoriteFoods", event.target.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
										htmlFor: "assessment-dislikes",
										children: "Foods you dislike"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "assessment-dislikes",
										value: form.dislikedFoods,
										maxLength: 500,
										placeholder: "Add any foods you prefer to avoid",
										onChange: (event) => update("dislikedFoods", event.target.value)
									})]
								})]
							})
						]
					}),
					step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						"aria-labelledby": "assessment-step-title",
						className: "space-y-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "assessment-step-title",
								className: "font-display text-2xl",
								children: "Everyday needs"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Optional details can help shape practical meal ideas. You can skip this step."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-lg border border-dashed bg-muted/40 px-4 py-3 text-sm text-muted-foreground",
								children: "Allergy, intolerance, and health answers are shown in your review but are not written to the local browser draft."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
										htmlFor: "assessment-allergies",
										children: "Allergies"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "assessment-allergies",
										value: form.allergies,
										maxLength: 500,
										placeholder: "Only share what you want considered",
										onChange: (event) => update("allergies", event.target.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
										htmlFor: "assessment-intolerances",
										children: "Intolerances"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "assessment-intolerances",
										value: form.intolerances,
										maxLength: 500,
										placeholder: "Optional",
										onChange: (event) => update("intolerances", event.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiChoice, {
								label: "Meal timing preferences",
								options: MEAL_TIMES,
								value: form.mealTimingPreferences,
								onChange: (value) => update("mealTimingPreferences", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
										htmlFor: "assessment-budget",
										children: "Food budget"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "assessment-budget",
										value: form.budget,
										maxLength: 120,
										placeholder: "Optional, include currency and period",
										onChange: (event) => update("budget", event.target.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
										htmlFor: "assessment-cooking",
										children: "Cooking preference"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "assessment-cooking",
										value: form.cookingPreference,
										onChange: (event) => {
											const value = event.currentTarget.value;
											update("cookingPreference", isOptionValue([
												{ value: "home-cooking" },
												{ value: "quick-meals" },
												{ value: "minimal-cooking" },
												{ value: "mix" }
											], value) ? value : "");
										},
										className: "h-10 w-full rounded-md border border-input bg-card px-3 text-sm focus:outline-none focus:ring-1 focus:ring-ring",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "No preference"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "home-cooking",
												children: "I enjoy cooking at home"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "quick-meals",
												children: "Quick meals work best"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "minimal-cooking",
												children: "Minimal cooking"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "mix",
												children: "A mix of options"
											})
										]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
										htmlFor: "assessment-health",
										children: "Health considerations"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "assessment-health",
										value: form.healthConsiderations,
										maxLength: 500,
										placeholder: "Share only what you would like considered; avoid details you do not want to include.",
										onChange: (event) => update("healthConsiderations", event.target.value)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Optional. NUTRIFY does not diagnose conditions or provide medical advice."
									})
								]
							})
						]
					}),
					step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						"aria-labelledby": "assessment-step-title",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-10 shrink-0 place-items-center rounded-full bg-sage text-forest",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									id: "assessment-step-title",
									className: "font-display text-2xl",
									children: "Review your answers"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: "Check your details before completing the assessment."
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid gap-6 md:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
										className: "rounded-lg border p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-sm font-semibold text-forest",
											children: "About you"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
											className: "mt-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Age",
													value: `${form.age} years`
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Height",
													value: `${form.heightCm} cm`
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Current weight",
													value: `${form.weightKg} kg`
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
										className: "rounded-lg border p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-sm font-semibold text-forest",
											children: "Goals and routine"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
											className: "mt-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Goal",
													value: GOALS.find((option) => option.value === form.goal)?.label ?? ""
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Activity level",
													value: ACTIVITY_LEVELS.find((option) => option.value === form.activityLevel)?.label ?? ""
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Dietary pattern",
													value: DIETARY_PATTERNS.find((option) => option.value === form.dietaryPattern)?.label ?? ""
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
										className: "rounded-lg border p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-sm font-semibold text-forest",
											children: "Food preferences"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
											className: "mt-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Preferred cuisines",
													value: form.preferredCuisines.join(", ")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Favourite foods",
													value: form.favoriteFoods
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Foods you dislike",
													value: form.dislikedFoods
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
										className: "rounded-lg border p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-sm font-semibold text-forest",
											children: "Everyday needs"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
											className: "mt-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Allergies",
													value: form.allergies
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Intolerances",
													value: form.intolerances
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Meal timing",
													value: form.mealTimingPreferences.join(", ")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Food budget",
													value: form.budget
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Cooking preference",
													value: form.cookingPreference ? form.cookingPreference.replaceAll("-", " ") : ""
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
													label: "Health considerations",
													value: form.healthConsiderations
												})
											]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-xs leading-relaxed text-muted-foreground",
								children: "Completing this assessment does not calculate nutrition targets or provide medical advice. Your information will be used to prepare a personalized nutrition plan."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap items-center justify-between gap-3 border-t pt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							onClick: goBack,
							disabled: step === 0,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), " Back"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "ghost",
								onClick: skipOptional,
								children: ["Skip optional questions ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							}), step < 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "forest",
								onClick: continueStep,
								children: [
									step === 3 ? "Review answers" : "Continue",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "forest",
								onClick: completeAssessment,
								children: ["Complete assessment ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {})]
							})]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { AssessmentPage as component };
