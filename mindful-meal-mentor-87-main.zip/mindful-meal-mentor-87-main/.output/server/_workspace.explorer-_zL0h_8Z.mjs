import { i as __toESM } from "./_runtime.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { c as Search, l as SearchX } from "./_libs/lucide-react.mjs";
import { r as foodDataService } from "./_ssr/food-data-service-ig-qFVcp.mjs";
import { i as PageHeader, n as DemoBadge, r as EmptyState } from "./_ssr/common-DdTCn9RE.mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
import { t as Input } from "./_ssr/input-B8Q2ztVi.mjs";
import { t as FoodCard } from "./_ssr/FoodCard-DBah2pwS.mjs";
import { n as SortSelect, r as useFoodFilter, t as FilterSelect } from "./_ssr/FoodFilters-D5cF2aTN.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "./_libs/radix-ui__react-slider.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.explorer-_zL0h_8Z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" })]
}));
Slider.displayName = Slider$1.displayName;
function ExplorerPage() {
	const foods = foodDataService.getAll();
	const { f, setF, results, reset } = useFoodFilter(foods);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Discover",
			title: "Food Explorer",
			description: "Browse USDA Foundation Foods alongside clearly labeled prototype entries. Cuisine and meal details are shown only when specified by the source.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoBadge, { label: "USDA + demo records" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[260px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "surface h-fit space-y-5 p-5 lg:sticky lg:top-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.q,
							onChange: (e) => setF({
								...f,
								q: e.target.value
							}),
							placeholder: "Search foods",
							className: "h-10 rounded-full bg-background pl-9",
							"aria-label": "Search foods"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: f.cuisine,
						onChange: (v) => setF({
							...f,
							cuisine: v
						}),
						placeholder: "Cuisines",
						options: foodDataService.getCuisines()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: f.category,
						onChange: (v) => setF({
							...f,
							category: v
						}),
						placeholder: "Categories",
						options: foodDataService.getCategories()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: f.diet,
						onChange: (v) => setF({
							...f,
							diet: v
						}),
						placeholder: "Diets",
						options: [
							"Vegetarian",
							"Non-vegetarian",
							"Vegan"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: f.meal,
						onChange: (v) => setF({
							...f,
							meal: v
						}),
						placeholder: "Meals",
						options: [
							"Breakfast",
							"Lunch",
							"Dinner",
							"Snack"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.allergens,
						onChange: (e) => setF({
							...f,
							allergens: e.target.value
						}),
						placeholder: "Exclude allergens",
						className: "h-10 rounded-full bg-card",
						"aria-label": "Allergens to exclude, comma separated"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 px-2 text-xs leading-relaxed text-muted-foreground",
						children: "Foods without complete allergen data are excluded when you enter an allergen."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-3 flex justify-between text-sm text-forest",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Max calories / 100 g" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [f.maxCal, " kcal"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 200,
						max: 700,
						step: 10,
						value: [f.maxCal],
						onValueChange: ([v]) => setF({
							...f,
							maxCal: v ?? f.maxCal
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-3 flex justify-between text-sm text-forest",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Min protein / 100 g" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [f.minProtein, " g"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 0,
						max: 45,
						step: 1,
						value: [f.minProtein],
						onValueChange: ([v]) => setF({
							...f,
							minProtein: v ?? 0
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: reset,
						className: "w-full",
						children: "Reset filters"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-forest",
							children: results.length
						}),
						" of ",
						foods.length,
						" foods"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortSelect, {
					value: f.sort,
					onChange: (v) => setF({
						...f,
						sort: v
					})
				})]
			}), results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: SearchX,
				title: "No results",
				description: "No sample foods match your search. Try a different term or reset filters.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: reset,
					children: "Reset filters"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-5 sm:grid-cols-2 xl:grid-cols-3",
				children: results.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodCard, { food: x }, x.id))
			})] })]
		})]
	});
}
//#endregion
export { ExplorerPage as component };
