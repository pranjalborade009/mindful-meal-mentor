import { y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { T as History, U as Bookmark, Y as Activity, a as Target, o as Sparkles, q as ArrowRight } from "./_libs/lucide-react.mjs";
import { i as formatNutrient, r as foodDataService } from "./_ssr/food-data-service-ig-qFVcp.mjs";
import { a as SectionCard, i as PageHeader, n as DemoBadge, r as EmptyState } from "./_ssr/common-DdTCn9RE.mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
import { n as useSavedFoods } from "./_ssr/use-saved-foods-CT0vTAMy.mjs";
import { t as FoodCard } from "./_ssr/FoodCard-DBah2pwS.mjs";
import { n as demoProfile, t as demoHistory } from "./_ssr/demoHistory-B7iCp8mX.mjs";
import { a as Bar, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as BarChart, r as YAxis } from "./_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.dashboard-028QJkUj.js
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const foods = foodDataService.getAll();
	const { saved } = useSavedFoods();
	const t = demoProfile.targets;
	const targets = [
		{
			name: "Protein",
			value: t.proteinG ?? 0
		},
		{
			name: "Carbs",
			value: t.carbohydrateG ?? 0
		},
		{
			name: "Fat",
			value: t.fatG ?? 0
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Overview",
				title: "Good evening, Demo User",
				description: "A quick view of your nutrition goals, meal plan, and progress for the day.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "forest",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/recommendations",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), " Build Meal Plan"]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoBadge, { label: "Demo data — no real user analyzed" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					{
						icon: Target,
						label: "Current goal",
						value: demoProfile.goal
					},
					{
						icon: Activity,
						label: "Activity level",
						value: demoProfile.activity
					},
					{
						icon: Sparkles,
						label: "Daily calorie target",
						value: `${t.caloriesKcal} kcal`
					},
					{
						icon: Bookmark,
						label: "Saved foods",
						value: String(saved.length)
					}
				].map(({ icon: Icon, label, value }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs uppercase tracking-wider text-muted-foreground",
							children: label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-2xl text-forest",
							children: value
						})
					]
				}, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
					title: "Nutritional targets",
					subtitle: "Grams per day, from your profile",
					className: "lg:col-span-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-52",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: targets,
								margin: { left: -20 },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										tickLine: false,
										axisLine: false,
										fontSize: 12
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tickLine: false,
										axisLine: false,
										fontSize: 11
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { cursor: { fill: "var(--color-muted)" } }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "value",
										fill: "var(--color-primary)",
										radius: [
											6,
											6,
											0,
											0
										]
									})
								]
							})
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
					title: "Profile summary",
					subtitle: "Edit anytime in My Profile",
					className: "lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "grid grid-cols-2 gap-4 text-sm sm:grid-cols-3",
						children: [
							["Age", `${demoProfile.age} yrs`],
							["Height", `${demoProfile.heightCm} cm`],
							["Weight", `${demoProfile.weightKg} kg`],
							["Diet", demoProfile.diet],
							["Cuisines", demoProfile.cuisines.join(", ")],
							["Budget", demoProfile.budget]
						].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted-foreground",
							children: k
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-0.5 font-medium text-forest",
							children: v
						})] }, k))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						className: "mt-6",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/profile",
							children: "Edit profile"
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Recommendation preview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/recommendations",
					className: "inline-flex items-center gap-1 text-sm text-primary hover:text-forest",
					children: ["See all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
				children: foods.slice(0, 3).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodCard, {
					food: f,
					showReason: true
				}, f.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
					title: "Recently saved",
					children: saved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						icon: Bookmark,
						title: "No saved foods",
						description: "Save foods you like to find them here.",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/explorer",
								children: "Browse foods"
							})
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y",
						children: saved.slice(0, 4).map((id) => {
							const f = foodDataService.getById(id);
							return f && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 py-3",
								children: [
									f.image && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: f.image,
										alt: "",
										className: "size-11 rounded-lg object-cover",
										loading: "lazy"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-forest",
											children: f.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												formatNutrient(f.nutrition.caloriesKcal, " kcal"),
												" · ",
												formatNutrient(f.nutrition.proteinG, " g protein")
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/foods/$foodId",
										params: { foodId: f.id },
										className: "text-xs text-primary",
										children: "View"
									})
								]
							}, id);
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
					title: "Recent sessions",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y",
						children: demoHistory.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-10 place-items-center rounded-lg bg-sage text-forest",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-forest",
										children: s.goal
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [
											new Date(s.createdAt).toLocaleDateString("en-IN", { dateStyle: "medium" }),
											" · ",
											s.count,
											" foods"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/history",
									className: "text-xs text-primary",
									children: "Open"
								})
							]
						}, s.id))
					})
				})]
			})
		]
	});
}
//#endregion
export { Dashboard as component };
