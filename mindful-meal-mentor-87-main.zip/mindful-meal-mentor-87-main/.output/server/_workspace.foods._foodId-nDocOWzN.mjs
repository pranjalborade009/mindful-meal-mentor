import { y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.foods._foodId-nDocOWzN.js
var import_jsx_runtime = require_jsx_runtime();
function FoodNotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-20 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "Food not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			className: "mt-6",
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/explorer",
				children: "Back to Food Explorer"
			})
		})]
	});
}
//#endregion
export { FoodNotFound as notFoundComponent };
