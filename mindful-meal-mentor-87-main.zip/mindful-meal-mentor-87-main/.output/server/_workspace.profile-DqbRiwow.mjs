import { i as __toESM } from "./_runtime.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { d as Save } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as foodDataService } from "./_ssr/food-data-service-ig-qFVcp.mjs";
import { i as PageHeader } from "./_ssr/common-DdTCn9RE.mjs";
import { t as Button } from "./_ssr/button-BuPsPhsM.mjs";
import { t as Input } from "./_ssr/input-B8Q2ztVi.mjs";
import { t as Textarea } from "./_ssr/textarea-kko37XEX.mjs";
import { n as demoProfile } from "./_ssr/demoHistory-B7iCp8mX.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-Dg1urBTx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_workspace.profile-DqbRiwow.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Section({ title, desc, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid gap-6 border-b py-8 md:grid-cols-[240px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-base font-semibold text-forest",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: desc
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2",
			children
		})]
	});
}
function F({ label, unit, children, full }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("space-y-1.5", full && "sm:col-span-2"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex justify-between text-sm font-medium text-forest",
			children: [label, unit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-normal text-muted-foreground",
				children: unit
			})]
		}), children]
	});
}
function Chips({ options, value, onChange, multi }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-2",
		children: options.map((o) => {
			const on = value.includes(o);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": on,
				onClick: () => onChange(multi ? on ? value.filter((x) => x !== o) : [...value, o] : [o]),
				className: cn("rounded-full border px-3.5 py-1.5 text-sm transition-colors", on ? "border-forest bg-forest text-forest-foreground" : "bg-card text-muted-foreground hover:border-primary hover:text-forest"),
				children: o
			}, o);
		})
	});
}
function ProfilePage() {
	const [p, setP] = (0, import_react.useState)(demoProfile);
	const set = (k, v) => setP((s) => ({
		...s,
		[k]: v
	}));
	const num = (v) => v === "" ? void 0 : Number(v);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			toast("Profile saved locally (demo)", { description: "Backend persistence comes in a later phase." });
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Settings",
				title: "Your Goals",
				description: "These inputs help shape your nutrition plan. All fields are optional unless noted. NUTRIFY supports nutrition planning and does not diagnose or prescribe medical treatment.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					variant: "forest",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), " Save Profile"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Personal information",
				desc: "Basic body measurements.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Age",
						unit: "years",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: p.age ?? "",
							onChange: (e) => set("age", num(e.target.value)),
							className: "bg-card"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Activity level",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: p.activity,
							onValueChange: (v) => set("activity", v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "bg-card",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
								"Sedentary",
								"Light",
								"Moderate",
								"Active"
							].map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: a,
								children: a
							}, a)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Height",
						unit: "cm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: p.heightCm ?? "",
							onChange: (e) => set("heightCm", num(e.target.value)),
							className: "bg-card"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Weight",
						unit: "kg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: p.weightKg ?? "",
							onChange: (e) => set("weightKg", num(e.target.value)),
							className: "bg-card"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Goal",
				desc: "What should recommendations support?",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Primary goal",
					full: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: [
							"Weight loss",
							"Weight maintenance",
							"Weight gain"
						],
						value: [p.goal],
						onChange: (v) => v[0] && set("goal", v[0])
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Dietary preference",
				desc: "Used as a hard filter before ranking.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Diet type",
					full: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: [
							"Vegetarian",
							"Non-vegetarian",
							"Vegan"
						],
						value: [p.diet],
						onChange: (v) => v[0] && set("diet", v[0])
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Food preferences",
				desc: "Soft preferences that influence ranking.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Cuisines",
						full: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							multi: true,
							options: foodDataService.getCuisines(),
							value: p.cuisines,
							onChange: (v) => set("cuisines", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Budget",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.budget ?? "",
							onChange: (e) => set("budget", e.target.value),
							placeholder: "e.g. ₹150–₹300 per meal",
							className: "bg-card"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Meal preferences",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "e.g. light dinners",
							className: "bg-card"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Likes",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: p.likes ?? "",
							onChange: (e) => set("likes", e.target.value),
							className: "bg-card"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Dislikes",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: p.dislikes ?? "",
							onChange: (e) => set("dislikes", e.target.value),
							className: "bg-card"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Dietary constraints",
				desc: "Foods containing these are excluded.",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Allergies",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: p.allergies ?? "",
						onChange: (e) => set("allergies", e.target.value),
						placeholder: "e.g. peanuts",
						className: "bg-card"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Intolerances",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "e.g. lactose",
						className: "bg-card"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Nutritional targets",
				desc: "Enter your own daily targets. NUTRIFY helps you monitor and plan around them.",
				children: [
					"caloriesKcal",
					"proteinG",
					"carbohydrateG",
					"fatG"
				].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: {
						caloriesKcal: "Calories",
						proteinG: "Protein",
						carbohydrateG: "Carbohydrates",
						fatG: "Fat"
					}[k],
					unit: k === "caloriesKcal" ? "kcal / day" : "g / day",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: p.targets[k] ?? "",
						onChange: (e) => set("targets", {
							...p.targets,
							[k]: num(e.target.value)
						}),
						className: "bg-card"
					})
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					variant: "forest",
					size: "lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), " Save Profile"]
				})
			})
		]
	});
}
//#endregion
export { ProfilePage as component };
