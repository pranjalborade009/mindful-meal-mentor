globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/arrow-left-hNlAnx9b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-ZyT0jPBNcXS+OgAyEBMBBXcK70k\"",
		"mtime": "2026-10-14T08:44:31.899Z",
		"size": 165,
		"path": "../public/assets/arrow-left-hNlAnx9b.js"
	},
	"/assets/arrow-right-Do1YRq-l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-MG5M3ZeCIHQIg1nOyWoIY5g1a7Y\"",
		"mtime": "2026-10-14T08:44:31.899Z",
		"size": 165,
		"path": "../public/assets/arrow-right-Do1YRq-l.js"
	},
	"/assets/AuthLayout-BRiVxAN0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"734-Pd5tvQN5Ew7cWldgyqhMBcqDMts\"",
		"mtime": "2026-10-14T08:44:31.814Z",
		"size": 1844,
		"path": "../public/assets/AuthLayout-BRiVxAN0.js"
	},
	"/assets/book-open-BXfbFqSQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-Bvtr9nymlQ3Wj26KndCke7Q02kk\"",
		"mtime": "2026-10-14T08:44:31.899Z",
		"size": 279,
		"path": "../public/assets/book-open-BXfbFqSQ.js"
	},
	"/assets/bookmark-BpAGh4iJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-8BUrFCd26dCwAQlDqrz96etN9rw\"",
		"mtime": "2026-10-14T08:44:31.900Z",
		"size": 230,
		"path": "../public/assets/bookmark-BpAGh4iJ.js"
	},
	"/assets/button-BwMEgZn2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c8-r0acS0qJscAx8KKvPMXjG1WULyM\"",
		"mtime": "2026-10-14T08:44:31.900Z",
		"size": 1480,
		"path": "../public/assets/button-BwMEgZn2.js"
	},
	"/assets/check-D5PIylc8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-uJ2Ivy+wmexk4Na2norU3xh+2cM\"",
		"mtime": "2026-10-14T08:44:31.900Z",
		"size": 124,
		"path": "../public/assets/check-D5PIylc8.js"
	},
	"/assets/checkbox-BCfF7nGq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1405-0v9FHhtokNHaoekSBWceE9bdGtI\"",
		"mtime": "2026-10-14T08:44:31.901Z",
		"size": 5125,
		"path": "../public/assets/checkbox-BCfF7nGq.js"
	},
	"/assets/Combination-C4hP2O5k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5abb-BDA7mdrmJicK6Y5YF5Iv/2PSPBk\"",
		"mtime": "2026-10-14T08:44:31.815Z",
		"size": 23227,
		"path": "../public/assets/Combination-C4hP2O5k.js"
	},
	"/assets/common-BEy9eFGc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a6a-7kSMgvGwKd31Nj+oBUoTGZd5GUA\"",
		"mtime": "2026-10-14T08:44:31.901Z",
		"size": 2666,
		"path": "../public/assets/common-BEy9eFGc.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-09T17:16:17.165Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/demoHistory-DbDB2drD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ec-CcTvKxQFtMoG7Cyhv/PKTUqXbmU\"",
		"mtime": "2026-10-14T08:44:31.902Z",
		"size": 748,
		"path": "../public/assets/demoHistory-DbDB2drD.js"
	},
	"/assets/dist-4ghk4zK4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"280-/WGqIWdbBceVeYlqUjD+DFfJXNk\"",
		"mtime": "2026-10-14T08:44:31.917Z",
		"size": 640,
		"path": "../public/assets/dist-4ghk4zK4.js"
	},
	"/assets/dist-B3pUOe40.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"785e-e9GUgf0HUbRfa4jw7aq+wK2FfeI\"",
		"mtime": "2026-10-14T08:44:31.988Z",
		"size": 30814,
		"path": "../public/assets/dist-B3pUOe40.js"
	},
	"/assets/dist-BCwNX6AT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1362-rLclujiBOpyAK3UJnIsIxHKYrbE\"",
		"mtime": "2026-10-14T08:44:32.146Z",
		"size": 4962,
		"path": "../public/assets/dist-BCwNX6AT.js"
	},
	"/assets/dist-BDDJhNHz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ed-Ohn+LeX1SkTaS2Gta2CdBXAQMPs\"",
		"mtime": "2026-10-14T08:44:32.147Z",
		"size": 749,
		"path": "../public/assets/dist-BDDJhNHz.js"
	},
	"/assets/dist-C27j6xoU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14aa-LsiKaCdTXf/3m8EtV8mu56FdxtU\"",
		"mtime": "2026-10-14T08:44:32.148Z",
		"size": 5290,
		"path": "../public/assets/dist-C27j6xoU.js"
	},
	"/assets/dist-CvH34gRE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cb5-ARb6JtjW8E5vhoQWesTzKKI8Yzw\"",
		"mtime": "2026-10-14T08:44:32.148Z",
		"size": 7349,
		"path": "../public/assets/dist-CvH34gRE.js"
	},
	"/assets/dist-CWtSPrbB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8311-DFQwDlKpOJC1V6HKnBtLpiBFdIQ\"",
		"mtime": "2026-10-14T08:44:32.148Z",
		"size": 33553,
		"path": "../public/assets/dist-CWtSPrbB.js"
	},
	"/assets/dist-CyBCRTPs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"94f-YGdk1tlAMZpuWEWojMTWkFiSKug\"",
		"mtime": "2026-10-14T08:44:32.149Z",
		"size": 2383,
		"path": "../public/assets/dist-CyBCRTPs.js"
	},
	"/assets/dist-MEaLFxYW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"230-65qlQ8XKKl6DsAZ5HbpNhOnTiTc\"",
		"mtime": "2026-10-14T08:44:32.149Z",
		"size": 560,
		"path": "../public/assets/dist-MEaLFxYW.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-10-09T17:16:17.153Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/createLucideIcon-GbkIog0d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-bE0625NoUfmUOMhS6HSRsuzW/PE\"",
		"mtime": "2026-10-14T08:44:31.902Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-GbkIog0d.js"
	},
	"/assets/food-chilla-n6Z9GcwE.jpg": {
		"type": "image/jpeg",
		"etag": "\"17ded-m+Je7B5OaeDOTvT0/8DSi718J+g\"",
		"mtime": "2026-10-14T08:44:32.380Z",
		"size": 97773,
		"path": "../public/assets/food-chilla-n6Z9GcwE.jpg"
	},
	"/assets/food-chicken-DJUJwxVR.jpg": {
		"type": "image/jpeg",
		"etag": "\"194da-/eC+p2rthzwwNYOWvMK4ExVYwqk\"",
		"mtime": "2026-10-14T08:44:32.379Z",
		"size": 103642,
		"path": "../public/assets/food-chicken-DJUJwxVR.jpg"
	},
	"/assets/food-lentil-CJbMgiC6.jpg": {
		"type": "image/jpeg",
		"etag": "\"1ae94-aR8lkfBLrKKXkDdI2VAIPWXcqC0\"",
		"mtime": "2026-10-14T08:44:32.488Z",
		"size": 110228,
		"path": "../public/assets/food-lentil-CJbMgiC6.jpg"
	},
	"/assets/food-khichdi-D50LqOAS.jpg": {
		"type": "image/jpeg",
		"etag": "\"16f8b-/iGjTlwHVUkSrt+7SIT3I+GsWAo\"",
		"mtime": "2026-10-14T08:44:32.380Z",
		"size": 94091,
		"path": "../public/assets/food-khichdi-D50LqOAS.jpg"
	},
	"/assets/food-data-service-CYB1yRp6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7ef21-l36dXIjdnoJxt+qlyE6tENaTAII\"",
		"mtime": "2026-10-14T08:44:32.149Z",
		"size": 519969,
		"path": "../public/assets/food-data-service-CYB1yRp6.js"
	},
	"/assets/food-paneer-gl9jMjJM.jpg": {
		"type": "image/jpeg",
		"etag": "\"15fe0-mIhtgPohyMY2NIree1b0qkFCR9k\"",
		"mtime": "2026-10-14T08:44:32.516Z",
		"size": 90080,
		"path": "../public/assets/food-paneer-gl9jMjJM.jpg"
	},
	"/assets/FoodCard-b8FA2s_I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14f9-J1sH6JmOLFf1DCpXsC2fLqjyDoo\"",
		"mtime": "2026-10-14T08:44:31.815Z",
		"size": 5369,
		"path": "../public/assets/FoodCard-b8FA2s_I.js"
	},
	"/assets/forgot-password-Cgz_ETZn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"688-OEMf+O3OLQHc3am9+GshhIKld4M\"",
		"mtime": "2026-10-14T08:44:32.149Z",
		"size": 1672,
		"path": "../public/assets/forgot-password-Cgz_ETZn.js"
	},
	"/assets/FoodFilters-CEUmz1LZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82c-BorYFAyfVXnoUPULvTf5WBq6ZO8\"",
		"mtime": "2026-10-14T08:44:31.815Z",
		"size": 2092,
		"path": "../public/assets/FoodFilters-CEUmz1LZ.js"
	},
	"/assets/hero-meal-DZsDpMu-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36-vn+Pwk4flkVZBAurANsT6HMWqfw\"",
		"mtime": "2026-10-14T08:44:32.237Z",
		"size": 54,
		"path": "../public/assets/hero-meal-DZsDpMu-.js"
	},
	"/assets/food-tofu-Di_n_vUD.jpg": {
		"type": "image/jpeg",
		"etag": "\"16de8-D3HwE8d9N7S4lgAf2xrN1yfqODg\"",
		"mtime": "2026-10-14T08:44:32.516Z",
		"size": 93672,
		"path": "../public/assets/food-tofu-Di_n_vUD.jpg"
	},
	"/assets/generateCategoricalChart-BEY-RGSc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54428-rzeKgnPjbqzCywXAMxxgbm/glUs\"",
		"mtime": "2026-10-14T08:44:32.204Z",
		"size": 345128,
		"path": "../public/assets/generateCategoricalChart-BEY-RGSc.js"
	},
	"/assets/index-CGRaIl-6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5533d-5a4yk3VwdOLe7PEX3fwDGd1wNUA\"",
		"mtime": "2026-10-14T08:44:31.814Z",
		"size": 348989,
		"path": "../public/assets/index-CGRaIl-6.js"
	},
	"/assets/input-FiBMTdHF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26c-iPwRH3hI+dH+Y+jJm+2DPom0YtM\"",
		"mtime": "2026-10-14T08:44:32.237Z",
		"size": 620,
		"path": "../public/assets/input-FiBMTdHF.js"
	},
	"/assets/jsx-runtime-D3jfb0Ew.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22c5-Qh7NbnnF5pPMnr2eoPNshytf37o\"",
		"mtime": "2026-10-14T08:44:32.238Z",
		"size": 8901,
		"path": "../public/assets/jsx-runtime-D3jfb0Ew.js"
	},
	"/assets/leaf-rhN69OLV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"109-ovMdcRUnUrYydMppVy81ebYvkRw\"",
		"mtime": "2026-10-14T08:44:32.278Z",
		"size": 265,
		"path": "../public/assets/leaf-rhN69OLV.js"
	},
	"/assets/link-Cqw0SZOf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c2a-asAmG8MrxyYTGUXjPVvQ9xoEFbE\"",
		"mtime": "2026-10-14T08:44:32.369Z",
		"size": 11306,
		"path": "../public/assets/link-Cqw0SZOf.js"
	},
	"/assets/login-Bpr1A9Tz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"849-MTT7qdZmIlFON/Rt0uMLMwd+h3k\"",
		"mtime": "2026-10-14T08:44:32.369Z",
		"size": 2121,
		"path": "../public/assets/login-Bpr1A9Tz.js"
	},
	"/assets/history-B4amKG8I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ed-O3F572r8ZFJYP1ZnyMtxMrB1MYI\"",
		"mtime": "2026-10-14T08:44:32.237Z",
		"size": 237,
		"path": "../public/assets/history-B4amKG8I.js"
	},
	"/assets/Logo-unpZ6WyN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"270-HyIrW7mC9HvJYYAeV5hG+7g0t4o\"",
		"mtime": "2026-10-14T08:44:31.841Z",
		"size": 624,
		"path": "../public/assets/Logo-unpZ6WyN.js"
	},
	"/assets/matchContext-CaFHjCGQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"115-lX8Z+WCNDR9vLhjW9f1lQQDpNBk\"",
		"mtime": "2026-10-14T08:44:32.369Z",
		"size": 277,
		"path": "../public/assets/matchContext-CaFHjCGQ.js"
	},
	"/assets/food-yogurt-CLeXujBT.jpg": {
		"type": "image/jpeg",
		"etag": "\"225b3-jOtsQCev1U6TpPtRarxjax8+dgk\"",
		"mtime": "2026-10-14T08:44:32.517Z",
		"size": 140723,
		"path": "../public/assets/food-yogurt-CLeXujBT.jpg"
	},
	"/assets/hero-meal-BcPlfdwN.jpg": {
		"type": "image/jpeg",
		"etag": "\"6cbaa-Ed6KSo5eWdAQfNHrsIGYhbszyOI\"",
		"mtime": "2026-10-14T08:44:32.517Z",
		"size": 445354,
		"path": "../public/assets/hero-meal-BcPlfdwN.jpg"
	},
	"/assets/network-DY9DdEcy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"602-altFQ44RmvfXEWzxKDwPrpXU7VM\"",
		"mtime": "2026-10-14T08:44:32.369Z",
		"size": 1538,
		"path": "../public/assets/network-DY9DdEcy.js"
	},
	"/assets/react-dom-CwdmouWZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f17-QemzpnA5Tqxk5YG3QZZamATuNCY\"",
		"mtime": "2026-10-14T08:44:32.370Z",
		"size": 3863,
		"path": "../public/assets/react-dom-CwdmouWZ.js"
	},
	"/assets/register-Bq5V1suL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a7e-XPWhQycGNBuV5eEEQLL5Tl/G2RU\"",
		"mtime": "2026-10-14T08:44:32.370Z",
		"size": 2686,
		"path": "../public/assets/register-Bq5V1suL.js"
	},
	"/assets/routes-L4Q2rmpV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3328-PZS7xKl27Q0Jysz5t0pzEm1wXls\"",
		"mtime": "2026-10-14T08:44:32.370Z",
		"size": 13096,
		"path": "../public/assets/routes-L4Q2rmpV.js"
	},
	"/assets/search-B2A_Zr5w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-/hjyh3sFMiIm58zz8MMjPchudZM\"",
		"mtime": "2026-10-14T08:44:32.371Z",
		"size": 174,
		"path": "../public/assets/search-B2A_Zr5w.js"
	},
	"/assets/search-x-CDQAVHFK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"101-VD/IQT4HAA5c2bEHu4rAO/ZIgo8\"",
		"mtime": "2026-10-14T08:44:32.372Z",
		"size": 257,
		"path": "../public/assets/search-x-CDQAVHFK.js"
	},
	"/assets/sparkles-BNBj2awz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-uGtTMOD3uwxC+E98+h6G/JFI9o0\"",
		"mtime": "2026-10-14T08:44:32.373Z",
		"size": 494,
		"path": "../public/assets/sparkles-BNBj2awz.js"
	},
	"/assets/select-BkGywjZJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bc4f-/A4DyIv96pcOSz/zFMZuseHMi50\"",
		"mtime": "2026-10-14T08:44:32.373Z",
		"size": 48207,
		"path": "../public/assets/select-BkGywjZJ.js"
	},
	"/assets/target-DwiEufwh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e2-F3nyrWm1BcNMX8EqRemapO1iKeM\"",
		"mtime": "2026-10-14T08:44:32.373Z",
		"size": 226,
		"path": "../public/assets/target-DwiEufwh.js"
	},
	"/assets/styles-seB3FkUe.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17a9b-Epu8mJAPaXMb6N2hY3tIY8kwEe0\"",
		"mtime": "2026-10-14T08:44:32.518Z",
		"size": 96923,
		"path": "../public/assets/styles-seB3FkUe.css"
	},
	"/assets/textarea-Caytr_j7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"206-BjSkRflbnYjjjYjDakgE1If7JXU\"",
		"mtime": "2026-10-14T08:44:32.373Z",
		"size": 518,
		"path": "../public/assets/textarea-Caytr_j7.js"
	},
	"/assets/useNavigate-B-zoS3m-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"df-QsEGir5LKahguL2liez6F/KnnMY\"",
		"mtime": "2026-10-14T08:44:32.374Z",
		"size": 223,
		"path": "../public/assets/useNavigate-B-zoS3m-.js"
	},
	"/assets/user-round-BSAvy415.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"41f-KhLZL/JYfvuvwVK9rrdSvJ4pP00\"",
		"mtime": "2026-10-14T08:44:32.374Z",
		"size": 1055,
		"path": "../public/assets/user-round-BSAvy415.js"
	},
	"/assets/x-C1YxrEI2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-qqQZU/SG7F9uMu8isvezLBj5xTo\"",
		"mtime": "2026-10-14T08:44:32.379Z",
		"size": 154,
		"path": "../public/assets/x-C1YxrEI2.js"
	},
	"/assets/_workspace-Bb5VD-gT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c76-m0y/6KYSBLXQvWm56j8tbPDQbug\"",
		"mtime": "2026-10-14T08:44:31.863Z",
		"size": 7286,
		"path": "../public/assets/_workspace-Bb5VD-gT.js"
	},
	"/assets/_workspace.assessment-DYq-CK1c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5ca9-UOfNOpc06Rs8cktUcpTi/qffBAg\"",
		"mtime": "2026-10-14T08:44:31.864Z",
		"size": 23721,
		"path": "../public/assets/_workspace.assessment-DYq-CK1c.js"
	},
	"/assets/_workspace.dashboard-DABF8zbN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c47-wLu4fN80kxfR0Tp0Iqu1ZVFkSP8\"",
		"mtime": "2026-10-14T08:44:31.864Z",
		"size": 23623,
		"path": "../public/assets/_workspace.dashboard-DABF8zbN.js"
	},
	"/assets/_workspace.diary-B9e6V3j5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab5-P2epqL/Qf5yksKGHRdTGqbCzyLc\"",
		"mtime": "2026-10-14T08:44:31.865Z",
		"size": 19125,
		"path": "../public/assets/_workspace.diary-B9e6V3j5.js"
	},
	"/assets/_workspace.explorer-BTNr4tTy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"370a-J3zVJr+dZn6+JeOpTllLUZ/8NjQ\"",
		"mtime": "2026-10-14T08:44:31.865Z",
		"size": 14090,
		"path": "../public/assets/_workspace.explorer-BTNr4tTy.js"
	},
	"/assets/_workspace.foods._foodId-1brvIzi0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"860a-L8slMO6NRSjoGng4MxW3xTh58yY\"",
		"mtime": "2026-10-14T08:44:31.890Z",
		"size": 34314,
		"path": "../public/assets/_workspace.foods._foodId-1brvIzi0.js"
	},
	"/assets/_workspace.foods._foodId-BNYebz2g.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c5-/8qVjYtkQ/CRYbberQIM5N4XeW4\"",
		"mtime": "2026-10-14T08:44:31.897Z",
		"size": 453,
		"path": "../public/assets/_workspace.foods._foodId-BNYebz2g.js"
	},
	"/assets/_workspace.foods._foodId-C4QOkl3j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c88-7QBmF2aSijrid2T2+7+w7uaLrik\"",
		"mtime": "2026-10-14T08:44:31.898Z",
		"size": 7304,
		"path": "../public/assets/_workspace.foods._foodId-C4QOkl3j.js"
	},
	"/assets/_workspace.history-B1LsLmKU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c0-aKLhbVde8x0POD7qFAoS9ebKuPQ\"",
		"mtime": "2026-10-14T08:44:31.898Z",
		"size": 5312,
		"path": "../public/assets/_workspace.history-B1LsLmKU.js"
	},
	"/assets/_workspace.insights-kAsJdobA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4fcb-uWG7n5Xpbbg2nTafoPlq6zSOw9M\"",
		"mtime": "2026-10-14T08:44:31.898Z",
		"size": 20427,
		"path": "../public/assets/_workspace.insights-kAsJdobA.js"
	},
	"/assets/_workspace.profile-ClKEAoTC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16be-FDsYsoFzAOLuMjipSkgTHOGbaq0\"",
		"mtime": "2026-10-14T08:44:31.898Z",
		"size": 5822,
		"path": "../public/assets/_workspace.profile-ClKEAoTC.js"
	},
	"/assets/_workspace.recommendations-C05rZxF0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f6e-VtZoXR8QwZ0sP0uYM50XsEDjWAE\"",
		"mtime": "2026-10-14T08:44:31.899Z",
		"size": 3950,
		"path": "../public/assets/_workspace.recommendations-C05rZxF0.js"
	},
	"/assets/_workspace.saved-Dryz6XuP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48f-H2gLOzWwPaK+ocZy2Woblo+gGHg\"",
		"mtime": "2026-10-14T08:44:31.899Z",
		"size": 1167,
		"path": "../public/assets/_workspace.saved-Dryz6XuP.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_ajR22V = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_ajR22V
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
