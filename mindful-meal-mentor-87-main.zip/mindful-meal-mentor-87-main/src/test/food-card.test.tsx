import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { demoFoods } from "@/data/demoFoods";
import { Macro, FoodImage } from "@/components/food/FoodCard";
import { usdaFoundationFoods } from "@/data/usdaFoundationFoods";

describe("Food Explorer cards", () => {
  it("shows an accessible fallback when the food has no image", () => {
    const importedFood = usdaFoundationFoods[0]!;
    expect(importedFood.image).toBeUndefined();
    render(<FoodImage food={importedFood} />);
    expect(screen.getByRole("img", { name: `Photo unavailable for ${importedFood.name}` })).toBeInTheDocument();
  });

  it("uses the existing image asset when one is supplied", () => {
    const demoFood = demoFoods.find((food) => food.image !== undefined)!;
    render(<FoodImage food={demoFood} />);
    expect(screen.getByRole("img", { name: demoFood.name })).toHaveAttribute("src", demoFood.image);
  });

  it("labels missing macro data as not available", () => {
    render(<Macro label="Protein" value={null} />);
    expect(screen.getByText("Not available")).toBeInTheDocument();
  });
});