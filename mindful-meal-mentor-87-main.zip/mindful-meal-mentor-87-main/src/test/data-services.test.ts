import { describe, expect, it } from "vitest";
import { candidateModels, ensembleApproaches, associationRules } from "@/data/demoMetrics";
import { foodDataService } from "@/services/food-data-service";
import { recommendationService } from "@/services/recommendation-service";

describe("frontend data services", () => {
  it("exposes demo foods with serving-scoped nutrition through the service", () => {
    const foods = foodDataService.getAll();
    const sampleFoods = foods.filter((food) => food.source === "demo");

    expect(sampleFoods).toHaveLength(8);
    expect(sampleFoods.every((food) => food.nutritionDataQuality === "estimated")).toBe(true);
    expect(sampleFoods.every((food) => food.nutritionProvenance.sourceType === "demo")).toBe(true);
    expect(sampleFoods.every((food) => food.allergenDataStatus === "unknown")).toBe(true);
    expect(sampleFoods.every((food) => food.nutrition.servingSize.quantity > 0)).toBe(true);
    expect(sampleFoods.every((food) => food.nutrition.servingSize.unit === "g")).toBe(true);
    expect(foods.some((food) => food.source === "usda-fooddata-central")).toBe(true);
    expect(new Set(foods.map((food) => food.id)).size).toBe(foods.length);
    expect(foodDataService.getById(foods[0]!.id)).toEqual(foods[0]);
    expect(foodDataService.getCuisines()).toContain("Indian");
  });

  it("keeps prototype recommendations and model metrics clearly separate", () => {
    const recommendations = recommendationService.getRecommendations();

    expect(recommendations.every((recommendation) => recommendation.source === "demo")).toBe(true);
    expect(recommendations.every((recommendation) => recommendation.score !== null)).toBe(true);
    expect(recommendationService.getForFood("salmon-quinoa-bowl")).toMatchObject({ source: "demo", score: 91 });
    expect([...candidateModels, ...ensembleApproaches].every((model) =>
      model.accuracy === null && model.precision === null && model.recall === null && model.f1 === null,
    )).toBe(true);
    expect(associationRules).toEqual([]);
  });
});
