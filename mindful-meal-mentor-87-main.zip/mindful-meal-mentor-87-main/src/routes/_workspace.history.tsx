import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { History, CalendarClock, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PageHeader, EmptyState, DemoBadge } from "@/components/common";
import { demoHistory } from "@/data/demoHistory";
import { foodDataService } from "@/services/food-data-service";
import { pageMeta } from "@/lib/seo";
import { formatNutrient } from "@/lib/portion-calculations";
import type { RecommendationSession } from "@/types";

export const Route = createFileRoute("/_workspace/history")({
  head: () => pageMeta("Recommendation History", "Review your previous recommendation sessions."),
  component: HistoryPage,
});

const fmt = (d: string) => new Date(d).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });

function HistoryPage() {
  const [open, setOpen] = useState<RecommendationSession | null>(null);
  const sessions = demoHistory;
  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Timeline" title="Recommendation History" description="Previous recommendation sessions." actions={<DemoBadge label="Demo records" />} />
      {sessions.length === 0 ? (
        <EmptyState icon={History} title="No sessions yet" description="Generate your first recommendations to start a history." action={<Button variant="forest" asChild><Link to="/recommendations">Generate</Link></Button>} />
      ) : (
        <ol className="relative space-y-6 border-l border-dashed pl-8">
          {sessions.map((s) => (
            <li key={s.id} className="relative">
              <span className="absolute -left-[41px] top-6 size-4 rounded-full border-4 border-background bg-primary" />
              <div className="surface flex flex-col gap-5 p-5 md:flex-row md:items-center">
                <div className="flex-1">
                  <p className="flex items-center gap-1.5 text-xs text-muted-foreground"><CalendarClock className="size-3.5" /> {fmt(s.createdAt)}</p>
                  <p className="mt-2 flex items-center gap-2 font-display text-2xl text-forest"><Target className="size-4 text-primary" /> {s.goal}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{s.count} recommendations</p>
                </div>
                <div className="flex -space-x-3">
                  {s.foodIds.map((id) => { const f = foodDataService.getById(id); return f && f.image && <img key={id} src={f.image} alt={f.name} title={f.name} className="size-12 rounded-full border-2 border-card object-cover" loading="lazy" />; })}
                </div>
                <Button variant="outline" size="sm" onClick={() => setOpen(s)}>View details</Button>
              </div>
            </li>
          ))}
        </ol>
      )}
      <Dialog open={!!open} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display text-2xl font-normal text-forest">{open?.goal} session</DialogTitle>
            <DialogDescription>{open && fmt(open.createdAt)} · demo record</DialogDescription>
          </DialogHeader>
          <ul className="divide-y">
            {open?.foodIds.map((id) => { const f = foodDataService.getById(id); return f && (
              <li key={id} className="flex items-center gap-3 py-3">
                {f.image && <img src={f.image} alt="" className="size-12 rounded-lg object-cover" />}
                <div className="flex-1"><p className="text-sm font-medium text-forest">{f.name}</p><p className="text-xs text-muted-foreground">{formatNutrient(f.nutrition.caloriesKcal, " kcal")} · {formatNutrient(f.nutrition.proteinG, " g protein")}</p></div>
                <Link to="/foods/$foodId" params={{ foodId: f.id }} className="text-xs text-primary">View</Link>
              </li>
            ); })}
          </ul>
        </DialogContent>
      </Dialog>
    </div>
  );
}
