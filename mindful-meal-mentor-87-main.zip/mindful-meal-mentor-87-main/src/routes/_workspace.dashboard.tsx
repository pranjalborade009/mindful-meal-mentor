import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles, Target, Activity, Bookmark, History } from "lucide-react";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { Button } from "@/components/ui/button";
import { PageHeader, SectionCard, DemoBadge, EmptyState } from "@/components/common";
import { FoodCard } from "@/components/food/FoodCard";
import { foodDataService } from "@/services/food-data-service";
import { demoHistory, demoProfile } from "@/data/demoHistory";
import { useSavedFoods } from "@/hooks/use-saved-foods";
import { pageMeta } from "@/lib/seo";
import { formatNutrient } from "@/lib/portion-calculations";

export const Route = createFileRoute("/_workspace/dashboard")({
  head: () => pageMeta("Daily Progress", "Your nutrition overview, goals, and progress across meals, habits, and food choices."),
  component: Dashboard,
});

function Dashboard() {
  const foods = foodDataService.getAll();
  const { saved } = useSavedFoods();
  const t = demoProfile.targets;
  const targets = [
    { name: "Protein", value: t.proteinG ?? 0 },
    { name: "Carbs", value: t.carbohydrateG ?? 0 },
    { name: "Fat", value: t.fatG ?? 0 },
  ];
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Overview"
        title="Good evening, Demo User"
        description="A quick view of your nutrition goals, meal plan, and progress for the day."
        actions={<Button variant="forest" asChild><Link to="/recommendations"><Sparkles /> Build Meal Plan</Link></Button>}
      />

      <div className="flex justify-end"><DemoBadge label="Demo data — no real user analyzed" /></div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { icon: Target, label: "Current goal", value: demoProfile.goal },
          { icon: Activity, label: "Activity level", value: demoProfile.activity },
          { icon: Sparkles, label: "Daily calorie target", value: `${t.caloriesKcal} kcal` },
          { icon: Bookmark, label: "Saved foods", value: String(saved.length) },
        ].map(({ icon: Icon, label, value }) => (
          <div key={label} className="surface p-5">
            <Icon className="size-4 text-primary" />
            <p className="mt-4 text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
            <p className="mt-1 font-display text-2xl text-forest">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <SectionCard title="Nutritional targets" subtitle="Grams per day, from your profile" className="lg:col-span-1">
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={targets} margin={{ left: -20 }}>
                <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} />
                <YAxis tickLine={false} axisLine={false} fontSize={11} />
                <Tooltip cursor={{ fill: "var(--color-muted)" }} />
                <Bar dataKey="value" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
        <SectionCard title="Profile summary" subtitle="Edit anytime in My Profile" className="lg:col-span-2">
          <dl className="grid grid-cols-2 gap-4 text-sm sm:grid-cols-3">
            {[
              ["Age", `${demoProfile.age} yrs`], ["Height", `${demoProfile.heightCm} cm`], ["Weight", `${demoProfile.weightKg} kg`],
              ["Diet", demoProfile.diet], ["Cuisines", demoProfile.cuisines.join(", ")], ["Budget", demoProfile.budget],
            ].map(([k, v]) => (
              <div key={k}><dt className="text-xs text-muted-foreground">{k}</dt><dd className="mt-0.5 font-medium text-forest">{v}</dd></div>
            ))}
          </dl>
          <Button variant="outline" size="sm" className="mt-6" asChild><Link to="/profile">Edit profile</Link></Button>
        </SectionCard>
      </div>

      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-2xl">Recommendation preview</h2>
          <Link to="/recommendations" className="inline-flex items-center gap-1 text-sm text-primary hover:text-forest">See all <ArrowRight className="size-4" /></Link>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {foods.slice(0, 3).map((f) => <FoodCard key={f.id} food={f} showReason />)}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Recently saved">
          {saved.length === 0 ? (
            <EmptyState icon={Bookmark} title="No saved foods" description="Save foods you like to find them here." action={<Button variant="outline" size="sm" asChild><Link to="/explorer">Browse foods</Link></Button>} />
          ) : (
            <ul className="divide-y">
              {saved.slice(0, 4).map((id) => { const f = foodDataService.getById(id); return f && (
                <li key={id} className="flex items-center gap-3 py-3">
                  {f.image && <img src={f.image} alt="" className="size-11 rounded-lg object-cover" loading="lazy" />}
                  <div className="flex-1"><p className="text-sm font-medium text-forest">{f.name}</p><p className="text-xs text-muted-foreground">{formatNutrient(f.nutrition.caloriesKcal, " kcal")} · {formatNutrient(f.nutrition.proteinG, " g protein")}</p></div>
                  <Link to="/foods/$foodId" params={{ foodId: f.id }} className="text-xs text-primary">View</Link>
                </li>
              ); })}
            </ul>
          )}
        </SectionCard>
        <SectionCard title="Recent sessions">
          <ul className="divide-y">
            {demoHistory.map((s) => (
              <li key={s.id} className="flex items-center gap-3 py-3">
                <span className="grid size-10 place-items-center rounded-lg bg-sage text-forest"><History className="size-4" /></span>
                <div className="flex-1"><p className="text-sm font-medium text-forest">{s.goal}</p><p className="text-xs text-muted-foreground">{new Date(s.createdAt).toLocaleDateString("en-IN", { dateStyle: "medium" })} · {s.count} foods</p></div>
                <Link to="/history" className="text-xs text-primary">Open</Link>
              </li>
            ))}
          </ul>
        </SectionCard>
      </div>
    </div>
  );
}
