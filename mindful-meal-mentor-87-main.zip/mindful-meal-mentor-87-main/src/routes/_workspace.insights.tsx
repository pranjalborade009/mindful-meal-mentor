import { createFileRoute } from "@tanstack/react-router";
import { Database, Wand2, Layers, GitBranch, Boxes, Network, Scale, ArrowRight, ShieldCheck, FileQuestion } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageHeader, SectionCard, ChartPlaceholder, EmptyState } from "@/components/common";
import { candidateModels, ensembleApproaches, associationRules, plannedFeatures, pipelineSteps } from "@/data/demoMetrics";
import type { MLModelMetrics } from "@/types";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/_workspace/insights")({
  head: () => pageMeta("Nutrition Insights", "A simple overview of nutrition trends, food balance, and the progress signals behind your plan."),
  component: InsightsPage,
});

const Pending = () => <span className="font-mono text-xs text-muted-foreground">—</span>;

function MetricTable({ rows }: { rows: MLModelMetrics[] }) {
  const cell = (v: number | null) => (v == null ? <Pending /> : v.toFixed(3));
  return (
    <div className="overflow-x-auto rounded-lg border">
      <Table>
        <TableHeader className="bg-muted/60">
          <TableRow>{["Algorithm", "Accuracy", "Precision", "Recall", "F1-score", "Status"].map((h) => <TableHead key={h} className="text-xs uppercase tracking-wider">{h}</TableHead>)}</TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((r) => (
            <TableRow key={r.algorithm}>
              <TableCell className="font-medium text-forest">{r.algorithm}</TableCell>
              <TableCell>{cell(r.accuracy)}</TableCell><TableCell>{cell(r.precision)}</TableCell>
              <TableCell>{cell(r.recall)}</TableCell><TableCell>{cell(r.f1)}</TableCell>
              <TableCell><span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">{r.status}</span></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

const stages = [
  { icon: Database, label: "Dataset" }, { icon: Wand2, label: "Preprocessing" }, { icon: Layers, label: "Features" },
  { icon: GitBranch, label: "Classification" }, { icon: Boxes, label: "Clustering" }, { icon: Network, label: "Ranking" },
];

function InsightsPage() {
  return (
    <div className="space-y-10">
      <PageHeader eyebrow="Progress overview" title="Nutrition Insights"
        description="A place to review food balance, nutrition patterns, and plan health signals without exposing technical model details." />

      {/* Pipeline hero */}
      <section className="relative overflow-hidden rounded-[1.75rem] bg-forest p-6 text-forest-foreground md:p-10">
        <div className="absolute inset-0 dot-grid opacity-20" aria-hidden />
        <div className="relative">
          <p className="eyebrow text-lime">End-to-end methodology</p>
          <h2 className="mt-3 max-w-2xl font-display text-3xl text-forest-foreground md:text-4xl">From raw nutritional data to explainable, personalized recommendations.</h2>
          <div className="mt-10 grid grid-cols-3 gap-3 md:grid-cols-6">
            {stages.map(({ icon: Icon, label }, i) => (
              <div key={label} className="group relative rounded-xl border border-forest-foreground/15 p-4 transition-colors hover:bg-forest-foreground/5">
                <span className="font-mono text-[0.65rem] opacity-50">0{i + 1}</span>
                <Icon className="mt-3 size-5 text-lime" />
                <p className="mt-2 text-sm">{label}</p>
              </div>
            ))}
          </div>
          <p className="mt-6 inline-flex items-center gap-2 rounded-full bg-forest-foreground/10 px-3 py-1.5 text-xs"><ShieldCheck className="size-3.5 text-lime" /> No fabricated results — values appear only after experiments run.</p>
        </div>
      </section>

      <Tabs defaultValue="data" className="space-y-6">
        <TabsList className="h-auto flex-wrap justify-start gap-1 rounded-full bg-sage/60 p-1">
          {[["data", "Dataset & EDA"], ["prep", "Preprocessing"], ["supervised", "Supervised"], ["ensemble", "Ensemble"], ["clustering", "Clustering"], ["rules", "Association rules"], ["engine", "Recommendation engine"]].map(([v = "", l]) => (
            <TabsTrigger key={v} value={v} className="rounded-full px-4 data-[state=active]:bg-forest data-[state=active]:text-forest-foreground">{l}</TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="data" className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {["Food records", "Features", "Missing values", "Target classes"].map((k) => (
              <div key={k} className="surface p-5"><p className="text-xs uppercase tracking-wider text-muted-foreground">{k}</p><p className="mt-2 font-display text-3xl text-muted-foreground/60">—</p><p className="mt-1 text-xs text-muted-foreground">From dataset loader</p></div>
            ))}
          </div>
          <div className="grid gap-6 lg:grid-cols-2">
            <SectionCard title="Nutrient distributions" subtitle="Histogram per feature"><ChartPlaceholder label="Distributions" /></SectionCard>
            <SectionCard title="Correlation heatmap" subtitle="Pearson correlation between nutrients"><ChartPlaceholder label="Correlation matrix" /></SectionCard>
          </div>
        </TabsContent>

        <TabsContent value="prep" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <SectionCard title="Preprocessing steps" subtitle="Planned pipeline">
              <ol className="space-y-3 text-sm">
                {["Handle missing values", "Remove duplicates & outliers", "Encode categorical attributes", "Scale numerical features (standardization)", "Train / test split with stratification"].map((s, i) => (
                  <li key={s} className="flex items-center gap-3"><span className="grid size-6 place-items-center rounded-full bg-sage font-mono text-xs text-forest">{i + 1}</span>{s}</li>
                ))}
              </ol>
            </SectionCard>
            <SectionCard title="Feature engineering" subtitle="Planned feature examples — not yet computed">
              <ul className="divide-y text-sm">{plannedFeatures.map((f) => <li key={f.name} className="flex justify-between py-2.5"><span className="font-medium text-forest">{f.name}</span><span className="text-muted-foreground">{f.note}</span></li>)}</ul>
            </SectionCard>
          </div>
        </TabsContent>

        <TabsContent value="supervised" className="space-y-6">
          <SectionCard title="Model comparison" subtitle="Candidate algorithms — metrics pending experiments"><MetricTable rows={candidateModels} /></SectionCard>
          <div className="grid gap-6 lg:grid-cols-2">
            <SectionCard title="Confusion matrix" subtitle="Best model on held-out test set"><ChartPlaceholder label="Confusion matrix" height={220} /></SectionCard>
            <SectionCard title="Feature importance" subtitle="When supported by the model"><ChartPlaceholder label="Feature importance" height={220} /></SectionCard>
          </div>
        </TabsContent>

        <TabsContent value="ensemble" className="space-y-6">
          <SectionCard title="Individual vs ensemble" subtitle="No claim of improvement without experimental evidence"><MetricTable rows={ensembleApproaches} /></SectionCard>
          <SectionCard title="Comparison chart"><ChartPlaceholder label="Ensemble comparison" height={220} /></SectionCard>
        </TabsContent>

        <TabsContent value="clustering" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <SectionCard title="Elbow method" subtitle="Inertia vs. number of clusters (k)"><ChartPlaceholder label="Elbow curve" /></SectionCard>
            <SectionCard title="Silhouette scores" subtitle="Compare k values"><ChartPlaceholder label="Silhouette comparison" /></SectionCard>
            <SectionCard title="2-D cluster visualization" subtitle="PCA projection of K-Means clusters"><ChartPlaceholder label="Cluster scatter" height={220} /></SectionCard>
            <SectionCard title="Cluster distribution" subtitle="Labels come from actual data"><ChartPlaceholder label="Cluster sizes" height={220} /></SectionCard>
          </div>
        </TabsContent>

        <TabsContent value="rules">
          <SectionCard title="Apriori association rules" subtitle="Support · Confidence · Lift">
            {associationRules.length === 0 ? (
              <EmptyState icon={FileQuestion} title="Data not available" description="Association rule mining requires ingredient-combination or transaction-style data. Rules will appear here only if suitable data exists." />
            ) : null}
          </SectionCard>
        </TabsContent>

        <TabsContent value="engine" className="space-y-6">
          <SectionCard title="Personalized recommendation flow">
            <div className="flex flex-wrap items-center gap-2">
              {pipelineSteps.map((s, i) => (
                <div key={s} className="flex items-center gap-2">
                  <span className={i === 2 ? "rounded-full bg-lime px-4 py-2 text-sm font-medium text-lime-foreground" : i === pipelineSteps.length - 1 ? "rounded-full bg-forest px-4 py-2 text-sm text-forest-foreground" : "rounded-full border bg-card px-4 py-2 text-sm text-forest"}>{s}</span>
                  {i < pipelineSteps.length - 1 && <ArrowRight className="size-4 text-muted-foreground" />}
                </div>
              ))}
            </div>
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <div className="rounded-lg bg-muted/70 p-4 text-sm"><p className="flex items-center gap-2 font-semibold text-forest"><ShieldCheck className="size-4" /> Stage 1 — Hard constraints</p><p className="mt-1 text-muted-foreground">Diet type, allergies and intolerances remove ineligible foods entirely. Nothing excluded here can be ranked.</p></div>
              <div className="rounded-lg bg-muted/70 p-4 text-sm"><p className="flex items-center gap-2 font-semibold text-forest"><Scale className="size-4" /> Stage 2 — Ranking</p><p className="mt-1 text-muted-foreground">Remaining foods are scored by similarity (e.g. cosine) between the user requirement vector and each food's feature vector.</p></div>
            </div>
          </SectionCard>
          <SectionCard title="Experiment notes" subtitle="Record observations for the viva"><ChartPlaceholder label="Experiment log" height={120} /></SectionCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}
