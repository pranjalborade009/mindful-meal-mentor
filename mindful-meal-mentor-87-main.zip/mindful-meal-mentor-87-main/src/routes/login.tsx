import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { AuthLayout, Field } from "@/components/layout/AuthLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log in — NUTRIFY" },
      { name: "description", content: "Log in to NUTRIFY to continue your nutrition plan, meal tracking, and food discovery." },
      { property: "og:title", content: "Log in — NUTRIFY" },
      { property: "og:description", content: "Log in to NUTRIFY to continue your nutrition plan, meal tracking, and food discovery." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const [show, setShow] = useState(false);
  const [email, setEmail] = useState("");
  const [err, setErr] = useState<string>();
  const navigate = useNavigate();
  return (
    <AuthLayout title="Welcome back" subtitle="Log in to continue to your nutrition workspace.">
      <form
        className="space-y-5"
        onSubmit={(e) => {
          e.preventDefault();
          if (!email.includes("@")) return setErr("Enter a valid email address.");
          setErr(undefined);
          toast("Demo login", { description: "No credentials were checked or stored." });
          navigate({ to: "/dashboard" });
        }}
      >
        <Field id="email" label="Email" error={err}>
          <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 bg-card" />
        </Field>
        <Field id="password" label="Password" hint={<Link to="/forgot-password" className="text-xs text-primary hover:underline">Forgot password?</Link>}>
          <div className="relative">
            <Input id="password" type={show ? "text" : "password"} placeholder="••••••••" className="h-11 bg-card pr-10" />
            <button type="button" onClick={() => setShow(!show)} aria-label={show ? "Hide password" : "Show password"} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-forest">
              {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </Field>
        <label className="flex items-center gap-2 text-sm text-muted-foreground"><Checkbox /> Remember me</label>
        <Button type="submit" variant="forest" size="lg" className="w-full">Log in</Button>
        <p className="text-center text-sm text-muted-foreground">New to NUTRIFY? <Link to="/register" className="font-medium text-primary hover:underline">Create an account</Link></p>
      </form>
    </AuthLayout>
  );
}
