import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Sparkles, Info, SearchX } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader, DemoBadge, EmptyState } from "@/components/common";
import { FoodCard } from "@/components/food/FoodCard";
import { FilterSelect, SortSelect, useFoodFilter } from "@/components/food/FoodFilters";
import { demoProfile } from "@/data/demoHistory";
import { foodDataService } from "@/services/food-data-service";
import { recommendationService } from "@/services/recommendation-service";
import type { Food } from "@/types";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/_workspace/recommendations")({
  head: () => pageMeta("Meal Planner", "Personalized meal ideas shaped around your goals, diet, and food preferences."),
  component: RecommendationsPage,
});

function RecommendationsPage() {
  const recommendationFoods = recommendationService.getRecommendations()
    .map(({ foodId }) => foodDataService.getById(foodId))
    .filter((food): food is Food => food !== undefined);
  const { f, setF, results, reset } = useFoodFilter(recommendationFoods);
  const [loading, setLoading] = useState(false);
  const generate = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); toast("Sample set refreshed", { description: "Prototype only — the ML engine is not connected yet." }); }, 1200);
  };
  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Meal planning" title="Meal Planner"
        description="Foods that fit your goals and dietary preferences, tailored to your daily routine."
        actions={<Button variant="forest" onClick={generate} disabled={loading}><Sparkles /> {loading ? "Planning…" : "Build Meal Plan"}</Button>} />

      <div className="grid gap-4 rounded-xl bg-forest p-5 text-forest-foreground md:grid-cols-4">
        {[["Goal", demoProfile.goal], ["Diet", demoProfile.diet], ["Calories", `${demoProfile.targets.caloriesKcal} kcal`], ["Protein", `${demoProfile.targets.proteinG} g`]].map(([k, v]) => (
          <div key={k}><p className="text-[0.68rem] uppercase tracking-widest opacity-60">{k}</p><p className="mt-1 font-display text-xl">{v}</p></div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="w-40"><FilterSelect value={f.meal} onChange={(v) => setF({ ...f, meal: v })} placeholder="Meals" options={["Breakfast", "Lunch", "Dinner", "Snack"]} /></div>
        <div className="w-44"><FilterSelect value={f.cuisine} onChange={(v) => setF({ ...f, cuisine: v })} placeholder="Cuisines" options={foodDataService.getCuisines()} /></div>
        <div className="w-44"><FilterSelect value={f.diet} onChange={(v) => setF({ ...f, diet: v })} placeholder="Diets" options={["Vegetarian", "Non-vegetarian", "Vegan"]} /></div>
        <div className="ml-auto"><SortSelect value={f.sort} onChange={(v) => setF({ ...f, sort: v })} /></div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground">
        <p className="flex items-center gap-1.5"><Info className="size-4" /> Meal-fit scores are sample suggestions only and should be treated as placeholders.</p>
        <DemoBadge />
      </div>

      {loading ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="surface overflow-hidden"><Skeleton className="aspect-[5/4] rounded-none" /><div className="space-y-2 p-4"><Skeleton className="h-3 w-24" /><Skeleton className="h-5 w-40" /><Skeleton className="h-12 w-full" /></div></div>)}
        </div>
      ) : results.length === 0 ? (
        <EmptyState icon={SearchX} title="No foods match these filters" description="Try widening your filters." action={<Button variant="outline" onClick={reset}>Reset filters</Button>} />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{results.map((x) => <FoodCard key={x.id} food={x} showReason />)}</div>
      )}

      <p className="text-center text-xs text-muted-foreground">Want to review your nutrition context? <Link to="/insights" className="text-primary hover:underline">Open Nutrition Insights</Link></p>
    </div>
  );
}
