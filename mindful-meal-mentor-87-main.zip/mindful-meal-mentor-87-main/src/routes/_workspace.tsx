import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";

// Pathless layout for the application workspace (sidebar + content).
export const Route = createFileRoute("/_workspace")({
  component: AppShell,
});
