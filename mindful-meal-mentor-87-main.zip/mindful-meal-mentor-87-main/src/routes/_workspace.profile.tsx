import { createFileRoute } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Save } from "lucide-react";
import { PageHeader } from "@/components/common";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { demoProfile } from "@/data/demoHistory";
import { foodDataService } from "@/services/food-data-service";
import { cn } from "@/lib/utils";
import { pageMeta } from "@/lib/seo";
import type { UserProfile } from "@/types";

export const Route = createFileRoute("/_workspace/profile")({
  head: () => pageMeta("Your Goals", "Set goals, dietary preferences, constraints, and nutrition targets that shape your plan."),
  component: ProfilePage,
});

function Section({ title, desc, children }: { title: string; desc: string; children: ReactNode }) {
  return (
    <section className="grid gap-6 border-b py-8 md:grid-cols-[240px_1fr]">
      <div><h2 className="text-base font-semibold text-forest">{title}</h2><p className="mt-1 text-sm text-muted-foreground">{desc}</p></div>
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </section>
  );
}

function F({ label, unit, children, full }: { label: string; unit?: string; children: ReactNode; full?: boolean }) {
  return (
    <label className={cn("space-y-1.5", full && "sm:col-span-2")}>
      <span className="flex justify-between text-sm font-medium text-forest">{label}{unit && <span className="text-xs font-normal text-muted-foreground">{unit}</span>}</span>
      {children}
    </label>
  );
}

function Chips<T extends string>({ options, value, onChange, multi }: { options: T[]; value: T[]; onChange: (v: T[]) => void; multi?: boolean }) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((o) => {
        const on = value.includes(o);
        return (
          <button type="button" key={o} aria-pressed={on}
            onClick={() => onChange(multi ? (on ? value.filter((x) => x !== o) : [...value, o]) : [o])}
            className={cn("rounded-full border px-3.5 py-1.5 text-sm transition-colors", on ? "border-forest bg-forest text-forest-foreground" : "bg-card text-muted-foreground hover:border-primary hover:text-forest")}
          >{o}</button>
        );
      })}
    </div>
  );
}

function ProfilePage() {
  const [p, setP] = useState<UserProfile>(demoProfile);
  const set = <K extends keyof UserProfile>(k: K, v: UserProfile[K]) => setP((s) => ({ ...s, [k]: v }));
  const num = (v: string) => (v === "" ? undefined : Number(v));
  return (
    <form onSubmit={(e) => { e.preventDefault(); toast("Profile saved locally (demo)", { description: "Backend persistence comes in a later phase." }); }}>
      <PageHeader eyebrow="Settings" title="Your Goals" description="These inputs help shape your nutrition plan. All fields are optional unless noted. NUTRIFY supports nutrition planning and does not diagnose or prescribe medical treatment."
        actions={<Button type="submit" variant="forest"><Save /> Save Profile</Button>} />

      <Section title="Personal information" desc="Basic body measurements.">
        <F label="Age" unit="years"><Input type="number" value={p.age ?? ""} onChange={(e) => set("age", num(e.target.value))} className="bg-card" /></F>
        <F label="Activity level">
          <Select value={p.activity} onValueChange={(v) => set("activity", v as UserProfile["activity"])}>
            <SelectTrigger className="bg-card"><SelectValue /></SelectTrigger>
            <SelectContent>{["Sedentary", "Light", "Moderate", "Active"].map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
          </Select>
        </F>
        <F label="Height" unit="cm"><Input type="number" value={p.heightCm ?? ""} onChange={(e) => set("heightCm", num(e.target.value))} className="bg-card" /></F>
        <F label="Weight" unit="kg"><Input type="number" value={p.weightKg ?? ""} onChange={(e) => set("weightKg", num(e.target.value))} className="bg-card" /></F>
      </Section>

      <Section title="Goal" desc="What should recommendations support?">
        <F label="Primary goal" full><Chips options={["Weight loss", "Weight maintenance", "Weight gain"] as UserProfile["goal"][]} value={[p.goal]} onChange={(v) => v[0] && set("goal", v[0])} /></F>
      </Section>

      <Section title="Dietary preference" desc="Used as a hard filter before ranking.">
        <F label="Diet type" full><Chips options={["Vegetarian", "Non-vegetarian", "Vegan"] as UserProfile["diet"][]} value={[p.diet]} onChange={(v) => v[0] && set("diet", v[0])} /></F>
      </Section>

      <Section title="Food preferences" desc="Soft preferences that influence ranking.">
        <F label="Cuisines" full><Chips multi options={foodDataService.getCuisines()} value={p.cuisines} onChange={(v) => set("cuisines", v)} /></F>
        <F label="Budget"><Input value={p.budget ?? ""} onChange={(e) => set("budget", e.target.value)} placeholder="e.g. ₹150–₹300 per meal" className="bg-card" /></F>
        <F label="Meal preferences"><Input placeholder="e.g. light dinners" className="bg-card" /></F>
        <F label="Likes"><Textarea value={p.likes ?? ""} onChange={(e) => set("likes", e.target.value)} className="bg-card" /></F>
        <F label="Dislikes"><Textarea value={p.dislikes ?? ""} onChange={(e) => set("dislikes", e.target.value)} className="bg-card" /></F>
      </Section>

      <Section title="Dietary constraints" desc="Foods containing these are excluded.">
        <F label="Allergies"><Input value={p.allergies ?? ""} onChange={(e) => set("allergies", e.target.value)} placeholder="e.g. peanuts" className="bg-card" /></F>
        <F label="Intolerances"><Input placeholder="e.g. lactose" className="bg-card" /></F>
      </Section>

      <Section title="Nutritional targets" desc="Enter your own daily targets. NUTRIFY helps you monitor and plan around them.">
        {(["caloriesKcal", "proteinG", "carbohydrateG", "fatG"] as const).map((k) => (
          <F key={k} label={{ caloriesKcal: "Calories", proteinG: "Protein", carbohydrateG: "Carbohydrates", fatG: "Fat" }[k]} unit={k === "caloriesKcal" ? "kcal / day" : "g / day"}>
            <Input type="number" value={p.targets[k] ?? ""} onChange={(e) => set("targets", { ...p.targets, [k]: num(e.target.value) })} className="bg-card" />
          </F>
        ))}
      </Section>

      <div className="flex justify-end pt-6"><Button type="submit" variant="forest" size="lg"><Save /> Save Profile</Button></div>
    </form>
  );
}
