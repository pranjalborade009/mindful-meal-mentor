import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { MailCheck, ArrowLeft } from "lucide-react";
import { AuthLayout, Field } from "@/components/layout/AuthLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Reset password — NUTRIFY" },
      { name: "description", content: "Request a password reset link for your NUTRIFY account." },
      { property: "og:title", content: "Reset password — NUTRIFY" },
      { property: "og:description", content: "Request a password reset link for your NUTRIFY account." },
    ],
  }),
  component: ForgotPage,
});

function ForgotPage() {
  const [sent, setSent] = useState(false);
  return (
    <AuthLayout title="Forgot password?" subtitle="Enter the email linked to your account and we'll send a reset link.">
      {sent ? (
        <div className="rounded-xl border bg-card p-6 text-center">
          <MailCheck className="mx-auto size-8 text-primary" />
          <p className="mt-3 font-medium text-forest">Demo: reset link not actually sent</p>
          <p className="mt-1 text-sm text-muted-foreground">Email delivery will be added in a later phase.</p>
        </div>
      ) : (
        <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
          <Field id="email" label="Email address"><Input id="email" type="email" required placeholder="you@example.com" className="h-11 bg-card" /></Field>
          <Button type="submit" variant="forest" size="lg" className="w-full">Send Reset Link</Button>
        </form>
      )}
      <Link to="/login" className="mt-6 inline-flex items-center gap-1.5 text-sm text-primary hover:underline"><ArrowLeft className="size-4" /> Return to login</Link>
    </AuthLayout>
  );
}
