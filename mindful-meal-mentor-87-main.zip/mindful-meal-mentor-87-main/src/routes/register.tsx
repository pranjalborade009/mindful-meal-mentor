import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { AuthLayout, Field } from "@/components/layout/AuthLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Create account — NUTRIFY" },
      { name: "description", content: "Create a NUTRIFY account to build your nutrition goals and personalized meal plan." },
      { property: "og:title", content: "Create account — NUTRIFY" },
      { property: "og:description", content: "Create a NUTRIFY account to build your nutrition goals and personalized meal plan." },
    ],
  }),
  component: RegisterPage,
});

function RegisterPage() {
  const [show, setShow] = useState(false);
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [terms, setTerms] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const navigate = useNavigate();
  return (
    <AuthLayout title="Create your account" subtitle="Start building your nutrition profile.">
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          const next: Record<string, string> = {};
          if (pw.length < 8) next["pw"] = "Use at least 8 characters.";
          if (pw !== pw2) next["pw2"] = "Passwords do not match.";
          if (!terms) next["terms"] = "Please accept the terms to continue.";
          setErrors(next);
          if (Object.keys(next).length) return;
          toast("Demo account created", { description: "Nothing was stored — registration comes in a later phase." });
          navigate({ to: "/profile" });
        }}
      >
        <Field id="name" label="Full name"><Input id="name" placeholder="Your name" className="h-11 bg-card" /></Field>
        <Field id="email" label="Email"><Input id="email" type="email" placeholder="you@example.com" className="h-11 bg-card" /></Field>
        <Field id="pw" label="Password" error={errors["pw"]}>
          <div className="relative">
            <Input id="pw" type={show ? "text" : "password"} value={pw} onChange={(e) => setPw(e.target.value)} className="h-11 bg-card pr-10" />
            <button type="button" onClick={() => setShow(!show)} aria-label={show ? "Hide password" : "Show password"} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-forest">
              {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </Field>
        <Field id="pw2" label="Confirm password" error={errors["pw2"]}>
          <Input id="pw2" type={show ? "text" : "password"} value={pw2} onChange={(e) => setPw2(e.target.value)} className="h-11 bg-card" />
        </Field>
        <div>
          <label className="flex items-start gap-2 text-sm text-muted-foreground">
            <Checkbox checked={terms} onCheckedChange={(v) => setTerms(!!v)} className="mt-0.5" />
            I agree to the terms and understand recommendations are informational only.
          </label>
          {errors["terms"] && <p className="mt-1 text-xs text-destructive">{errors["terms"]}</p>}
        </div>
        <Button type="submit" variant="forest" size="lg" className="w-full">Create Account</Button>
        <p className="text-center text-sm text-muted-foreground">Already have an account? <Link to="/login" className="font-medium text-primary hover:underline">Log in</Link></p>
      </form>
    </AuthLayout>
  );
}
