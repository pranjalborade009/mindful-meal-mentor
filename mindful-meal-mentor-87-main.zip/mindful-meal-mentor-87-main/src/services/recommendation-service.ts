import { demoRecommendations } from "@/data/demoRecommendations";
import type { Recommendation } from "@/types";

/** Demo-only source until a real recommendation API is available. */
export const recommendationService = {
  getRecommendations(): Recommendation[] {
    return demoRecommendations;
  },
  getForFood(foodId: string): Recommendation | undefined {
    return demoRecommendations.find((recommendation) => recommendation.foodId === foodId);
  },
};
