import { ASSESSMENT_STEPS, createEmptyAssessmentForm } from "@/lib/assessment-validation";
import type { AssessmentDraft, AssessmentFormState } from "@/types";

const STORAGE_KEY = "nutrify-assessment-draft-v1";

const goals = ["weight-loss", "weight-gain", "maintenance"] as const;
const activityLevels = ["sedentary", "light", "moderate", "high"] as const;
const dietaryPatterns = ["omnivore", "vegetarian", "eggetarian", "pescatarian", "vegan", "other"] as const;
const cookingPreferences = ["home-cooking", "quick-meals", "minimal-cooking", "mix"] as const;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isOneOf<const Values extends readonly string[]>(values: Values, candidate: unknown): candidate is Values[number] {
  return typeof candidate === "string" && values.some((value) => value === candidate);
}

export function loadAssessmentDraft(): AssessmentDraft | null {
  if (typeof window === "undefined") return null;

  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return null;

    const parsed: unknown = JSON.parse(stored);
    if (!isRecord(parsed) || parsed["version"] !== 1 || !isRecord(parsed["form"])) return null;

    const values = parsed["form"];
    const form = createEmptyAssessmentForm();
    if (typeof values["age"] === "string") form.age = values["age"];
    if (typeof values["heightCm"] === "string") form.heightCm = values["heightCm"];
    if (typeof values["weightKg"] === "string") form.weightKg = values["weightKg"];
    if (isOneOf(goals, values["goal"])) form.goal = values["goal"];
    if (isOneOf(activityLevels, values["activityLevel"])) form.activityLevel = values["activityLevel"];
    if (isOneOf(dietaryPatterns, values["dietaryPattern"])) form.dietaryPattern = values["dietaryPattern"];
    if (typeof values["favoriteFoods"] === "string") form.favoriteFoods = values["favoriteFoods"];
    if (typeof values["dislikedFoods"] === "string") form.dislikedFoods = values["dislikedFoods"];
    if (typeof values["budget"] === "string") form.budget = values["budget"];
    if (isOneOf(cookingPreferences, values["cookingPreference"])) form.cookingPreference = values["cookingPreference"];

    if (Array.isArray(values["preferredCuisines"])) {
      form.preferredCuisines = values["preferredCuisines"].filter((value): value is string => typeof value === "string");
    }
    if (Array.isArray(values["mealTimingPreferences"])) {
      form.mealTimingPreferences = values["mealTimingPreferences"].filter((value): value is string => typeof value === "string");
    }

    const draftStep = parsed["step"];
    const step = typeof draftStep === "number" && Number.isInteger(draftStep) && draftStep >= 0 && draftStep < ASSESSMENT_STEPS.length
      ? draftStep
      : 0;
    return { form, step };
  } catch {
    return null;
  }
}

export function saveAssessmentDraft(form: AssessmentFormState, step: number): void {
  if (typeof window === "undefined") return;

  const {
    allergies: _allergies,
    intolerances: _intolerances,
    healthConsiderations: _healthConsiderations,
    ...nonSensitiveForm
  } = form;
  const draft = { version: 1, step, form: nonSensitiveForm };

  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
  } catch {
    // Local draft storage is best-effort and must not block the assessment.
  }
}

export function clearAssessmentDraft(): void {
  if (typeof window === "undefined") return;

  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Storage may be unavailable in private or restricted browser contexts.
  }
}