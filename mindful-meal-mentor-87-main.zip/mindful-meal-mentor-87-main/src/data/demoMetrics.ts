import type { AssociationRule, MLModelMetrics } from "@/types";

/**
 * Candidate algorithms only. All metric values are null until the Python ML
 * pipeline supplies real results. Never hard-code fabricated numbers here.
 */
export const candidateModels: MLModelMetrics[] = [
  "K-Nearest Neighbors", "Decision Tree", "Support Vector Machine", "Naive Bayes", "Random Forest",
].map((algorithm) => ({ algorithm, family: "Supervised", accuracy: null, precision: null, recall: null, f1: null, status: "Pending" }));

export const ensembleApproaches: MLModelMetrics[] = ["Voting", "Bagging", "Boosting", "Stacking"].map((algorithm) => ({
  algorithm, family: "Ensemble", accuracy: null, precision: null, recall: null, f1: null, status: "Pending",
}));

/** Empty until suitable transaction-style data exists. */
export const associationRules: AssociationRule[] = [];

export const plannedFeatures = [
  { name: "Calorie density", note: "kcal per 100 g" },
  { name: "Protein density", note: "g protein per 100 kcal" },
  { name: "Macronutrient ratios", note: "P : C : F split" },
  { name: "Fiber ratio", note: "g fiber per serving" },
  { name: "User requirement features", note: "targets vs. food vector" },
];

export const pipelineSteps = [
  "User Profile", "Feature Engineering", "Dietary Constraint Filtering",
  "Feature Similarity", "Personalized Ranking", "Recommended Foods",
];
