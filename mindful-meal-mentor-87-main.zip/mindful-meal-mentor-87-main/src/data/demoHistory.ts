import type { RecommendationSession, UserProfile } from "@/types";

/** DEMO DATA — sample sessions; will come from the database later. */
export const demoHistory: RecommendationSession[] = [
  { id: "s-104", createdAt: "2026-10-08T19:42:00", goal: "Weight loss", count: 8, foodIds: ["grilled-chicken-plate", "lentil-salad", "paneer-tikka", "moong-chilla"] },
  { id: "s-103", createdAt: "2026-10-05T08:15:00", goal: "Weight loss", count: 6, foodIds: ["greek-yogurt-bowl", "moong-chilla", "tofu-stir-fry"] },
  { id: "s-102", createdAt: "2026-09-29T13:05:00", goal: "Weight maintenance", count: 10, foodIds: ["salmon-quinoa-bowl", "millet-khichdi", "lentil-salad"] },
];

/** DEMO DATA — sample profile used to populate the prototype. */
export const demoProfile: UserProfile = {
  age: 24, heightCm: 168, weightKg: 70, activity: "Moderate", goal: "Weight loss", diet: "Vegetarian",
  cuisines: ["Indian", "Mediterranean"], budget: "₹150–₹300 per meal", likes: "Paneer, lentils",
  dislikes: "Mushrooms", allergies: "None",
  targets: { caloriesKcal: 1800, proteinG: 90, carbohydrateG: 200, fatG: 60 },
};
