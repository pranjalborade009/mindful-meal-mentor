import type { Recommendation } from "@/types";

/** Illustrative prototype scores only; these are not outputs from a trained model. */
export const demoRecommendations: Recommendation[] = [
  {
    foodId: "salmon-quinoa-bowl",
    score: 91,
    scoreUnit: "percent",
    reason: "High protein density with balanced fats.",
    source: "demo",
  },
  {
    foodId: "paneer-tikka",
    score: 86,
    scoreUnit: "percent",
    reason: "Vegetarian protein source, low carbohydrate.",
    source: "demo",
  },
  {
    foodId: "greek-yogurt-bowl",
    score: 83,
    scoreUnit: "percent",
    reason: "Moderate calories, good morning protein.",
    source: "demo",
  },
  {
    foodId: "lentil-salad",
    score: 88,
    scoreUnit: "percent",
    reason: "Very high fiber, supports satiety.",
    source: "demo",
  },
  {
    foodId: "millet-khichdi",
    score: 79,
    scoreUnit: "percent",
    reason: "Whole-grain carbohydrates, familiar cuisine.",
    source: "demo",
  },
  {
    foodId: "tofu-stir-fry",
    score: 84,
    scoreUnit: "percent",
    reason: "Plant protein with complex carbohydrates.",
    source: "demo",
  },
  {
    foodId: "grilled-chicken-plate",
    score: 90,
    scoreUnit: "percent",
    reason: "Highest protein per calorie in sample set.",
    source: "demo",
  },
  {
    foodId: "moong-chilla",
    score: 81,
    scoreUnit: "percent",
    reason: "Low-fat, protein-rich vegan breakfast.",
    source: "demo",
  },
];
