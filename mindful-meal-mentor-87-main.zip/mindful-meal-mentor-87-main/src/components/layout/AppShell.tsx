import { Link, Outlet, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import {
  LayoutDashboard, UserRound, ClipboardList, Sparkles, Search, BrainCircuit, Bookmark, History, BookOpen, LogOut,
  PanelLeftClose, PanelLeftOpen, Menu,
} from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

const items = [
  { to: "/dashboard", label: "Daily Progress", icon: LayoutDashboard },
  { to: "/assessment", label: "Personal Assessment", icon: ClipboardList },
  { to: "/profile", label: "Your Goals", icon: UserRound },
  { to: "/recommendations", label: "Meal Planner", icon: Sparkles },
  { to: "/explorer", label: "Food Explorer", icon: Search },
  { to: "/insights", label: "Nutrition Insights", icon: BrainCircuit },
  { to: "/saved", label: "Saved Meals", icon: Bookmark },
  { to: "/diary", label: "Food Diary", icon: BookOpen },
  { to: "/history", label: "Recommendation History", icon: History },
] as const;

function NavList({ collapsed, onNavigate }: { collapsed?: boolean; onNavigate?: () => void }) {
  const navigate = useNavigate();
  return (
    <div className="flex h-full flex-col">
      <nav className="flex-1 space-y-1">
        {items.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            onClick={onNavigate}
            title={collapsed ? label : undefined}
            className={cn("flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-forest", collapsed && "justify-center px-0")}
            activeProps={{ className: "!bg-forest !text-forest-foreground [&_svg]:text-lime" }}
          >
            <Icon className="size-4 shrink-0" />
            {!collapsed && <span>{label}</span>}
          </Link>
        ))}
      </nav>
      <div className={cn("mt-4 flex items-center gap-3 border-t pt-4", collapsed && "flex-col")}>
        <span className="grid size-9 shrink-0 place-items-center rounded-full bg-sage text-sm font-semibold text-forest">DU</span>
        {!collapsed && (
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-forest">Demo User</p>
            <p className="truncate text-xs text-muted-foreground">Prototype session</p>
          </div>
        )}
        <button
          aria-label="Log out"
          onClick={() => { toast("Logged out (demo)", { description: "Authentication is not connected yet." }); navigate({ to: "/login" }); }}
          className="grid size-8 place-items-center rounded-md text-muted-foreground hover:bg-sidebar-accent hover:text-forest"
        >
          <LogOut className="size-4" />
        </button>
      </div>
    </div>
  );
}

export function AppShell() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div className="flex min-h-screen">
      <aside className={cn("sticky top-0 hidden h-screen shrink-0 flex-col border-r bg-sidebar p-4 transition-[width] duration-300 lg:flex", collapsed ? "w-[76px]" : "w-60")}>
        <div className={cn("mb-8 flex items-center", collapsed ? "justify-center" : "justify-between")}>
          <Logo compact={collapsed} />
          {!collapsed && (
            <button onClick={() => setCollapsed(true)} aria-label="Collapse sidebar" className="text-muted-foreground hover:text-forest"><PanelLeftClose className="size-4" /></button>
          )}
        </div>
        {collapsed && (
          <button onClick={() => setCollapsed(false)} aria-label="Expand sidebar" className="mb-4 self-center text-muted-foreground hover:text-forest"><PanelLeftOpen className="size-4" /></button>
        )}
        <NavList collapsed={collapsed} />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b bg-background/90 px-4 backdrop-blur lg:hidden">
          <Logo />
          <button onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu className="size-5" /></button>
        </header>
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetContent side="left" className="w-72 bg-sidebar p-5">
            <SheetTitle className="sr-only">Navigation</SheetTitle>
            <div className="mb-8"><Logo /></div>
            <NavList onNavigate={() => setMobileOpen(false)} />
          </SheetContent>
        </Sheet>
        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 md:px-8 md:py-10">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
